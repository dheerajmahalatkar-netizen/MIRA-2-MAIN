export interface GeometryStats {
  allocatedNtfsPct: number;
  unallocatedPct: number;
  deletedMftPct: number;
  reservedPct: number;
  fileSystem: string;
  clusterSize: number;
  sectorsPerCluster: number;
  partitionScheme: string;
}

export interface CaseMetrics {
  fragmentsDetected: number;
  potentiallyRecoverableGb: number;
  reconstructionConfidence: number;
  storageIntegrity: number;
  fragmentation: number;
  corruptionDetected: number;
}

export interface EvidenceCase {
  id: string;
  title: string;
  sourceType: string;
  deviceModel: string;
  sizeGb: number;
  sizeBytes: number;
  driveSizeFormatted?: string;
  sectorCount: number;
  bytesPerSector: number;
  acquisitionDate: string;
  examiner: string;
  examinerRole: string;
  stationId: string;
  status: string;
  verificationStatus: string;
  sha256: string;
  sha256Short: string;
  md5: string;
  md5Short: string;
  fileFormat: string;
  geometry: GeometryStats;
  metrics: CaseMetrics;
  uploadedFiles?: any[];
}

export interface ChainOfCustodyEntry {
  id: string;
  caseId: string;
  timestamp: string;
  action: string;
  operator: string;
  hardwareDevice: string;
  details: string;
  verified: boolean;
  standard: string;
  hashMatch: boolean;
}

export interface HardwareBridge {
  id: string;
  name: string;
  type: string;
  serialNumber: string;
  writeBlocked: boolean;
  hardwareSwitchPos: string;
  status: 'Connected' | 'Standby' | 'Disconnected';
  port: string;
  transferRate: string;
  firmware: string;
  connectedAt?: string;
}

export interface ForensicNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'info' | 'warning' | 'success' | 'alert';
  read: boolean;
}

export interface SystemStatus {
  recoveryEngine: string;
  aiAnalyzer: string;
  writeBlocker: string;
  readOnlyMount: boolean;
  lastHeartbeat: string;
}

export interface ScanJob {
  id: string;
  caseId: string;
  status: 'in_progress' | 'completed' | 'failed' | 'paused';
  currentPhase: string;
  progressPercent: number;
  fragmentsDiscovered: number;
  potentialFileStructures: number;
  potentiallyRecoverableFiles: number;
  storageSize: string;
  sectorsScanned: number;
  scanDuration: string;
  fileSystemDetected: string;
  startedAt: string;
}

export interface PriorityEvidenceItem {
  id: string;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  fileName: string;
  fileType: string;
  status: 'Recovered' | 'Reconstructed' | 'Partial' | 'Duplicate';
  integrity: number;
  confidence: number;
  size?: string;
  sectorLocation?: string;
}

export interface ReconstructedFile {
  id: string;
  caseId?: string;
  fileName: string;
  fileType: string;
  size: string;
  sizeBytes: number;
  confidence: number;
  status: 'reconstructed' | 'in_progress' | 'pending' | 'failed';
  signatureMatchPct: number;
  metadataContinuityPct: number;
  sectorRelationshipPct: number;
  structuralSimilarityPct: number;
  sha256?: string;
  md5?: string;
  startSector?: number;
  endSector?: number;
  fragmentCount?: number;
  hexHeader?: string;
  asciiPreview?: string;
  verificationStatus?: 'Verified Bit-Perfect' | 'Pending Verification' | 'Anomalous Signature';
  reconstructedAt?: string;
  carvingMethod?: string;
}

export interface AnalysisLogItem {
  id: string;
  time: string;
  title: string;
  description: string;
  status: 'completed' | 'active' | 'pending';
}

export interface ReconstructionStats {
  progressPercent: number;
  filesReconstructed: number;
  inProgress: number;
  pending: number;
  failed: number;
  totalFragmentsAnalyzed: number;
  possibleFileStructures: number;
  estimatedRecoverableGb: number;
}

export interface AIAnalysisSummary {
  fragmentsIdentified: number;
  deletedFileStructures: number;
  highConfidenceCount: number;
  requireVerificationCount: number;
  potentialDuplicatesCount: number;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    message: string;
    code?: string;
  };
}

export interface SectorData {
  id: number;
  offset: number;
  offsetHex: string;
  entropy: number;
  classification: 'SPARSE' | 'STRUCTURED_TEXT' | 'BINARY_STRUCTURE' | 'ENCRYPTED_CORRUPT';
  anchor: string | null;
  isReconstructed: boolean;
  linkedArtifactId: string | null;
  hexPreview: string;
  asciiPreview: string;
}

export interface ReconstructionEdge {
  sourceSector: number;
  targetSector: number;
  continuityScore: number;
  reason: string;
}

export interface HexRow {
  offset: string;
  hex: string;
  ascii: string;
}

export interface ForensicArtifact {
  id: string;
  name: string;
  fileType: string;
  triage: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  sourceSectors: number[];
  integrityScore: number;
  confidenceScore: number;
  sha256: string;
  sizeBytes: number;
  sizeFormatted: string;
  isSyntheticDemo: boolean;
  contentPreview: string;
  hexViewRows: HexRow[];
  supportsHeaderRepair: boolean;
  repairStatus: 'NONE' | 'ATTEMPTED' | 'SUCCESS' | 'FAILED';
  repairValidation: string | null;
  provenance: {
    observed: string;
    inferred: string;
    verified: string;
    path: Array<{ from: number; to: number; score: number; reason: string }>;
  };
}

export interface AuditTimelineItem {
  id: string;
  step: string;
  timestamp: string;
  details: string;
  status: 'completed' | 'active';
  hash?: string;
}

export interface ForensicAnalysisResult {
  case: EvidenceCase;
  sectors: SectorData[];
  artifacts: ForensicArtifact[];
  edges: ReconstructionEdge[];
  custody: ChainOfCustodyEntry[];
  auditTimeline: AuditTimelineItem[];
}

export type PageRoute = 
  | 'intro'
  | 'overview' 
  | 'sectors' 
  | 'lab' 
  | 'report'
  | 'evidence-intake' 
  | 'recovery-analysis' 
  | 'reconstruction' 
  | 'evidence-explorer' 
  | 'relationship-graph'
  | 'timeline'
  | 'ai-insights' 
  | 'reports';

export interface AiInsightFinding {
  id: string;
  title: string;
  explanation: string;
  category: 'pattern' | 'relationship' | 'anomaly' | 'key_finding' | 'risk';
  importance: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  confidence: number;
  whyReasons: string[];
  matchedFragmentsCount?: number;
  relatedArtifactIds?: string[];
  relatedSectorIds?: number[];
  timestamp?: string;
}

export interface ReconstructionFragmentNode {
  id: string;
  sourceType: string;
  timestamp: string;
  recoveryStatus: 'Recovered' | 'Carved' | 'Verified' | 'Reconstructed' | 'Pending';
  confidence: number;
  sectorOffset: string;
  preview?: string;
  sizeFormatted?: string;
}

export interface InteractiveTimelineEvent {
  id: string;
  time: string;
  timestamp: string;
  title: string;
  description: string;
  stage: 'detected' | 'extracted' | 'evidence_found' | 'ai_correlated';
  relatedEvidenceId?: string;
  relatedEvidenceName?: string;
  confidence: number;
  metadata?: Record<string, string>;
  rawEntropy?: number;
  sectorLocation?: string;
}

export interface AnomalyRiskAlert {
  id: string;
  type: 'unusual_timestamp' | 'high_priority_evidence' | 'incomplete_reconstruction' | 'strong_correlation';
  severity: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  description: string;
  evidenceId?: string;
  timestamp: string;
  actionLabel?: string;
  actionRoute?: PageRoute;
  actionTargetId?: string;
  dismissed?: boolean;
}

export type GraphNodeType = 'file' | 'fragment' | 'evidence' | 'event' | 'finding';

export interface RelationshipNode {
  id: string;
  label: string;
  sublabel: string;
  type: GraphNodeType;
  confidence?: number;
  status?: string;
  details?: string;
  metadata?: Record<string, string | number>;
  color?: string;
}

export interface RelationshipLink {
  id: string;
  source: string;
  target: string;
  label: string;
  strength: number;
  confidence: number;
}
