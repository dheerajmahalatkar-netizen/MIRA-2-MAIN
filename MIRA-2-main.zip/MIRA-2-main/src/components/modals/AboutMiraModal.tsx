import React from 'react';

interface AboutMiraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEnter: () => void;
}

export const AboutMiraModal: React.FC<AboutMiraModalProps> = ({ isOpen, onClose, onEnter }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-[#0F172A] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-white animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md">
              <span className="material-symbols-outlined text-[20px]">psychology</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">About MIRA</h3>
              <p className="text-xs text-slate-400">Machine Intelligence for Recovery and Analysis</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto text-sm text-slate-300">
          <div>
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400 mb-1">
              Autonomous Forensic Reconstruction Architecture
            </h4>
            <p className="text-slate-300 leading-relaxed">
              MIRA is an explainable digital forensics system built for law enforcement, incident responders, and certified examiners. It solves the critical bottleneck of fragmented, unallocated, and corrupted storage by pairing deterministic 4096-byte LBA sector profiling with neural boundary continuity heuristics.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-2 text-cyan-300 font-semibold text-xs">
                <span className="material-symbols-outlined text-[18px]">lock</span>
                <span>Hardware Write-Block Protection</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Connects directly to certified bridges (e.g. Tableau T8u) ensuring 100% read-only bitstream integrity with dual SHA-256 and MD5 cryptographic attestation.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-2 text-indigo-300 font-semibold text-xs">
                <span className="material-symbols-outlined text-[18px]">analytics</span>
                <span>Shannon Entropy Profiling</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Calculates mathematical entropy (H = -Σ p log₂ p) across all storage sectors, classifying sparse runs, structured code, compressed data, and encrypted remnants.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-2 text-purple-300 font-semibold text-xs">
                <span className="material-symbols-outlined text-[18px]">hub</span>
                <span>64-Byte Boundary Continuity</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Evaluates transition zones across non-contiguous fragments, matching grammar tokens, UTF-8 sequences, and file table links with explainable confidence scores.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-2 text-emerald-300 font-semibold text-xs">
                <span className="material-symbols-outlined text-[18px]">verified</span>
                <span>ISO/IEC 27037 Standard</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Produces court-admissible chain-of-custody PDF ledgers with cryptographic timestamps, examiner signatures, and zero-tamper guarantees.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-blue-950/40 border border-blue-800/40 text-xs text-blue-200 flex items-start gap-3">
            <span className="material-symbols-outlined text-[20px] text-blue-400 shrink-0 mt-0.5">verified_user</span>
            <div>
              <span className="font-bold text-white block">Lead Forensic Examiner Station</span>
              Operating under examiner ID: Abhishek (Lead Forensic Analyst, Station WS-EVIDENCE-04). All reconstruction operations execute locally in a sealed environment.
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <span className="text-xs font-mono text-slate-400">Core Engine: MIRA v2.4 PRO</span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onEnter();
              }}
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <span>Enter Workstation</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
