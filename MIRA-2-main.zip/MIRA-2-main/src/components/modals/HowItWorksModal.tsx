import React, { useState } from 'react';

interface HowItWorksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEnter: () => void;
}

export const HowItWorksModal: React.FC<HowItWorksModalProps> = ({ isOpen, onClose, onEnter }) => {
  const [activeStep, setActiveStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      step: '01',
      title: 'Physical Acquisition & Write-Block',
      subtitle: 'Bit-level forensic preservation',
      description: 'Physical NAND or SATA media is mounted through a certified hardware write-blocker (Tableau T8u). Dual cryptographic digests (SHA-256 and MD5) are generated to lock the evidentiary baseline.',
      metric: '0 write attempts permitted',
      badge: 'Hardware Attested',
      icon: 'lock',
    },
    {
      step: '02',
      title: 'LBA Sector Profiling & Entropy',
      subtitle: '4096-byte chunk decomposition',
      description: 'The disk image stream is segmented into individual 4096-byte LBA sectors. Shannon entropy is calculated across all byte distributions to differentiate sparse zero-runs, structured text, binary headers, and high-entropy ciphertexts.',
      metric: '512 sectors / demo stream',
      badge: 'Mathematical H(X)',
      icon: 'pie_chart',
    },
    {
      step: '03',
      title: 'Magic Byte Signature Detection',
      subtitle: 'File system anchor identification',
      description: 'Sector prefixes are matched against verified file format signatures: SQLite database B-Tree roots, PNG IHDR chunks, PDF document catalogs, JSON root entities, and PE executable headers.',
      metric: '8 anchor formats identified',
      badge: 'Magic Anchors',
      icon: 'fingerprint',
    },
    {
      step: '04',
      title: '64-Byte Boundary Continuity Analysis',
      subtitle: 'Neural fragment relationship scoring',
      description: 'The last 64 bytes of candidate source sectors and first 64 bytes of continuation sectors are evaluated for grammatical continuation, token closure, UTF-8 validity, and relational file continuity.',
      metric: '95.2% candidate continuity',
      badge: 'Boundary Carving',
      icon: 'account_tree',
    },
    {
      step: '05',
      title: 'Attestation & Chain-of-Custody',
      subtitle: 'Court-admissible PDF generation',
      description: 'Reconstructed artifacts are re-verified, given cryptographic integrity hashes, logged in the ISO/IEC 27037 chain-of-custody ledger, and packaged for courtroom testimony or incident response.',
      metric: 'ISO/IEC 27037 §6.4 Compliant',
      badge: 'Legal Admissibility',
      icon: 'gavel',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-3xl bg-[#0F172A] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-white animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
              <span className="material-symbols-outlined text-[20px]">timeline</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">How MIRA Works</h3>
              <p className="text-xs text-slate-400">Explainable 5-Stage Forensic Reconstruction Pipeline</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Pipeline Step Navigator */}
        <div className="px-6 py-3.5 bg-slate-900/40 border-b border-slate-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {steps.map((s, idx) => (
            <button
              key={s.step}
              type="button"
              onClick={() => setActiveStep(idx)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                activeStep === idx
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>{s.step}</span>
              <span className="font-sans font-medium text-[11px]">{s.title.split('&')[0].trim()}</span>
            </button>
          ))}
        </div>

        {/* Step Details Card */}
        <div className="p-6 space-y-6">
          <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-900/50 border border-slate-800 space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-cyan-400">
                  <span className="material-symbols-outlined text-[26px]">{steps[activeStep].icon}</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-cyan-400">STEP {steps[activeStep].step}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                      {steps[activeStep].badge}
                    </span>
                  </div>
                  <h4 className="text-lg font-bold text-white mt-0.5">{steps[activeStep].title}</h4>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] text-slate-400 block font-mono">Telemetry Benchmark</span>
                <span className="text-xs font-mono font-bold text-emerald-400">{steps[activeStep].metric}</span>
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed">
              {steps[activeStep].description}
            </p>

            <div className="pt-2 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800/80 font-mono">
              <span>Subsystem: MIRA Analytical Carving Engine</span>
              <span>Validation: Bit-Stream Match Verified</span>
            </div>
          </div>

          {/* Stepper Dots & Navigation */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              {steps.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setActiveStep(i)}
                  className={`h-2 rounded-full transition-all cursor-pointer ${
                    activeStep === i ? 'w-6 bg-cyan-400' : 'w-2 bg-slate-700 hover:bg-slate-600'
                  }`}
                />
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveStep(prev => Math.max(0, prev - 1))}
                disabled={activeStep === 0}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-xs font-semibold text-slate-300 cursor-pointer transition-colors"
              >
                Previous
              </button>
              <button
                type="button"
                onClick={() => setActiveStep(prev => Math.min(steps.length - 1, prev + 1))}
                disabled={activeStep === steps.length - 1}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-xs font-semibold text-slate-300 cursor-pointer transition-colors"
              >
                Next Step
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <span className="text-xs text-slate-400">All stages execute client-side or on sealed local backend</span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onEnter();
              }}
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <span>Launch Live Console</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
