import React, { useState } from 'react';
import { useForensic } from '../../context/ForensicContext';

interface HardwareBridgeModalProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export const HardwareBridgeModal: React.FC<HardwareBridgeModalProps> = ({ isOpen, onClose }) => {
  const { bridgeModalOpen, setBridgeModalOpen, hardwareBridges, connectBridge } = useForensic();
  const [selectedBridge, setSelectedBridge] = useState(hardwareBridges[0]?.id || 'BRG-TABLEAU-T8U');
  const [testingPort, setTestingPort] = useState(false);

  const isModalOpen = isOpen !== undefined ? isOpen : bridgeModalOpen;
  const handleClose = () => {
    if (onClose) {
      onClose();
    }
    setBridgeModalOpen(false);
  };

  if (!isModalOpen) return null;

  const current = hardwareBridges.find(b => b.id === selectedBridge) || hardwareBridges[0];

  const handleConnect = async () => {
    setTestingPort(true);
    await connectBridge(selectedBridge);
    setTestingPort(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden text-slate-900">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shadow-xs">
              <span className="material-symbols-outlined text-[18px]">cable</span>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Attach Forensic Hardware Bridge
              </h3>
              <p className="text-[11px] text-slate-500">
                Write-blocked physical acquisition bus configuration
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-slate-400 hover:text-slate-700 p-1 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-800">
              Select Detected Hardware Device
            </label>
            <div className="grid grid-cols-1 gap-2.5">
              {hardwareBridges.map(bridge => (
                <div
                  key={bridge.id}
                  onClick={() => setSelectedBridge(bridge.id)}
                  className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                    selectedBridge === bridge.id
                      ? 'border-blue-600 bg-blue-50/70 ring-1 ring-blue-600 shadow-2xs'
                      : 'border-slate-200 bg-slate-50 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900">
                      {bridge.name}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-semibold ${
                        bridge.status === 'Connected'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {bridge.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    Port: {bridge.port} · Bus: {bridge.transferRate}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Bridge Telemetry Diagnostics */}
          {current && (
            <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-2 text-xs">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Hardware Serial:</span>
                <span className="font-mono text-slate-900 font-medium">
                  {current.serialNumber}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Physical Write-Block Switch:</span>
                <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
                  <span className="material-symbols-outlined text-[14px]">lock</span>
                  {current.hardwareSwitchPos}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Firmware Attestation:</span>
                <span className="font-mono text-slate-800">
                  {current.firmware}
                </span>
              </div>
            </div>
          )}

          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2.5 text-[11px] text-emerald-800">
            <span className="material-symbols-outlined text-[18px] text-emerald-600 shrink-0">
              verified_user
            </span>
            <span>
              All bridge communications enforce zero write commands per NIST SP 800-86 testing specifications.
            </span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2.5">
          <button
            onClick={() => setBridgeModalOpen(false)}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
            type="button"
          >
            Cancel
          </button>
          <button
            onClick={handleConnect}
            disabled={testingPort}
            className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs flex items-center gap-2 disabled:opacity-50 cursor-pointer transition-colors"
            type="button"
          >
            {testingPort ? (
              <>
                <span className="material-symbols-outlined text-[16px] animate-spin">
                  sync
                </span>
                <span>Handshaking Bus...</span>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-[16px]">cable</span>
                <span>Mount &amp; Verify Write-Block</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
