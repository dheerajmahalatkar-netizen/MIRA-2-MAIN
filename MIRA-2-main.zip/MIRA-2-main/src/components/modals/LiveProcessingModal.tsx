import React, { useEffect, useState } from 'react';

export interface LiveProcessingStep {
  id: string;
  icon: string;
  label: string;
  status: 'pending' | 'active' | 'completed';
  detail: string;
}

interface LiveProcessingModalProps {
  isOpen: boolean;
  onComplete: () => void;
  title?: string;
}

export const LiveProcessingModal: React.FC<LiveProcessingModalProps> = ({
  isOpen,
  onComplete,
  title = 'Processing Forensic Image',
}) => {
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [isDone, setIsDone] = useState(false);

  const initialSteps: Array<{ icon: string; label: string; detail: string }> = [
    { icon: 'search', label: 'Scanning...', detail: 'Enumerating physical sectors and Shannon entropy distribution.' },
    { icon: 'extension', label: 'Reconstructing fragments...', detail: 'Correlating LBA sector clusters with known file signatures.' },
    { icon: 'hub', label: 'Connecting evidence...', detail: 'Mapping sector adjacency, USN journal links, and metadata continuity.' },
    { icon: 'psychology', label: 'Generating insights...', detail: 'Applying neural confidence models and anomaly heuristics.' },
    { icon: 'bar_chart', label: 'Preparing analysis...', detail: 'Generating cryptographic attestation ledgers and relationship graphs.' },
    { icon: 'check_circle', label: 'Analysis Complete', detail: 'Court-admissible ISO/IEC 27037 forensic package ready for review.' },
  ];

  useEffect(() => {
    if (!isOpen) {
      setCurrentStepIdx(0);
      setIsDone(false);
      return;
    }

    let current = 0;
    const interval = setInterval(() => {
      current += 1;
      if (current < initialSteps.length) {
        setCurrentStepIdx(current);
      } else {
        setIsDone(true);
        clearInterval(interval);
      }
    }, 700);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const progressPct = Math.round(((currentStepIdx + 1) / initialSteps.length) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full p-6 space-y-6 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto mb-3 shadow-xs">
            <span className={`material-symbols-outlined text-[26px] ${!isDone ? 'animate-spin' : ''}`}>
              {isDone ? 'verified' : 'sync'}
            </span>
          </div>
          <h3 className="text-base font-bold text-slate-900">{title}</h3>
          <p className="text-xs text-slate-500">MIRA local analytical reconstruction engine</p>
        </div>

        {/* Progress Bar */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-500">Stage {currentStepIdx + 1} of {initialSteps.length}</span>
            <span className="font-bold text-blue-600">{progressPct}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progressPct}%` }}
            ></div>
          </div>
        </div>

        {/* Stepper List */}
        <div className="space-y-2.5">
          {initialSteps.map((step, idx) => {
            const isCompleted = idx < currentStepIdx || isDone;
            const isActive = idx === currentStepIdx && !isDone;
            const isPending = idx > currentStepIdx && !isDone;

            return (
              <div
                key={idx}
                className={`flex items-start gap-3 p-2.5 rounded-lg border text-xs transition-all duration-200 ${
                  isActive
                    ? 'bg-blue-50/70 border-blue-300 shadow-2xs'
                    : isCompleted
                    ? 'bg-white border-slate-100 text-slate-700'
                    : 'bg-slate-50/50 border-transparent text-slate-400 opacity-60'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 mt-0.5 ${
                    isCompleted
                      ? 'bg-emerald-100 text-emerald-700'
                      : isActive
                      ? 'bg-blue-600 text-white animate-pulse'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {isCompleted ? 'check' : step.icon}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className={`font-semibold ${isActive ? 'text-blue-900 font-bold' : ''}`}>
                      {step.label}
                    </span>
                    {isActive && (
                      <span className="text-[10px] font-mono text-blue-600 animate-pulse font-semibold">
                        PROCESSING
                      </span>
                    )}
                    {isCompleted && (
                      <span className="text-[10px] font-mono text-emerald-600 font-semibold">DONE</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">{step.detail}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="pt-2">
          {isDone ? (
            <button
              type="button"
              onClick={onComplete}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>View Analysis Results</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </button>
          ) : (
            <div className="text-center text-[11px] text-slate-400 font-mono flex items-center justify-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping"></span>
              <span>Running deterministic ISO/IEC 27037 verification...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
