import React, { useState, useEffect } from 'react';
import { useForensic } from '../../context/ForensicContext';

interface ActionItem {
  id: string;
  title: string;
  category: string;
  icon: string;
  action: () => void;
}

export const CommandPaletteModal: React.FC = () => {
  const {
    cmdPaletteOpen,
    setCmdPaletteOpen,
    setActiveRoute,
    loadDemo,
    exportCustodyPdf,
    verifyIntegrity,
    currentCase,
    showToast,
  } = useForensic();

  const [query, setQuery] = useState('');

  useEffect(() => {
    if (cmdPaletteOpen) {
      setQuery('');
    }
  }, [cmdPaletteOpen]);

  if (!cmdPaletteOpen) return null;

  const actions: ActionItem[] = [
    {
      id: 'nav-overview',
      title: 'Go to Overview',
      category: 'Navigation',
      icon: 'dashboard',
      action: () => setActiveRoute('overview'),
    },
    {
      id: 'nav-intake',
      title: 'Go to Evidence Intake',
      category: 'Navigation',
      icon: 'archive',
      action: () => setActiveRoute('evidence-intake'),
    },
    {
      id: 'nav-recovery',
      title: 'Go to Recovery Analysis',
      category: 'Navigation',
      icon: 'manage_search',
      action: () => setActiveRoute('recovery-analysis'),
    },
    {
      id: 'nav-reconstruction',
      title: 'Go to Reconstruction',
      category: 'Navigation',
      icon: 'account_tree',
      action: () => setActiveRoute('reconstruction'),
    },
    {
      id: 'nav-explorer',
      title: 'Go to Evidence Explorer',
      category: 'Navigation',
      icon: 'folder_open',
      action: () => setActiveRoute('evidence-explorer'),
    },
    {
      id: 'nav-insights',
      title: 'Go to AI Insights',
      category: 'Navigation',
      icon: 'psychology',
      action: () => setActiveRoute('ai-insights'),
    },
    {
      id: 'nav-reports',
      title: 'Go to Reports & Attestations',
      category: 'Navigation',
      icon: 'summarize',
      action: () => setActiveRoute('reports'),
    },
    {
      id: 'nav-sectors',
      title: 'Go to Sector Map',
      category: 'Navigation',
      icon: 'grid_view',
      action: () => setActiveRoute('sectors'),
    },
    {
      id: 'nav-lab',
      title: 'Go to Evidence Lab',
      category: 'Navigation',
      icon: 'biotech',
      action: () => setActiveRoute('lab'),
    },
    {
      id: 'act-demo',
      title: 'Load Synthetic Evidence Demo Image',
      category: 'Pipeline Action',
      icon: 'play_circle',
      action: () => loadDemo(),
    },
    {
      id: 'act-verify',
      title: 'Verify Bit-Stream Cryptographic Attestation',
      category: 'Integrity Check',
      icon: 'verified',
      action: () => verifyIntegrity(),
    },
    {
      id: 'act-pdf',
      title: 'Export ISO/IEC 27037 Attestation Record (PDF)',
      category: 'Reporting',
      icon: 'picture_as_pdf',
      action: () => exportCustodyPdf(),
    },
    {
      id: 'case-hash',
      title: `Copy Image SHA-256 (${currentCase?.sha256Short || 'a8f4e2c6...'})`,
      category: 'Cryptographic Hash',
      icon: 'content_copy',
      action: () => {
        if (currentCase?.sha256) {
          navigator.clipboard.writeText(currentCase.sha256);
          showToast('Copied full SHA-256 hash to clipboard', 'success');
        }
      },
    },
  ];

  const filtered = actions.filter(
    item =>
      item.title.toLowerCase().includes(query.toLowerCase()) ||
      item.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-100"
      onClick={() => setCmdPaletteOpen(false)}
    >
      <div
        className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden text-slate-900"
        onClick={e => e.stopPropagation()}
      >
        {/* Search Bar */}
        <div className="p-3 border-b border-slate-200 flex items-center gap-3">
          <span className="material-symbols-outlined text-[20px] text-slate-400">
            search
          </span>
          <input
            type="text"
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Type a command or jump to page..."
            className="flex-1 bg-transparent text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
          />
          <kbd className="px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-[10px] font-mono text-slate-500">
            ESC
          </kbd>
        </div>

        {/* Action Results */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1">
          {filtered.length > 0 ? (
            filtered.map(item => (
              <div
                key={item.id}
                onClick={() => {
                  item.action();
                  setCmdPaletteOpen(false);
                }}
                className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-md bg-slate-100 group-hover:bg-blue-50 text-slate-500 group-hover:text-blue-600 flex items-center justify-center transition-colors">
                    <span className="material-symbols-outlined text-[16px]">
                      {item.icon}
                    </span>
                  </div>
                  <span className="text-xs font-medium text-slate-800 group-hover:text-slate-900">
                    {item.title}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  {item.category}
                </span>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-xs text-slate-500">
              No matching commands or pages found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
