import React, { useState } from 'react';
import { useForensic } from '../../context/ForensicContext';
import {
  DEFAULT_AI_FINDINGS,
  DEFAULT_TIMELINE_EVENTS,
  DEFAULT_GRAPH_NODES,
} from '../../data/forensicIntelligenceData';

interface FinalReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FinalReportModal: React.FC<FinalReportModalProps> = ({ isOpen, onClose }) => {
  const { currentCase, artifacts, reconstructedFiles, showToast } = useForensic();
  const [activeTab, setActiveTab] = useState<'preview' | 'json' | 'markdown'>('preview');

  if (!isOpen) return null;

  const caseId = currentCase?.id || 'CASE-2026-091';
  const examiner = currentCase?.examiner || 'J. Vance';
  const dateStr = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handlePrint = () => {
    window.print();
  };

  const handleCopyMarkdown = () => {
    const md = `# MIRA FORENSIC ATTESTATION & FINAL REPORT
**Case ID:** ${caseId}  
**Examiner:** ${examiner}  
**Standard:** ISO/IEC 27037 Digital Evidence Admissibility  
**Date:** ${dateStr}  

---

## 1. Executive Summary
During forensic analysis of the target media (${currentCase?.deviceModel || 'Seagate FireCuda 2TB'}), MIRA reconstructed ${reconstructedFiles.length || 3} primary files from unallocated and slack sectors with 100% bitstream integrity. All SHA-256 and MD5 hashes match hardware write-blocked acquisitions.

## 2. Reconstructed Evidence
${reconstructedFiles
  .map(
    f =>
      `- **${f.fileName}** (${f.fileType}, ${f.size}) - Confidence: ${f.confidence}% - SHA-256: \`${f.sha256 || 'N/A'}\``
  )
  .join('\n')}

## 3. Important Findings
${DEFAULT_AI_FINDINGS.map(
  f =>
    `- [${f.importance}] **${f.title}** (${f.confidence}% Confidence): ${f.explanation}`
).join('\n')}

## 4. Timeline
${DEFAULT_TIMELINE_EVENTS.map(t => `- **${t.time}**: ${t.title} - ${t.description}`).join('\n')}

## 5. Relationships
- Nodes Identified: ${DEFAULT_GRAPH_NODES.length}
- Verified Flow: File -> Fragment -> Evidence -> Event -> Finding

## 6. AI Insights & Confidence Levels
- Mean Confidence: 95.4%
- Boundary Continuity: 98.2%
- Cryptographic Validation: 100% Bit-Perfect

## 7. Key Observations & Recommendations
- Immediate containment of exposed API tokens in Sector #180.
- Submit SQLite database records into court evidentiary chain.
`;
    navigator.clipboard.writeText(md);
    showToast('Markdown report copied to clipboard!', 'success');
  };

  const handleDownloadJson = () => {
    const reportData = {
      meta: {
        reportType: 'MIRA AI Final Report',
        caseId,
        examiner,
        date: dateStr,
        standard: 'ISO/IEC 27037',
      },
      executiveSummary: `MIRA reconstructed ${reconstructedFiles.length || 3} primary files from unallocated and slack sectors with 100% bitstream integrity.`,
      reconstructedEvidence: reconstructedFiles,
      importantFindings: DEFAULT_AI_FINDINGS,
      timeline: DEFAULT_TIMELINE_EVENTS,
      relationships: DEFAULT_GRAPH_NODES,
      confidenceLevels: {
        meanConfidence: 95.4,
        boundaryContinuity: 98.2,
        integrityScore: 100,
      },
      keyObservations: [
        'High-entropy API token fragments identified in unallocated space.',
        'SQLite transaction ledger verified across sectors #12, #13, #14.',
        'No write blocker bypass or hash collisions detected.',
      ],
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MIRA_Final_Report_${caseId}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Report JSON downloaded successfully', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center font-bold text-sm">
              <span className="material-symbols-outlined text-[20px]">description</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900">
                  MIRA One-Click AI Final Report
                </h3>
                <span className="text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                  ISO/IEC 27037
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Case: {caseId} · Generated: {dateStr}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
              title="Print or Save as PDF"
            >
              <span className="material-symbols-outlined text-[16px]">print</span>
              <span className="hidden sm:inline">Print / PDF</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadJson}
              className="px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <span className="material-symbols-outlined text-[16px]">data_object</span>
              <span className="hidden sm:inline">Export JSON</span>
            </button>
            <button
              type="button"
              onClick={handleCopyMarkdown}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <span className="material-symbols-outlined text-[16px]">content_copy</span>
              <span>Copy MD</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 py-2 border-b border-slate-100 flex items-center gap-2 text-xs bg-white">
          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
              activeTab === 'preview'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Formatted Preview
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('json')}
            className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
              activeTab === 'json'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            JSON Raw Schema
          </button>
        </div>

        {/* Report Content Body */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6 text-slate-800 text-xs leading-relaxed bg-white">
          {activeTab === 'preview' ? (
            <div className="space-y-6 max-w-3xl mx-auto border border-slate-200 rounded-xl p-8 shadow-xs bg-white">
              {/* Header Box */}
              <div className="border-b-2 border-slate-900 pb-5 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-blue-600 font-bold">
                    Official Evidentiary Attestation
                  </span>
                  <h1 className="text-xl font-bold text-slate-900 mt-1">
                    Forensic Examination &amp; AI Reconstruction Report
                  </h1>
                  <p className="text-xs text-slate-500 font-mono mt-1">
                    ISO/IEC 27037 Standard Digital Forensics Dossier
                  </p>
                </div>
                <div className="text-right text-[11px] font-mono text-slate-600 space-y-0.5 shrink-0">
                  <div><strong>Case ID:</strong> {caseId}</div>
                  <div><strong>Examiner:</strong> {examiner}</div>
                  <div><strong>Status:</strong> Admissible</div>
                </div>
              </div>

              {/* 1. Executive Summary */}
              <section className="space-y-2">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-1">
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  1. Executive Summary
                </h2>
                <p className="text-slate-600 leading-relaxed">
                  During forensic acquisition and automated analytical carving of target media{' '}
                  <span className="font-mono text-slate-800 font-medium">
                    {currentCase?.title || 'Physical Disk 0'}
                  </span>
                  , MIRA discovered and reconstructed {reconstructedFiles.length || 3} primary files.
                  Cryptographic hashing (dual SHA-256 and MD5) affirms bit-level verification with zero
                  alteration from the hardware write-blocked state.
                </p>
              </section>

              {/* 2. Reconstructed Evidence */}
              <section className="space-y-2">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-1">
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  2. Reconstructed Evidence Artifacts
                </h2>
                <div className="overflow-x-auto border border-slate-200 rounded-lg">
                  <table className="w-full text-left text-[11px]">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold font-mono">
                      <tr>
                        <th className="p-2">File Name</th>
                        <th className="p-2">Type</th>
                        <th className="p-2">Size</th>
                        <th className="p-2">Confidence</th>
                        <th className="p-2 font-mono">SHA-256 Checksum</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {reconstructedFiles.map(file => (
                        <tr key={file.id}>
                          <td className="p-2 font-bold font-mono text-slate-900">{file.fileName}</td>
                          <td className="p-2 text-slate-600">{file.fileType}</td>
                          <td className="p-2 font-mono text-slate-600">{file.size}</td>
                          <td className="p-2 font-bold text-emerald-700">{file.confidence}%</td>
                          <td className="p-2 font-mono text-[10px] text-slate-500 truncate max-w-[140px]">
                            {file.sha256}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              {/* 3. Important Findings */}
              <section className="space-y-2">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-1">
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  3. Important Findings &amp; Anomalies
                </h2>
                <div className="space-y-2">
                  {DEFAULT_AI_FINDINGS.map(f => (
                    <div key={f.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{f.title}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded font-bold bg-white border border-slate-200 text-slate-700">
                          {f.importance} · {f.confidence}%
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1">{f.explanation}</p>
                    </div>
                  ))}
                </div>
              </section>

              {/* 4. Timeline */}
              <section className="space-y-2">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-1">
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  4. Chronological Reconstruction Timeline
                </h2>
                <div className="space-y-1.5">
                  {DEFAULT_TIMELINE_EVENTS.map(t => (
                    <div key={t.id} className="flex items-start gap-3 text-[11px]">
                      <span className="font-mono text-slate-500 font-bold shrink-0 w-16">
                        {t.time}
                      </span>
                      <div>
                        <strong className="text-slate-900">{t.title}</strong>
                        <span className="text-slate-500"> — {t.description}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* 5. Key Observations */}
              <section className="space-y-2">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-1">
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  5. Key Observations &amp; Next Steps
                </h2>
                <ul className="list-disc list-inside space-y-1 text-slate-600 text-[11px]">
                  <li>Dual-hash verification confirms bit-for-bit parity with initial acquisition.</li>
                  <li>Critical token exposure in Sector #180 should be escalated for security credential rotation.</li>
                  <li>SQLite database entries exhibit sequential continuity and are ready for court admission.</li>
                </ul>
              </section>

              {/* Sign-off footer */}
              <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-[11px] font-mono text-slate-500">
                <div>Digital Signature: SHA256-RSA Verified</div>
                <div>Examiner: {examiner}</div>
              </div>
            </div>
          ) : (
            <pre className="p-4 bg-slate-900 text-emerald-400 rounded-xl text-[11px] font-mono overflow-x-auto max-h-[500px]">
              {JSON.stringify(
                {
                  caseId,
                  examiner,
                  standard: 'ISO/IEC 27037',
                  reconstructedFiles,
                  findings: DEFAULT_AI_FINDINGS,
                  timeline: DEFAULT_TIMELINE_EVENTS,
                },
                null,
                2
              )}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};
