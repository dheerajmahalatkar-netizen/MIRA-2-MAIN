import React, { useState } from 'react';
import { useForensic } from '../../context/ForensicContext';

export const ReconstructionDetailModal: React.FC = () => {
  const {
    fileDetailModalOpen,
    setFileDetailModalOpen,
    selectedReconstructedFile,
    verifyReconstructedFile,
    reAnalyzeReconstructedFile,
    downloadFileBitstream,
    showToast,
  } = useForensic();

  const [activeTab, setActiveTab] = useState<'provenance' | 'hex' | 'indicators'>('provenance');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  if (!fileDetailModalOpen || !selectedReconstructedFile) return null;

  const file = selectedReconstructedFile;

  const handleCopyHash = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(type);
    showToast(`Copied ${type} hash to clipboard`, 'info');
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const handleVerify = async () => {
    setIsVerifying(true);
    try {
      await verifyReconstructedFile(file.id);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleReAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      await reAnalyzeReconstructedFile(file.id);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={() => setFileDetailModalOpen(false)}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden text-slate-900 dark:text-slate-100"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-950 border border-blue-100 dark:border-blue-900 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[22px]">
                {file.fileType === 'Document'
                  ? 'description'
                  : file.fileType === 'Archive'
                  ? 'folder_zip'
                  : file.fileType === 'Database'
                  ? 'database'
                  : file.fileType === 'Image'
                  ? 'image'
                  : 'draft'}
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold tracking-tight font-mono truncate max-w-[320px]">
                  {file.fileName}
                </h3>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    file.confidence >= 85
                      ? 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300'
                      : 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300'
                  }`}
                >
                  {file.confidence}% confidence
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {file.size} · {file.fileType} · ID: {file.id}
              </p>
            </div>
          </div>
          <button
            onClick={() => setFileDetailModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            type="button"
            aria-label="Close modal"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] text-xs font-semibold gap-6">
          <button
            onClick={() => setActiveTab('provenance')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'provenance'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-300'
            }`}
          >
            Provenance & Carving
          </button>
          <button
            onClick={() => setActiveTab('hex')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'hex'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-300'
            }`}
          >
            Hex Header Inspection
          </button>
          <button
            onClick={() => setActiveTab('indicators')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'indicators'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-300'
            }`}
          >
            AI Linkage Indicators
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {activeTab === 'provenance' && (
            <div className="space-y-4">
              {/* Status Banner */}
              <div className="p-3 bg-blue-50/70 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/50 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-blue-600 text-[18px]">verified</span>
                  <div>
                    <span className="font-bold text-blue-900 dark:text-blue-200">
                      {file.verificationStatus || 'Verified Bit-Perfect'}
                    </span>
                    <p className="text-[11px] text-blue-700 dark:text-blue-300">
                      ISO/IEC 27037 write-blocked forensic assembly authenticated.
                    </p>
                  </div>
                </div>
                <span className="font-mono text-[11px] text-blue-700 dark:text-blue-300">
                  {file.reconstructedAt || '10:44 UTC'}
                </span>
              </div>

              {/* Forensic Parameters Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-lg border border-slate-100 dark:border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Carving Algorithm</span>
                  <div className="font-semibold text-slate-800 dark:text-slate-200">
                    {file.carvingMethod || 'Bifragment Gap Carving + MFT Heuristics'}
                  </div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-lg border border-slate-100 dark:border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Fragment Count</span>
                  <div className="font-semibold text-slate-800 dark:text-slate-200">
                    {file.fragmentCount || 4} contiguous & non-contiguous sectors
                  </div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-lg border border-slate-100 dark:border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Sector Allocation Range</span>
                  <div className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                    LBA {file.startSector?.toLocaleString() || '104,288'} - {file.endSector?.toLocaleString() || '129,688'}
                  </div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-lg border border-slate-100 dark:border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Byte Stream Length</span>
                  <div className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                    {file.sizeBytes?.toLocaleString() || '13,002,488'} bytes
                  </div>
                </div>
              </div>

              {/* Cryptographic Hashes */}
              <div className="space-y-2 pt-1">
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                  Cryptographic Integrity Signatures
                </span>
                <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2 font-mono text-[11px]">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400 font-bold shrink-0">SHA-256:</span>
                    <span className="text-slate-700 dark:text-slate-300 truncate">
                      {file.sha256 || 'a8f4c931b2e47d890f12c448a609d1e43b92f708231947b198c614b8991d2e5a'}
                    </span>
                    <button
                      onClick={() => handleCopyHash(file.sha256 || '', 'SHA-256')}
                      className="px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[10px] text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                    >
                      {copiedHash === 'SHA-256' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400 font-bold shrink-0">MD5:</span>
                    <span className="text-slate-700 dark:text-slate-300 truncate">
                      {file.md5 || '4f7d29c8e10b2849a602de82049e29a1'}
                    </span>
                    <button
                      onClick={() => handleCopyHash(file.md5 || '', 'MD5')}
                      className="px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[10px] text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                    >
                      {copiedHash === 'MD5' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'hex' && (
            <div className="space-y-3 font-mono">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-600 dark:text-slate-300">
                  Header Magic Bytes & ASCII Stream
                </span>
                <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold">
                  ✓ Valid Standard Signature
                </span>
              </div>
              <div className="bg-slate-900 text-slate-100 p-3.5 rounded-lg border border-slate-800 text-[11px] space-y-1 overflow-x-auto leading-relaxed">
                <div className="text-slate-500 border-b border-slate-800 pb-1 flex justify-between">
                  <span>Offset (h)  00 01 02 03 04 05 06 07  08 09 0A 0B 0C 0D 0E 0F</span>
                  <span>Decoded Text</span>
                </div>
                <div className="flex justify-between text-emerald-400">
                  <span>00000000  {file.hexHeader || '50 4B 03 04 14 00 06 00  08 00 00 00 21 00 3C F7'}</span>
                  <span className="text-amber-300">{file.asciiPreview || 'PK......!.<...'}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>00000010  64 6F 63 50 72 6F 70 73  2F 61 70 70 2E 78 6D 6C</span>
                  <span className="text-slate-300">docProps/app.xml</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>00000020  78 6C 2F 77 6F 72 6B 62  6F 6F 6B 2E 78 6D 6C 20</span>
                  <span className="text-slate-300">xl/workbook.xml </span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>00000030  ... [... truncated remaining {file.size} carved stream ...]</span>
                  <span>...</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 leading-snug">
                Physical sector signature verification confirmed zero header bit-rot. File container structure matches official ISO format specification.
              </p>
            </div>
          )}

          {activeTab === 'indicators' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-lg border border-slate-200 dark:border-slate-800">
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block mb-1">
                  AI Reconstruction Model Attribution
                </span>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Fragments were matched and stitched using heuristic cluster continuity, header-footer parity analysis, and entropy profiling.
                </p>
              </div>

              {/* Progress bars for each indicator */}
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 dark:text-slate-300">File Signature Match</span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{file.signatureMatchPct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full transition-all duration-300" style={{ width: `${file.signatureMatchPct}%` }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 dark:text-slate-300">Metadata Continuity</span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{file.metadataContinuityPct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-blue-600 h-full rounded-full transition-all duration-300" style={{ width: `${file.metadataContinuityPct}%` }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 dark:text-slate-300">Sector Relationship & Cluster Proximity</span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{file.sectorRelationshipPct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full transition-all duration-300" style={{ width: `${file.sectorRelationshipPct}%` }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-medium mb-1">
                    <span className="text-slate-700 dark:text-slate-300">Structural Similarity</span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{file.structuralSimilarityPct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full transition-all duration-300" style={{ width: `${file.structuralSimilarityPct}%` }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleVerify}
              disabled={isVerifying}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">verified</span>
              <span>{isVerifying ? 'Verifying...' : 'Verify Parity'}</span>
            </button>
            <button
              onClick={handleReAnalyze}
              disabled={isAnalyzing}
              className="px-3.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">psychology</span>
              <span>{isAnalyzing ? 'Re-analyzing...' : 'Neural Refine'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => downloadFileBitstream(file)}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              <span>Download File</span>
            </button>
            <button
              onClick={() => setFileDetailModalOpen(false)}
              className="px-3.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold transition-colors"
              type="button"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
