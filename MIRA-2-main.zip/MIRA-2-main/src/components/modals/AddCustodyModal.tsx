import React, { useState } from 'react';
import { useForensic } from '../../context/ForensicContext';

export const AddCustodyModal: React.FC = () => {
  const { custodyModalOpen, setCustodyModalOpen, addCustodyEntry, currentCase } = useForensic();

  const [action, setAction] = useState('Evidence Transfer & Custody Handover');
  const [details, setDetails] = useState('');
  const [operator, setOperator] = useState('Abhishek · Lead Forensic Analyst');
  const [standard, setStandard] = useState('ISO/IEC 27037-aligned');
  const [hardwareDevice, setHardwareDevice] = useState('Tableau T8u Bridge (Write-Blocked)');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  if (!custodyModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!action.trim()) {
      setFormError('Custody action title is required');
      return;
    }
    if (!details.trim() || details.trim().length < 8) {
      setFormError('Detailed custody justification (min 8 characters) is required for forensic compliance');
      return;
    }

    try {
      setIsSubmitting(true);
      await addCustodyEntry(action, details, operator);
      setDetails('');
      setCustodyModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to submit custody record');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden text-slate-900">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shadow-xs">
              <span className="material-symbols-outlined text-[18px]">verified_user</span>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Log Chain of Custody Event
              </h3>
              <p className="text-[11px] text-slate-500">
                Case {currentCase?.id || 'CASE-2026-091'} · ISO/IEC 27037-aligned workflow
              </p>
            </div>
          </div>
          <button
            onClick={() => setCustodyModalOpen(false)}
            className="text-slate-400 hover:text-slate-700 p-1 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4 text-xs">
            {formError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] shrink-0">error</span>
                <span>{formError}</span>
              </div>
            )}

            <div className="space-y-1">
              <label className="font-semibold text-slate-800">
                Action / Custody Operation <span className="text-rose-600">*</span>
              </label>
              <select
                value={action}
                onChange={e => setAction(e.target.value)}
                className="w-full h-9 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              >
                <option value="Evidence Transfer & Custody Handover">
                  Evidence Transfer &amp; Custody Handover
                </option>
                <option value="Sealed Storage Vault Check-in">
                  Sealed Storage Vault Check-in
                </option>
                <option value="Secondary Hash Verification">
                  Secondary Hash Verification
                </option>
                <option value="Forensic Analysis Check-out">
                  Forensic Analysis Check-out
                </option>
                <option value="Court Evidence Staging">
                  Court Evidence Staging
                </option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-800">
                  Examiner / Operator
                </label>
                <input
                  type="text"
                  value={operator}
                  onChange={e => setOperator(e.target.value)}
                  className="w-full h-9 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-800">
                  Compliance Protocol
                </label>
                <input
                  type="text"
                  value={standard}
                  onChange={e => setStandard(e.target.value)}
                  className="w-full h-9 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-800">
                Authorized Hardware / Bus
              </label>
              <input
                type="text"
                value={hardwareDevice}
                onChange={e => setHardwareDevice(e.target.value)}
                className="w-full h-9 px-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-800">
                Justification &amp; Handling Details <span className="text-rose-600">*</span>
              </label>
              <textarea
                value={details}
                onChange={e => setDetails(e.target.value)}
                rows={3}
                placeholder="Specify purpose, physical custody transfer location, and hash verification..."
                className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-600 resize-none"
              />
            </div>
          </div>

          {/* Footer */}
          <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2.5">
            <button
              onClick={() => setCustodyModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              type="button"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs flex items-center gap-2 disabled:opacity-50 cursor-pointer transition-colors"
            >
              <span className="material-symbols-outlined text-[16px]">save</span>
              <span>{isSubmitting ? 'Recording Event...' : 'Commit Custody Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
