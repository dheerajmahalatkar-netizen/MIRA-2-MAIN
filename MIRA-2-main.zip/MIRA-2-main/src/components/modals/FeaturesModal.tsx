import React from 'react';
import { PageRoute } from '../../types/forensic';

interface FeaturesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: PageRoute) => void;
}

export const FeaturesModal: React.FC<FeaturesModalProps> = ({ isOpen, onClose, onNavigate }) => {
  if (!isOpen) return null;

  const features = [
    {
      route: 'evidence-intake' as PageRoute,
      icon: 'upload_file',
      title: 'Upload & Analyze',
      category: 'Evidence Intake',
      description: 'Stage physical dd/raw bitstream snapshots, compute dual SHA-256/MD5 hashes, and assign ISO/IEC 27037 custody identifiers before analysis.',
      badge: 'Acquisition',
      color: 'from-blue-500/20 to-blue-600/10 border-blue-500/30 text-blue-400',
    },
    {
      route: 'relationship-graph' as PageRoute,
      icon: 'hub',
      title: 'Find Relationships',
      category: 'Neural Link Graph',
      description: 'Interactive topological graph linking isolated sectors, fragments, and reconstructed files with edge continuity confidence scores.',
      badge: 'Graph Heuristics',
      color: 'from-cyan-500/20 to-cyan-600/10 border-cyan-500/30 text-cyan-400',
    },
    {
      route: 'reconstruction' as PageRoute,
      icon: 'extension',
      title: 'Reconstruct Files',
      category: 'Fragment Carving',
      description: 'Rebuild partial or non-contiguous file structures with explainable provenance: observed magic headers, inferred links, and verified bitstreams.',
      badge: 'Carving Engine',
      color: 'from-indigo-500/20 to-indigo-600/10 border-indigo-500/30 text-indigo-400',
    },
    {
      route: 'sectors' as PageRoute,
      icon: 'verified_user',
      title: 'Assess Integrity',
      category: 'Sector Matrix',
      description: 'Interactive heat-map of 512+ LBA sectors colored by Shannon entropy (Sparse, Structured Text, Binary Structures, and Encrypted Remnants).',
      badge: 'Entropy Heatmap',
      color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/30 text-emerald-400',
    },
    {
      route: 'evidence-explorer' as PageRoute,
      icon: 'fact_check',
      title: 'Prioritize & Explore',
      category: 'Evidence Dossier',
      description: 'Search, filter, and inspect recovered artifacts by triage priority (Critical, High, Medium, Low), hex view rows, and download reconstructed streams.',
      badge: 'Hex & Inspector',
      color: 'from-purple-500/20 to-purple-600/10 border-purple-500/30 text-purple-400',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-3xl bg-[#0F172A] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-white animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <span className="material-symbols-outlined text-[20px]">auto_awesome</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">MIRA Forensic Capabilities</h3>
              <p className="text-xs text-slate-400">Complete suite of digital forensic analysis tools</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Feature Grid */}
        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[70vh] overflow-y-auto">
          {features.map(f => (
            <div
              key={f.route}
              onClick={() => {
                onClose();
                onNavigate(f.route);
              }}
              className="p-4 rounded-xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${f.color} flex items-center justify-center border shadow-xs`}>
                    <span className="material-symbols-outlined text-[20px]">{f.icon}</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                    {f.badge}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">{f.category}</span>
                  <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">{f.title}</h4>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {f.description}
                </p>
              </div>

              <div className="flex items-center justify-between text-xs font-semibold text-blue-400 group-hover:text-cyan-300 pt-2 border-t border-slate-800/60">
                <span>Launch Tool</span>
                <span className="material-symbols-outlined text-[16px] transform group-hover:translate-x-1 transition-transform">arrow_forward</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <span className="text-xs font-mono text-slate-400">All tools operate under read-only write-block</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
};
