import React from 'react';
import { PageRoute } from '../../types/forensic';

export interface FloatingFragmentData {
  id: string;
  name: string;
  type: string;
  sectorLba: number;
  offsetHex: string;
  entropy: number;
  magicBytes: string;
  preview: string;
  score: number;
  category: string;
}

interface FragmentInspectModalProps {
  fragment: FloatingFragmentData | null;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: PageRoute) => void;
}

export const FragmentInspectModal: React.FC<FragmentInspectModalProps> = ({
  fragment,
  isOpen,
  onClose,
  onNavigate,
}) => {
  if (!isOpen || !fragment) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl bg-[#0F172A] border border-cyan-500/40 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.2)] overflow-hidden text-white animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Hologram Scanner Bar */}
        <div className="h-1 w-full bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse" />

        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center font-mono font-bold text-xs">
              LBA
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white font-mono">{fragment.name}</h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                  {fragment.category}
                </span>
              </div>
              <p className="text-xs text-slate-400">Sector Offset: {fragment.offsetHex} (LBA #{fragment.sectorLba})</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Telemetry Grid */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Shannon Entropy</span>
              <span className="text-lg font-bold text-cyan-300 font-mono">{fragment.entropy} H</span>
              <span className="text-[10px] text-slate-400 block">Structured Block</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Continuity Score</span>
              <span className="text-lg font-bold text-emerald-400 font-mono">{Math.round(fragment.score * 100)}%</span>
              <span className="text-[10px] text-slate-400 block">Neural Alignment</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Sector Size</span>
              <span className="text-lg font-bold text-white font-mono">4,096 B</span>
              <span className="text-[10px] text-slate-400 block">Standard Block</span>
            </div>
          </div>

          {/* Magic Signature Box */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono uppercase text-slate-400">Magic Byte Pattern</span>
            <div className="font-mono text-xs text-amber-300 bg-slate-950 px-2.5 py-1.5 rounded border border-slate-800 flex items-center justify-between">
              <span>{fragment.magicBytes}</span>
              <span className="text-[10px] text-emerald-400 font-sans">Verified Signature</span>
            </div>
          </div>

          {/* Hex & ASCII View Snippet */}
          <div className="space-y-1">
            <span className="text-[10px] font-mono uppercase text-slate-400">Fragment Content Sample</span>
            <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 whitespace-pre-wrap leading-relaxed max-h-36 overflow-y-auto">
              {fragment.preview}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <span className="text-xs font-mono text-slate-400">State: Candidate Fragment Linked</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
            >
              Dismiss
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onNavigate('reconstruction');
              }}
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <span>Examine in Reconstruction Flow</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
