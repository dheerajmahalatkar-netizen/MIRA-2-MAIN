import React from 'react';
import { useForensic } from '../../context/ForensicContext';

export const PdfPreviewModal: React.FC = () => {
  const { pdfModalOpen, setPdfModalOpen, currentCase, custodyHistory, exportCustodyPdf } = useForensic();

  if (!pdfModalOpen || !currentCase) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden text-slate-900">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shadow-xs">
              <span className="material-symbols-outlined text-[18px]">picture_as_pdf</span>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Chain of Custody Record (ISO/IEC 27037-Aligned)
              </h3>
              <p className="text-[11px] text-slate-500">
                Document preview for evidentiary attestation and legal verification
              </p>
            </div>
          </div>
          <button
            onClick={() => setPdfModalOpen(false)}
            className="text-slate-400 hover:text-slate-700 p-1 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Scrollable Preview Container styled like real certificate */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-100">
          <div className="bg-white text-slate-900 p-8 rounded-lg shadow-sm border border-slate-200 font-sans space-y-6 text-xs max-w-xl mx-auto">
            {/* Top Color Accent */}
            <div className="h-1.5 bg-blue-600 rounded-t -mx-8 -mt-8 mb-6"></div>

            {/* MIRA Document Header */}
            <div className="flex items-start justify-between border-b border-slate-200 pb-4">
              <div>
                <h1 className="text-xl font-bold tracking-tight text-slate-900">
                  MIRA DIGITAL FORENSICS
                </h1>
                <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mt-0.5">
                  Evidentiary Chain of Custody Record · ISO/IEC 27037-Aligned Workflow
                </p>
              </div>
              <div className="text-right text-[10px] font-mono text-slate-500 space-y-0.5">
                <div>DOC ID: COC-GEN-2026</div>
                <div>DATE: {new Date().toUTCString().slice(0, 22)} UTC</div>
              </div>
            </div>

            {/* Evidence Identification Box */}
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                1. Evidence Identification &amp; Acquisition Parameters
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500 block">Case ID:</span>
                  <span className="font-mono font-bold text-slate-900">{currentCase.id}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Examiner:</span>
                  <span className="font-semibold text-slate-800">{currentCase.examiner}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Source Description:</span>
                  <span className="font-medium text-slate-800">{currentCase.title}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Acquisition Station:</span>
                  <span className="font-mono text-slate-800">{currentCase.stationId}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Calculated Drive Size:</span>
                  <span className="font-semibold text-emerald-700">{currentCase.driveSizeFormatted}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Acquisition Method:</span>
                  <span className="text-slate-800">Physical Write-Blocked (Tableau T8u)</span>
                </div>
              </div>
            </div>

            {/* Cryptographic Verification Box */}
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                2. Cryptographic Integrity Attestation
              </div>
              <div className="space-y-1 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500 block text-[10px]">PRIMARY SHA-256 BITSTREAM HASH:</span>
                  <span className="text-blue-700 font-semibold break-all select-all">{currentCase.sha256}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">CORROBORATING MD5 CHECKSUM:</span>
                  <span className="text-slate-800 select-all">{currentCase.md5}</span>
                </div>
                <div className="pt-1 text-emerald-700 font-sans font-semibold text-[11px] flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">verified</span>
                  <span>Forensic bitstream verification status: MATCH CONFIRMED (Zero deviation)</span>
                </div>
              </div>
            </div>

            {/* Chronological Event History */}
            <div className="space-y-2">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                3. Chronological Custody Entries ({custodyHistory.length} Recorded)
              </div>
              <div className="space-y-2">
                {custodyHistory.map((item, idx) => (
                  <div key={item.id || idx} className="p-3 bg-slate-50 rounded border border-slate-200 text-[11px] space-y-1">
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-slate-900">{item.action}</span>
                      <span className="text-slate-500 font-mono text-[10px]">{item.timestamp}</span>
                    </div>
                    <div className="text-slate-600">{item.details}</div>
                    <div className="text-[10px] text-slate-500 font-mono flex items-center justify-between pt-1 border-t border-slate-200">
                      <span>Operator: {item.operator}</span>
                      <span className="text-emerald-700 font-semibold">Standard: {item.standard}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Sign-off Seal */}
            <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-[11px]">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Examiner Attestation</span>
                <span className="font-bold text-slate-900">{currentCase.examiner}</span>
                <span className="text-slate-500 block text-[10px]">{currentCase.examinerRole}</span>
              </div>
              <div className="text-right">
                <span className="text-slate-500 block text-[10px] uppercase">Compliance Seal</span>
                <span className="font-bold text-emerald-700">ISO/IEC 27037-ALIGNED</span>
                <span className="text-slate-500 block text-[10px]">CRYPTOGRAPHIC VERIFICATION PASS</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2.5 shrink-0">
          <button
            onClick={() => setPdfModalOpen(false)}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
            type="button"
          >
            Close Preview
          </button>
          <button
            onClick={() => {
              exportCustodyPdf();
              setPdfModalOpen(false);
            }}
            className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs flex items-center gap-2 cursor-pointer transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">download</span>
            <span>Download Formatted PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
