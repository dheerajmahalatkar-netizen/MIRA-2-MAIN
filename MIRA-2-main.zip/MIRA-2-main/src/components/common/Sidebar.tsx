import React from 'react';
import { useForensic } from '../../context/ForensicContext';
import { PageRoute } from '../../types/forensic';
import { MiraLogo } from './MiraLogo';

interface NavItem {
  id: PageRoute;
  label: string;
  icon: string;
  badge?: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: 'dashboard' },
  { id: 'evidence-intake', label: 'Evidence Intake', icon: 'upload_file' },
  { id: 'recovery-analysis', label: 'Recovery Analysis', icon: 'search' },
  { id: 'reconstruction', label: 'Reconstruction', icon: 'extension' },
  { id: 'evidence-explorer', label: 'Evidence Explorer', icon: 'folder' },
  { id: 'relationship-graph', label: 'Relationship Graph', icon: 'hub' },
  { id: 'timeline', label: 'Timeline', icon: 'schedule' },
  { id: 'ai-insights', label: 'AI Insights', icon: 'psychology' },
  { id: 'reports', label: 'Reports', icon: 'description' },
];

interface SidebarProps {
  onOpenIntro?: () => void;
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenIntro, mobileOpen, onCloseMobile }) => {
  const { activeRoute, setActiveRoute, systemStatus } = useForensic();

  const handleNavClick = (id: PageRoute) => {
    setActiveRoute(id);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-950/70 backdrop-blur-sm lg:hidden transition-opacity"
        />
      )}

      <aside
        className={`fixed left-0 top-0 h-full w-60 bg-white/95 dark:bg-[#070A12]/95 backdrop-blur-md border-r border-slate-200 dark:border-slate-800/80 z-50 flex flex-col justify-between select-none transition-all duration-300 ease-in-out shadow-lg lg:shadow-none ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex flex-col">
          {/* Brand Logo matching user screenshot */}
          <div className="p-4 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
            <div
              onClick={onOpenIntro}
              className="cursor-pointer group hover:opacity-90 transition-opacity"
              title="Return to MIRA 3D Home Portal"
            >
              <MiraLogo size={32} showSubtitle={true} />
            </div>

            {/* Close button on mobile */}
            {onCloseMobile && (
              <button
                type="button"
                onClick={onCloseMobile}
                className="lg:hidden p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            )}
          </div>

          {/* Navigation List */}
          <div className="px-3 py-3">
            <nav className="space-y-1">
              {/* Home Portal Button */}
              {onOpenIntro && (
                <button
                  type="button"
                  onClick={onOpenIntro}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-800/80 hover:text-blue-600 dark:hover:text-cyan-400 transition-all text-left cursor-pointer mb-2 border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 shadow-2xs group"
                  title="Open MIRA 3D Holographic Portal"
                >
                  <span className="material-symbols-outlined text-[19px] text-blue-600 dark:text-cyan-400 group-hover:scale-110 transition-transform">
                    home
                  </span>
                  <span className="font-bold">Home Portal</span>
                  <span className="ml-auto text-[9px] font-mono px-1.5 py-0.2 rounded bg-blue-100 dark:bg-cyan-950 text-blue-700 dark:text-cyan-300 font-bold border border-blue-200 dark:border-cyan-800">
                    3D
                  </span>
                </button>
              )}

              {NAV_ITEMS.map(item => {
                const isActive =
                  activeRoute === item.id ||
                  (item.id === 'recovery-analysis' && activeRoute === 'sectors') ||
                  (item.id === 'reconstruction' && activeRoute === 'lab') ||
                  (item.id === 'reports' && activeRoute === 'report');

                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold transition-all text-left cursor-pointer group relative ${
                      isActive
                        ? 'bg-gradient-to-r from-blue-600/10 to-indigo-600/10 dark:from-cyan-500/15 dark:to-blue-600/15 text-blue-600 dark:text-cyan-400 font-bold border border-blue-200/80 dark:border-cyan-500/30 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200 border border-transparent'
                    }`}
                  >
                    {isActive && (
                      <span className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-gradient-to-b from-cyan-400 to-blue-600 rounded-r shadow-[0_0_8px_#38BDF8]" />
                    )}
                    <span
                      className={`material-symbols-outlined text-[19px] transition-transform group-hover:scale-110 ${
                        isActive ? 'text-blue-600 dark:text-cyan-400' : 'text-slate-400 dark:text-slate-500'
                      }`}
                    >
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Sidebar Bottom: System Status & User Profile */}
        <div className="border-t border-slate-100 dark:border-slate-800/80 bg-white/60 dark:bg-[#070A12]/60 p-3 space-y-2.5">
          {/* System Status Section matching screenshot */}
          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800 space-y-1.5 text-[11px]">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 block mb-0.5">
              Engine Status
            </span>
            <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
              <span className="text-[11px]">Recovery Engine</span>
              <span className="inline-flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400 text-[10px]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Online
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
              <span className="text-[11px]">AI Analyzer</span>
              <span className="inline-flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400 text-[10px]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Active
              </span>
            </div>
          </div>

          {/* User Profile Card */}
          <div
            onClick={onOpenIntro}
            className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-700/80"
            title="Examiner profile (Click to view Entrance Portal)"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-7 h-7 rounded-full bg-slate-900 dark:bg-cyan-950 text-white dark:text-cyan-300 flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs border border-cyan-800/60">
                A
              </div>
              <div className="min-w-0">
                <span className="font-bold text-xs text-slate-900 dark:text-white block truncate leading-tight">
                  Lead Examiner
                </span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono truncate block">
                  Abhishek · WS-04
                </span>
              </div>
            </div>
            <span className="material-symbols-outlined text-[16px] text-slate-400">
              chevron_right
            </span>
          </div>
        </div>
      </aside>
    </>
  );
};
