import React from 'react';
import { useForensic } from '../../context/ForensicContext';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useForensic();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 pointer-events-none max-w-md">
      {toasts.map(toast => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';
        const isWarning = toast.type === 'warning';

        return (
          <div
            key={toast.id}
            id="toast-msg"
            className={`pointer-events-auto bg-white text-slate-800 px-4 py-2.5 rounded-lg shadow-xl text-xs font-medium flex items-center gap-2.5 transition-all transform duration-200 border ${
              isError
                ? 'border-rose-200 bg-rose-50/90 text-rose-800'
                : isSuccess
                ? 'border-emerald-200 bg-emerald-50/90 text-emerald-800'
                : isWarning
                ? 'border-amber-200 bg-amber-50/90 text-amber-800'
                : 'border-slate-200 shadow-md'
            }`}
          >
            <span
              className={`material-symbols-outlined text-[17px] shrink-0 ${
                isError
                  ? 'text-rose-600'
                  : isSuccess
                  ? 'text-emerald-600'
                  : isWarning
                  ? 'text-amber-600'
                  : 'text-blue-600'
              }`}
            >
              {isError
                ? 'error'
                : isSuccess
                ? 'verified'
                : isWarning
                ? 'warning'
                : 'info'}
            </span>
            <span className="flex-1 leading-snug">{toast.message}</span>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
              aria-label="Dismiss"
            >
              <span className="material-symbols-outlined text-[15px]">close</span>
            </button>
          </div>
        );
      })}
    </div>
  );
};
