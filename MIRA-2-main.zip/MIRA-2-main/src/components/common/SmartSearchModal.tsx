import React, { useState, useEffect } from 'react';
import { useForensic } from '../../context/ForensicContext';
import {
  DEFAULT_AI_FINDINGS,
  DEFAULT_TIMELINE_EVENTS,
  DEFAULT_GRAPH_NODES,
  DEFAULT_FRAGMENT_PIPELINES,
} from '../../data/forensicIntelligenceData';
import { PageRoute } from '../../types/forensic';

interface SmartSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SearchResult {
  id: string;
  title: string;
  subtitle: string;
  category: 'Finding' | 'Evidence' | 'Fragment' | 'Event' | 'Risk';
  route: PageRoute;
  badge: string;
  confidence?: number;
}

export const SmartSearchModal: React.FC<SmartSearchModalProps> = ({ isOpen, onClose }) => {
  const { setActiveRoute, reconstructedFiles } = useForensic();
  const [query, setQuery] = useState('');

  const sampleQueries = [
    'Show high-confidence findings',
    'Find evidence from yesterday',
    'Show fragments connected to this file',
    'Critical risk alerts',
  ];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Search logic across findings, reconstructed files, timeline events, fragments
  const getResults = (): SearchResult[] => {
    const q = query.toLowerCase().trim();

    const results: SearchResult[] = [];

    // Check query intents
    const isHighConfQuery = q.includes('high') && (q.includes('confidence') || q.includes('finding'));
    const isYesterdayQuery = q.includes('yesterday') || q.includes('date') || q.includes('time') || q.includes('earlier');
    const isFragmentQuery = q.includes('fragment') || q.includes('connect');
    const isRiskQuery = q.includes('risk') || q.includes('alert') || q.includes('critical') || q.includes('anomal');

    // 1. Reconstructed files
    reconstructedFiles.forEach(file => {
      if (
        q === '' ||
        file.fileName.toLowerCase().includes(q) ||
        file.fileType.toLowerCase().includes(q) ||
        (isHighConfQuery && file.confidence >= 90) ||
        (isFragmentQuery && file.fileName.includes('financial'))
      ) {
        results.push({
          id: file.id,
          title: file.fileName,
          subtitle: `${file.fileType} · ${file.size} · ${file.sha256?.substring(0, 16)}...`,
          category: 'Evidence',
          route: 'evidence-explorer',
          badge: `${file.confidence}% Confidence`,
          confidence: file.confidence,
        });
      }
    });

    // 2. AI Findings
    DEFAULT_AI_FINDINGS.forEach(finding => {
      if (
        q === '' ||
        finding.title.toLowerCase().includes(q) ||
        finding.explanation.toLowerCase().includes(q) ||
        (isHighConfQuery && finding.confidence >= 90) ||
        (isRiskQuery && (finding.importance === 'CRITICAL' || finding.category === 'risk'))
      ) {
        results.push({
          id: finding.id,
          title: finding.title,
          subtitle: finding.explanation,
          category: finding.category === 'risk' ? 'Risk' : 'Finding',
          route: 'ai-insights',
          badge: `${finding.importance} (${finding.confidence}%)`,
          confidence: finding.confidence,
        });
      }
    });

    // 3. Timeline Events
    DEFAULT_TIMELINE_EVENTS.forEach(event => {
      if (
        q === '' ||
        event.title.toLowerCase().includes(q) ||
        event.description.toLowerCase().includes(q) ||
        isYesterdayQuery
      ) {
        results.push({
          id: event.id,
          title: `${event.time} — ${event.title}`,
          subtitle: event.description,
          category: 'Event',
          route: 'timeline',
          badge: event.stage.replace('_', ' ').toUpperCase(),
          confidence: event.confidence,
        });
      }
    });

    return results.slice(0, 8);
  };

  const results = getResults();

  const handleSelect = (result: SearchResult) => {
    setActiveRoute(result.route);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-2xl w-full overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3 bg-slate-50/50">
          <span className="material-symbols-outlined text-[22px] text-blue-600">
            search
          </span>
          <input
            autoFocus
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Natural language search: 'Show high-confidence findings', 'Find evidence from yesterday'..."
            className="flex-1 bg-transparent text-sm text-slate-900 focus:outline-none placeholder:text-slate-400 font-medium"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="text-slate-400 hover:text-slate-600 text-xs px-1.5 py-0.5"
            >
              Clear
            </button>
          )}
          <span className="text-[10px] font-mono text-slate-400 border border-slate-200 bg-white px-2 py-0.5 rounded shadow-2xs">
            ESC
          </span>
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-4 py-2 bg-white border-b border-slate-100 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-[11px] text-slate-400 font-medium shrink-0">Try:</span>
          {sampleQueries.map((s, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setQuery(s)}
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 text-[11px] font-medium transition-colors cursor-pointer shrink-0"
            >
              {s}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-[420px] overflow-y-auto p-2 divide-y divide-slate-100 text-xs">
          {results.length === 0 ? (
            <div className="p-8 text-center text-slate-400 space-y-1">
              <span className="material-symbols-outlined text-[32px] text-slate-300">
                search_off
              </span>
              <p className="font-medium text-slate-600">No matching forensic results found</p>
              <p className="text-[11px]">Try queries like "high confidence", "sqlite", or "fragments".</p>
            </div>
          ) : (
            results.map(res => (
              <div
                key={res.id}
                onClick={() => handleSelect(res)}
                className="p-3 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                      res.category === 'Evidence'
                        ? 'bg-emerald-50 text-emerald-600'
                        : res.category === 'Finding'
                        ? 'bg-blue-50 text-blue-600'
                        : res.category === 'Risk'
                        ? 'bg-rose-50 text-rose-600'
                        : 'bg-purple-50 text-purple-600'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[16px]">
                      {res.category === 'Evidence'
                        ? 'folder'
                        : res.category === 'Finding'
                        ? 'psychology'
                        : res.category === 'Risk'
                        ? 'warning'
                        : 'schedule'}
                    </span>
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">
                        {res.title}
                      </h4>
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded">
                        {res.category}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate max-w-lg mt-0.5">
                      {res.subtitle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-50 border border-slate-200 text-slate-700">
                    {res.badge}
                  </span>
                  <span className="material-symbols-outlined text-[16px] text-slate-300 group-hover:text-blue-600 transition-colors">
                    arrow_forward
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span>Natural Language Contextual Search Engine</span>
          <span className="font-mono text-[10px]">MIRA Heuristic Index v2</span>
        </div>
      </div>
    </div>
  );
};
