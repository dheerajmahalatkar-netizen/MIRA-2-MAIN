import React, { useState } from 'react';
import { useForensic } from '../../context/ForensicContext';
import { SmartSearchModal } from './SmartSearchModal';
import { FinalReportModal } from '../modals/FinalReportModal';
import { LiveProcessingModal } from '../modals/LiveProcessingModal';
import { HardwareBridgeModal } from '../modals/HardwareBridgeModal';

interface HeaderProps {
  onOpenIntro?: () => void;
  onToggleMobileNav?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenIntro, onToggleMobileNav }) => {
  const {
    activeRoute,
    setActiveRoute,
    loadDemo,
    theme,
    toggleTheme,
    currentCase,
  } = useForensic();

  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isProcessingOpen, setIsProcessingOpen] = useState(false);
  const [isBridgeModalOpen, setIsBridgeModalOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  // Compute page display title from active route
  const getPageTitle = () => {
    switch (activeRoute) {
      case 'evidence-intake':
        return 'Evidence Intake';
      case 'recovery-analysis':
      case 'sectors':
        return 'Recovery Analysis & LBA Map';
      case 'reconstruction':
      case 'lab':
        return 'Fragment Reconstruction Engine';
      case 'evidence-explorer':
        return 'Evidence Explorer & Dossier';
      case 'relationship-graph':
        return 'Relationship Graph & Topological Links';
      case 'timeline':
        return 'Chronological Timeline Reconstruction';
      case 'ai-insights':
        return 'AI Evidentiary Insights';
      case 'reports':
      case 'report':
        return 'Audit Reports & Attestations';
      case 'overview':
      default:
        return 'Investigation Command Overview';
    }
  };

  const handleProcessingComplete = async () => {
    setIsProcessingOpen(false);
    await loadDemo();
  };

  return (
    <>
      <header className="fixed top-0 right-0 left-0 lg:left-60 h-16 bg-white/90 dark:bg-[#090D16]/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800/80 z-40 flex items-center justify-between px-4 sm:px-6 select-none transition-colors duration-200 shadow-xs">
        {/* Left: Dynamic Page Title & Case Status */}
        <div className="flex items-center gap-3 min-w-0">
          {/* Mobile hamburger button */}
          {onToggleMobileNav && (
            <button
              type="button"
              onClick={onToggleMobileNav}
              className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="Toggle Navigation Menu"
            >
              <span className="material-symbols-outlined text-[22px]">menu</span>
            </button>
          )}

          <div className="flex flex-col justify-center min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-tight truncate">
                {getPageTitle()}
              </h2>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-0.5 truncate">
              <span className="text-cyan-600 dark:text-cyan-400 font-bold">{currentCase?.id || 'CASE-2026-091'}</span>
              <span className="text-slate-300 dark:text-slate-700">·</span>
              <span className="truncate hidden sm:inline">{currentCase?.deviceModel || 'Samsung SSD Image'}</span>
              <span className="text-slate-300 dark:text-slate-700 hidden sm:inline">·</span>
              <span className="inline-flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Active Intake</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right: Search, Theme Toggle, Notification Bell, User Avatar */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Smart Search Bar with ⌘ K */}
          <div
            onClick={() => setIsSearchOpen(true)}
            className="hidden md:flex items-center gap-2.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer transition-all w-52 lg:w-64 hover:border-cyan-500/50"
            title="Search evidence, fragments, files... (Cmd+K)"
          >
            <span className="material-symbols-outlined text-[17px] text-slate-400">search</span>
            <span className="flex-1 text-[11px] truncate">
              Search evidence, fragments...
            </span>
            <kbd className="text-[10px] font-mono bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1.5 py-0.5 text-slate-500 dark:text-slate-400 shadow-2xs">
              ⌘ K
            </kbd>
          </div>

          {/* Quick Final Report Action Button */}
          <button
            type="button"
            onClick={() => setIsReportOpen(true)}
            className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/80 text-blue-700 dark:text-cyan-300 border border-blue-200 dark:border-blue-800/80 text-xs font-semibold rounded-lg transition-all cursor-pointer shadow-xs"
            title="Generate & View Court-Admissible Dossier"
          >
            <span className="material-symbols-outlined text-[15px]">summarize</span>
            <span>Final Report</span>
          </button>

          {/* Visible Light / Dark Theme Toggle */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-900/90 p-0.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => {
                if (theme !== 'light') toggleTheme();
              }}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
                theme === 'light'
                  ? 'bg-white text-blue-600 font-bold shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
              title="Switch to Light Theme"
            >
              <span className="material-symbols-outlined text-[14px]">light_mode</span>
              <span className="hidden sm:inline">Light</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (theme !== 'dark') toggleTheme();
              }}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
                theme === 'dark'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
              title="Switch to Dark Workstation Theme"
            >
              <span className="material-symbols-outlined text-[14px]">dark_mode</span>
              <span className="hidden sm:inline">Dark</span>
            </button>
          </div>

          {/* Notification Bell with red dot badge */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsReportOpen(true)}
              className="w-8 h-8 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
              title="Forensic Integrity & Risk Notifications"
            >
              <span className="material-symbols-outlined text-[20px]">notifications</span>
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-900 animate-pulse"></span>
            </button>
          </div>

          {/* User Profile Avatar with Abhishek Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsUserMenuOpen(prev => !prev)}
              className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer select-none"
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs ring-1 ring-cyan-400/40">
                A
              </div>
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 hidden sm:inline">
                Abhishek
              </span>
              <span className="material-symbols-outlined text-[15px] text-slate-400">
                arrow_drop_down
              </span>
            </button>

            {/* Dropdown Menu */}
            {isUserMenuOpen && (
              <div
                className="absolute right-0 mt-2 w-52 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 z-50 text-xs animate-in fade-in zoom-in-95 duration-150"
                onClick={() => setIsUserMenuOpen(false)}
              >
                <div className="px-3.5 py-2.5 border-b border-slate-100 dark:border-slate-800">
                  <div className="font-bold text-slate-900 dark:text-white">Abhishek</div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">Lead Forensic Examiner</div>
                  <div className="text-[9px] text-cyan-600 dark:text-cyan-400 font-mono mt-0.5">Station: WS-EVIDENCE-04</div>
                </div>

                {onOpenIntro && (
                  <button
                    type="button"
                    onClick={onOpenIntro}
                    className="w-full text-left px-3.5 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer font-medium"
                  >
                    <span className="material-symbols-outlined text-[16px] text-blue-600 dark:text-cyan-400">home</span>
                    <span>Return to Home Portal</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setIsProcessingOpen(true)}
                  className="w-full text-left px-3.5 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer font-medium"
                >
                  <span className="material-symbols-outlined text-[16px] text-emerald-600 dark:text-emerald-400">play_circle</span>
                  <span>Run Live Simulation</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsBridgeModalOpen(true)}
                  className="w-full text-left px-3.5 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer font-medium"
                >
                  <span className="material-symbols-outlined text-[16px] text-indigo-600 dark:text-indigo-400">router</span>
                  <span>Hardware Write-Blocker</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsReportOpen(true)}
                  className="w-full text-left px-3.5 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer font-medium border-t border-slate-100 dark:border-slate-800"
                >
                  <span className="material-symbols-outlined text-[16px] text-blue-600 dark:text-cyan-400">description</span>
                  <span>Export Final Report</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Modals */}
      <SmartSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />
      <FinalReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
      />
      <LiveProcessingModal
        isOpen={isProcessingOpen}
        onComplete={handleProcessingComplete}
        title="Processing Forensic Image"
      />
      <HardwareBridgeModal
        isOpen={isBridgeModalOpen}
        onClose={() => setIsBridgeModalOpen(false)}
      />
    </>
  );
};
