import React, { useState } from 'react';
import { DEFAULT_ANOMALY_ALERTS } from '../../data/forensicIntelligenceData';
import { AnomalyRiskAlert, PageRoute } from '../../types/forensic';
import { useForensic } from '../../context/ForensicContext';

interface AnomalyRiskBannerProps {
  compact?: boolean;
}

export const AnomalyRiskBanner: React.FC<AnomalyRiskBannerProps> = ({ compact = false }) => {
  const { setActiveRoute } = useForensic();
  const [alerts, setAlerts] = useState<AnomalyRiskAlert[]>(DEFAULT_ANOMALY_ALERTS);
  const [isExpanded, setIsExpanded] = useState(!compact);

  const activeAlerts = alerts.filter(a => !a.dismissed);

  if (activeAlerts.length === 0) return null;

  const handleDismiss = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setAlerts(prev => prev.map(a => (a.id === id ? { ...a, dismissed: true } : a)));
  };

  const handleAction = (alert: AnomalyRiskAlert) => {
    if (alert.actionRoute) {
      setActiveRoute(alert.actionRoute);
    }
  };

  const getAlertIcon = (type: AnomalyRiskAlert['type']) => {
    switch (type) {
      case 'unusual_timestamp':
        return { icon: 'schedule', color: 'text-amber-500', bg: 'bg-amber-50', border: 'border-amber-200' };
      case 'high_priority_evidence':
        return { icon: 'emergency', color: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-200' };
      case 'incomplete_reconstruction':
        return { icon: 'warning', color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' };
      case 'strong_correlation':
        return { icon: 'check_circle', color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' };
      default:
        return { icon: 'info', color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' };
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all duration-200">
      {/* Header Bar */}
      <div
        onClick={() => setIsExpanded(prev => !prev)}
        className="px-4 py-2.5 flex items-center justify-between cursor-pointer hover:bg-slate-50 transition-colors bg-gradient-to-r from-white via-slate-50/50 to-white"
      >
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <span className="material-symbols-outlined text-[18px] text-amber-500">
              notification_important
            </span>
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
          </div>
          <span className="text-xs font-bold text-slate-900 tracking-tight">
            Forensic Risk &amp; Anomaly Alerts
          </span>
          <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200">
            {activeAlerts.length} Active
          </span>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="text-[11px] hidden sm:inline">
            {isExpanded ? 'Collapse' : 'Inspect alerts'}
          </span>
          <span
            className={`material-symbols-outlined text-[18px] transition-transform duration-200 ${
              isExpanded ? 'rotate-180' : ''
            }`}
          >
            expand_more
          </span>
        </div>
      </div>

      {/* Expanded Alert List */}
      {isExpanded && (
        <div className="p-4 pt-1 border-t border-slate-100 divide-y divide-slate-100">
          {activeAlerts.map(alert => {
            const styling = getAlertIcon(alert.type);

            return (
              <div
                key={alert.id}
                className="py-3 first:pt-2 last:pb-1 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-7 h-7 rounded-lg ${styling.bg} ${styling.border} border ${styling.color} flex items-center justify-center shrink-0 mt-0.5`}
                  >
                    <span className="material-symbols-outlined text-[16px]">{styling.icon}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900">{alert.title}</span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {alert.timestamp}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed mt-0.5 max-w-3xl">
                      {alert.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  {alert.actionLabel && (
                    <button
                      type="button"
                      onClick={() => handleAction(alert)}
                      className="px-2.5 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <span>{alert.actionLabel}</span>
                      <span className="material-symbols-outlined text-[13px]">arrow_forward</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={e => handleDismiss(alert.id, e)}
                    className="p-1 text-slate-400 hover:text-slate-600 rounded transition-colors cursor-pointer"
                    title="Dismiss alert"
                  >
                    <span className="material-symbols-outlined text-[16px]">close</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
