import React from 'react';

interface MiraLogoProps {
  className?: string;
  size?: number; // icon size in px
  showText?: boolean;
  showSubtitle?: boolean;
  showTagline?: boolean;
  textColor?: string;
}

export const MiraLogo: React.FC<MiraLogoProps> = ({
  className = '',
  size = 36,
  showText = true,
  showSubtitle = true,
  showTagline = false,
  textColor = 'text-slate-900',
}) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Exact MIRA SVG Icon matching uploaded branding image */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 drop-shadow-xs transition-transform duration-300 hover:scale-105"
      >
        <defs>
          {/* Main Ribbon Gradients */}
          <linearGradient id="miraRibbonLeft" x1="15" y1="20" x2="60" y2="90" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#2563EB" />
            <stop offset="50%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#6366F1" />
          </linearGradient>

          <linearGradient id="miraRibbonRight" x1="50" y1="30" x2="100" y2="85" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="50%" stopColor="#6366F1" />
            <stop offset="100%" stopColor="#8B5CF6" />
          </linearGradient>

          <linearGradient id="miraRibbonCenter" x1="30" y1="25" x2="80" y2="75" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#1D4ED8" />
            <stop offset="100%" stopColor="#7C3AED" />
          </linearGradient>

          {/* Mag Glass Gradient */}
          <linearGradient id="magRingGrad" x1="45" y1="50" x2="70" y2="75" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#1E293B" />
            <stop offset="100%" stopColor="#0F172A" />
          </linearGradient>

          <linearGradient id="pixelCubeGrad1" x1="90" y1="20" x2="105" y2="35" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="100%" stopColor="#2563EB" />
          </linearGradient>

          <linearGradient id="pixelCubeGrad2" x1="102" y1="28" x2="114" y2="40" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#60A5FA" />
            <stop offset="100%" stopColor="#3B82F6" />
          </linearGradient>

          <linearGradient id="pixelCubeGrad3" x1="88" y1="33" x2="100" y2="45" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#818CF8" />
            <stop offset="100%" stopColor="#6366F1" />
          </linearGradient>
        </defs>

        {/* 1. Left stem of Ribbon 'M' */}
        <path
          d="M 22 28 C 22 24 26 21 30 24 L 48 38 L 48 88 C 48 92 43 94 40 91 L 24 75 C 22 73 22 70 22 67 Z"
          fill="url(#miraRibbonLeft)"
        />

        {/* 2. Right stem of Ribbon 'M' */}
        <path
          d="M 72 38 L 90 24 C 94 21 98 24 98 28 L 98 67 C 98 70 96 73 94 75 L 78 91 C 75 94 70 92 70 88 Z"
          fill="url(#miraRibbonRight)"
        />

        {/* 3. Center fold of Ribbon 'M' */}
        <path
          d="M 48 38 L 60 52 L 72 38 L 86 52 L 60 78 L 34 52 Z"
          fill="url(#miraRibbonCenter)"
        />

        {/* 4. Three Floating Cyber Pixel Cubes on Top-Right */}
        <rect x="92" y="16" width="11" height="11" rx="2" fill="url(#pixelCubeGrad1)" />
        <rect x="105" y="24" width="9" height="9" rx="1.5" fill="url(#pixelCubeGrad2)" />
        <rect x="90" y="30" width="10" height="10" rx="2" fill="url(#pixelCubeGrad3)" />

        {/* 5. Center Magnifying Glass Lens & Handle */}
        <circle cx="58" cy="62" r="17" fill="white" stroke="url(#magRingGrad)" strokeWidth="4.5" />
        <path
          d="M 70 74 L 81 85"
          stroke="#0F172A"
          strokeWidth="5"
          strokeLinecap="round"
        />

        {/* 6. Three Audio/Forensic Signal Bars Inside Lens */}
        <line x1="52" y1="65" x2="52" y2="59" stroke="#0284C7" strokeWidth="2.8" strokeLinecap="round" />
        <line x1="58" y1="70" x2="58" y2="54" stroke="#0284C7" strokeWidth="2.8" strokeLinecap="round" />
        <line x1="64" y1="66" x2="64" y2="58" stroke="#0284C7" strokeWidth="2.8" strokeLinecap="round" />
      </svg>

      {/* Brand Typography */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center tracking-tight">
            <span className={`text-[19px] font-black tracking-wider font-sans leading-none ${textColor} dark:text-white`}>
              MIRA
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 ml-1.5 animate-pulse" />
          </div>

          {showSubtitle && (
            <span className="text-[9px] font-semibold tracking-[0.14em] text-slate-500 dark:text-slate-400 uppercase mt-0.5 truncate max-w-[210px]">
              Memory Intelligence &amp; Resource Analysis
            </span>
          )}

          {showTagline && (
            <span className="text-[11px] text-slate-500 dark:text-slate-400 tracking-normal mt-1 font-medium">
              Reconstruct What's Lost. Reveal What Matters.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
