import React, { useState, useRef, useEffect } from 'react';
import { useForensic } from '../../context/ForensicContext';
import { DEFAULT_AI_FINDINGS, DEFAULT_TIMELINE_EVENTS } from '../../data/forensicIntelligenceData';
import { PageRoute } from '../../types/forensic';

interface Message {
  id: string;
  sender: 'user' | 'mira';
  text: string;
  timestamp: string;
  citations?: Array<{ label: string; route: PageRoute; targetId?: string }>;
}

export const AskMiraAssistant: React.FC = () => {
  const { currentCase, artifacts, reconstructedFiles, setActiveRoute } = useForensic();
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-init',
      sender: 'mira',
      text: 'Hello, Examiner. I am MIRA (Machine Intelligence for Recovery and Analysis). I can answer inquiries regarding recovered fragments, confidence models, timeline events, and ISO/IEC 27037 chain-of-custody ledgers.',
      timestamp: 'Just now',
      citations: [
        { label: 'View Findings', route: 'ai-insights' },
        { label: 'Inspect Evidence', route: 'evidence-explorer' },
      ],
    },
  ]);

  const quickPrompts = [
    'What are the most important findings?',
    'Show evidence related to this file.',
    'What happened first?',
    'Which findings have high confidence?',
  ];

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || query;
    if (!text.trim()) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setQuery('');
    setIsTyping(true);

    const lower = text.toLowerCase();
    let citations: Message['citations'] = [];

    if (lower.includes('important') || lower.includes('key finding') || lower.includes('critical')) {
      citations = [
        { label: 'Inspect SQLite DB', route: 'evidence-explorer', targetId: 'REC-02' },
        { label: 'View AI Insights', route: 'ai-insights' },
        { label: 'Examine Token Slack', route: 'evidence-explorer', targetId: 'REC-03' },
      ];
    } else if (lower.includes('related to this file') || lower.includes('file') || lower.includes('fragment')) {
      citations = [
        { label: 'Reconstruction Flow', route: 'reconstruction' },
        { label: 'Relationship Graph', route: 'relationship-graph' },
      ];
    } else if (lower.includes('first') || lower.includes('timeline') || lower.includes('chronol') || lower.includes('happened')) {
      citations = [
        { label: 'Interactive Timeline', route: 'timeline' },
        { label: 'Chain of Custody', route: 'reports' },
      ];
    } else if (lower.includes('high confidence') || lower.includes('score') || lower.includes('meter')) {
      citations = [
        { label: 'AI Confidence Meter', route: 'ai-insights' },
        { label: 'Generate Final Report', route: 'reports' },
      ];
    } else {
      citations = [
        { label: 'Evidence Explorer', route: 'evidence-explorer' },
        { label: 'Relationship Graph', route: 'relationship-graph' },
      ];
    }

    try {
      const res = await fetch('/api/forensics/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text.trim() }),
      });
      const data = await res.json();
      if (data?.success && data?.data?.reply) {
        setMessages(prev => [
          ...prev,
          {
            id: `mira-${Date.now()}`,
            sender: 'mira',
            text: data.data.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            citations,
          },
        ]);
        setIsTyping(false);
        return;
      }
    } catch {
      // Network/server offline fallback handled below
    }

    let responseText = '';
    if (lower.includes('important') || lower.includes('key finding') || lower.includes('critical')) {
      responseText = `The most critical finding is **FND-001** (SQLite Database Fragment Cluster) at sectors #12-#14 with 96% confidence, alongside **FND-002** (High-Entropy Token Slack Space, H=7.84) containing unallocated authentication keys.`;
    } else if (lower.includes('related to this file') || lower.includes('file') || lower.includes('fragment')) {
      const topFile = reconstructedFiles[0]?.fileName || 'financial_records.xlsx';
      responseText = `For ${topFile}, MIRA identified 3 contiguous fragments: Fragment #01 (Zip Header at LBA #48), Fragment #02 (Deflate Streams at #49-#51), and Fragment #03 (Central Directory at #52-#53). All have CRC-32 consistency and 96% composite recovery confidence.`;
    } else if (lower.includes('first') || lower.includes('timeline') || lower.includes('chronol') || lower.includes('happened')) {
      const firstEvent = DEFAULT_TIMELINE_EVENTS[0];
      responseText = `Chronologically, the earliest event was **${firstEvent.title}** at **${firstEvent.time}** (${firstEvent.timestamp}), where the physical Seagate FireCuda drive was mounted via the Tableau T8u hardware write-blocker in Read-Only mode.`;
    } else if (lower.includes('high confidence') || lower.includes('score') || lower.includes('meter')) {
      const highConf = DEFAULT_AI_FINDINGS.filter(f => f.confidence >= 90);
      responseText = `MIRA currently holds ${highConf.length} findings with High Confidence (≥90%):\n1. Dual-Hash Cryptographic Digest: 100%\n2. SQLite DB B-Tree Cluster: 96%\n3. XLSX Financial Spreadsheet: 94%\n4. Unallocated Slack Token: 92%.\nAll scores are grounded in byte signatures and Shannon entropy continuity.`;
    } else {
      responseText = `Based on current local disk analysis for case ${currentCase?.id || 'CASE-2026-091'}: We have ${artifacts.length || 3} primary candidate artifacts reconstructed across 512 sectors with 100% bit-perfect integrity. You can inspect raw sector entropy, relationship trees, or generate an attestation dossier.`;
    }

    setMessages(prev => [
      ...prev,
      {
        id: `mira-${Date.now()}`,
        sender: 'mira',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        citations,
      },
    ]);
    setIsTyping(false);
  };

  return (
    <>
      {/* Floating Action Button */}
      <button
        type="button"
        onClick={() => setIsOpen(prev => !prev)}
        className="fixed bottom-6 right-6 z-40 bg-blue-600 hover:bg-blue-700 text-white rounded-full p-3.5 shadow-lg flex items-center gap-2 group transition-all duration-300 hover:scale-105 cursor-pointer ring-4 ring-blue-500/20"
        title="Open Ask Mira AI Assistant"
      >
        <span className="material-symbols-outlined text-[24px]">psychology</span>
        <span className="text-xs font-bold pr-1 hidden sm:inline">Ask MIRA</span>
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
      </button>

      {/* Slide-out / Floating Assistant Drawer */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 sm:right-6 w-[94vw] sm:w-[420px] max-h-[600px] h-[80vh] bg-white rounded-2xl border border-slate-200 shadow-2xl z-50 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Top Bar */}
          <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-xs font-mono shadow-xs">
                M
              </div>
              <div>
                <h3 className="text-xs font-bold tracking-wide">Ask MIRA Forensic Assistant</h3>
                <p className="text-[10px] text-slate-300">Local Evidentiary Intelligence</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="text-slate-300 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          </div>

          {/* Quick Prompt Pills */}
          <div className="p-2.5 bg-slate-50 border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto scrollbar-none text-[11px]">
            {quickPrompts.map((prompt, i) => (
              <button
                key={i}
                type="button"
                onClick={() => handleSend(prompt)}
                className="whitespace-nowrap px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-full text-slate-700 font-medium transition-colors cursor-pointer shrink-0 shadow-2xs"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs">
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-xl p-3 leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-blue-600 text-white rounded-br-none'
                      : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200/80 shadow-2xs'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.text}</p>

                  {/* Citations / Links */}
                  {msg.citations && msg.citations.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex flex-wrap gap-1.5">
                      <span className="text-[10px] text-slate-400 font-medium self-center">
                        Jump to:
                      </span>
                      {msg.citations.map((cite, cIdx) => (
                        <button
                          key={cIdx}
                          type="button"
                          onClick={() => {
                            setActiveRoute(cite.route);
                            setIsOpen(false);
                          }}
                          className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white text-blue-600 border border-slate-200 hover:border-blue-300 transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <span>{cite.label}</span>
                          <span className="material-symbols-outlined text-[11px]">arrow_outward</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <span className="text-[9px] text-slate-400 mt-1 font-mono px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-1.5 text-slate-400 p-2">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce"></div>
                <div
                  className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce"
                  style={{ animationDelay: '0.2s' }}
                ></div>
                <div
                  className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce"
                  style={{ animationDelay: '0.4s' }}
                ></div>
                <span className="text-[11px] ml-1">Analyzing case data...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Footer */}
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
          >
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Ask MIRA about evidence, findings..."
              className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500 placeholder:text-slate-400"
            />
            <button
              type="submit"
              disabled={!query.trim()}
              className="p-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <span className="material-symbols-outlined text-[18px]">send</span>
            </button>
          </form>
        </div>
      )}
    </>
  );
};
