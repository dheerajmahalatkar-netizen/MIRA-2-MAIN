import React, { useState } from 'react';

interface AiConfidenceMeterProps {
  confidence: number;
  whyExplanation?: string;
  size?: 'sm' | 'md' | 'lg';
  showWhyButton?: boolean;
}

export const AiConfidenceMeter: React.FC<AiConfidenceMeterProps> = ({
  confidence,
  whyExplanation,
  size = 'md',
  showWhyButton = true,
}) => {
  const [isWhyOpen, setIsWhyOpen] = useState(false);

  // Confidence tier
  const tier: 'High' | 'Medium' | 'Low' =
    confidence >= 90 ? 'High' : confidence >= 70 ? 'Medium' : 'Low';

  const badgeStyles = {
    High: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Medium: 'bg-amber-50 text-amber-700 border-amber-200',
    Low: 'bg-rose-50 text-rose-700 border-rose-200',
  }[tier];

  const barStyles = {
    High: 'bg-emerald-500',
    Medium: 'bg-amber-500',
    Low: 'bg-rose-500',
  }[tier];

  const ringStyles = {
    High: 'text-emerald-500',
    Medium: 'text-amber-500',
    Low: 'text-rose-500',
  }[tier];

  if (size === 'sm') {
    return (
      <div className="inline-flex items-center gap-1.5 font-mono text-xs">
        <span
          className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold border ${badgeStyles}`}
          title={`${tier} Confidence (${confidence}%)`}
        >
          {tier} ({confidence}%)
        </span>
        {showWhyButton && whyExplanation && (
          <button
            type="button"
            onClick={e => {
              e.stopPropagation();
              setIsWhyOpen(prev => !prev);
            }}
            className="text-[10px] text-blue-600 hover:text-blue-700 underline cursor-pointer"
          >
            Why?
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="relative inline-block text-left">
      <div className="flex items-center gap-2">
        {/* Visual Progress Bar / Pill */}
        <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1">
          <div className="w-12 bg-slate-200 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-1.5 rounded-full transition-all duration-500 ${barStyles}`}
              style={{ width: `${Math.min(100, Math.max(0, confidence))}%` }}
            ></div>
          </div>
          <span className="font-mono text-xs font-bold text-slate-800">
            {confidence}%
          </span>
          <span
            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider border ${badgeStyles}`}
          >
            {tier}
          </span>
        </div>

        {/* Why Button */}
        {showWhyButton && whyExplanation && (
          <button
            type="button"
            onClick={e => {
              e.stopPropagation();
              setIsWhyOpen(prev => !prev);
            }}
            className="flex items-center gap-0.5 text-[11px] font-medium text-blue-600 hover:text-blue-700 bg-blue-50/70 hover:bg-blue-100/70 border border-blue-200 rounded-md px-2 py-1 transition-colors cursor-pointer"
            title="Explain why this confidence score was generated"
          >
            <span className="material-symbols-outlined text-[13px]">help</span>
            <span>Why?</span>
          </button>
        )}
      </div>

      {/* Popover Explanation */}
      {isWhyOpen && whyExplanation && (
        <div
          className="absolute z-30 mt-1.5 w-72 p-3 bg-white rounded-lg shadow-lg border border-slate-200 text-xs text-slate-700 animate-in fade-in zoom-in-95 duration-150 right-0 sm:left-0 sm:right-auto"
          onClick={e => e.stopPropagation()}
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-1.5 mb-1.5">
            <div className="flex items-center gap-1 text-slate-900 font-semibold">
              <span className="material-symbols-outlined text-[15px] text-blue-600">psychology</span>
              <span>Confidence Rationale</span>
            </div>
            <button
              type="button"
              onClick={() => setIsWhyOpen(false)}
              className="text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              ✕
            </button>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed">{whyExplanation}</p>
          <div className="mt-2 pt-1.5 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>Model: Neural Heuristic v2</span>
            <span>ISO/IEC 27037</span>
          </div>
        </div>
      )}
    </div>
  );
};
