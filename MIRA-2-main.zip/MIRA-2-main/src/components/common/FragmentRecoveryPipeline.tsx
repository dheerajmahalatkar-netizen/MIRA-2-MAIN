import React, { useState } from 'react';
import { DEFAULT_FRAGMENT_PIPELINES, FragmentPipelineGroup } from '../../data/forensicIntelligenceData';
import { ReconstructionFragmentNode } from '../../types/forensic';
import { AiConfidenceMeter } from './AiConfidenceMeter';

interface FragmentRecoveryPipelineProps {
  onInspectReconstructed?: (fileId: string) => void;
}

export const FragmentRecoveryPipeline: React.FC<FragmentRecoveryPipelineProps> = ({
  onInspectReconstructed,
}) => {
  const [selectedFileId, setSelectedFileId] = useState<string>(DEFAULT_FRAGMENT_PIPELINES[0].fileId);
  const [activeFragment, setActiveFragment] = useState<ReconstructionFragmentNode | null>(
    DEFAULT_FRAGMENT_PIPELINES[0].fragments[0]
  );
  const [isAnimating, setIsAnimating] = useState(false);
  const [assemblyStep, setAssemblyStep] = useState<number>(3); // all visible by default

  const currentPipeline =
    DEFAULT_FRAGMENT_PIPELINES.find(p => p.fileId === selectedFileId) || DEFAULT_FRAGMENT_PIPELINES[0];

  const handleRunReconstruction = () => {
    setIsAnimating(true);
    setAssemblyStep(0);
    let step = 0;
    const interval = setInterval(() => {
      step += 1;
      setAssemblyStep(step);
      if (step >= currentPipeline.fragments.length + 1) {
        clearInterval(interval);
        setIsAnimating(false);
      }
    }, 700);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-5">
      {/* Top Header & File Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px] text-blue-600">account_tree</span>
            <h3 className="text-sm font-bold text-slate-900">
              Fragment → Recovery Visual Reconstruction
            </h3>
            <span className="text-[10px] font-mono bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200 font-semibold">
              Live Pipeline
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Interactive visual assembly from raw disk fragments to verified reconstructed evidence.
          </p>
        </div>

        {/* Action & File Selector */}
        <div className="flex items-center gap-2">
          <select
            value={selectedFileId}
            onChange={e => {
              setSelectedFileId(e.target.value);
              const next = DEFAULT_FRAGMENT_PIPELINES.find(p => p.fileId === e.target.value);
              if (next) {
                setActiveFragment(next.fragments[0]);
                setAssemblyStep(next.fragments.length + 1);
              }
            }}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium text-slate-800 focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            {DEFAULT_FRAGMENT_PIPELINES.map(pipe => (
              <option key={pipe.fileId} value={pipe.fileId}>
                {pipe.fileName} ({pipe.fileType})
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={handleRunReconstruction}
            disabled={isAnimating}
            className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
            title="Re-run visual reconstruction animation"
          >
            <span className={`material-symbols-outlined text-[15px] ${isAnimating ? 'animate-spin' : ''}`}>
              refresh
            </span>
            <span>{isAnimating ? 'Assembling...' : 'Re-run Flow'}</span>
          </button>
        </div>
      </div>

      {/* Visual Pipeline Flowchart */}
      <div className="relative overflow-x-auto pb-4 pt-2">
        <div className="min-w-[850px] flex items-center justify-between gap-3 px-2">
          {/* Fragments sequence */}
          {currentPipeline.fragments.map((frag, idx) => {
            const isVisible = assemblyStep > idx;
            const isSelected = activeFragment?.id === frag.id;

            return (
              <React.Fragment key={frag.id}>
                {/* Fragment Card */}
                <div
                  onClick={() => setActiveFragment(frag)}
                  className={`flex-1 min-w-[190px] rounded-xl border p-4 transition-all duration-300 cursor-pointer relative ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-30 translate-y-2'
                  } ${
                    isSelected
                      ? 'bg-blue-50/70 border-blue-500 ring-2 ring-blue-500/20 shadow-sm'
                      : 'bg-white hover:bg-slate-50 border-slate-200 shadow-xs'
                  }`}
                >
                  {/* Top Tag & ID */}
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                      {frag.id}
                    </span>
                    <span
                      className={`text-[10px] font-semibold font-mono px-1.5 py-0.5 rounded border ${
                        frag.recoveryStatus === 'Verified'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : frag.recoveryStatus === 'Carved'
                          ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                          : 'bg-blue-50 text-blue-700 border-blue-200'
                      }`}
                    >
                      {frag.recoveryStatus}
                    </span>
                  </div>

                  {/* Source / Type */}
                  <div className="space-y-1 mb-3">
                    <div className="text-xs font-medium text-slate-800 line-clamp-1" title={frag.sourceType}>
                      {frag.sourceType}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                      <span className="material-symbols-outlined text-[13px] text-slate-400">schedule</span>
                      <span>{frag.timestamp}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      Offset: {frag.sectorOffset}
                    </div>
                  </div>

                  {/* Confidence Score Pill */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-500 font-medium">Confidence</span>
                    <AiConfidenceMeter
                      confidence={frag.confidence}
                      size="sm"
                      whyExplanation={`Fragment validated at ${frag.sectorOffset} via magic byte continuity & CRC.`}
                    />
                  </div>

                  {/* Pulse Indicator */}
                  {isVisible && isAnimating && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full animate-ping"></div>
                  )}
                </div>

                {/* Connecting Arrow Line */}
                <div className="flex flex-col items-center justify-center shrink-0 px-1 text-slate-400">
                  <div className="flex items-center gap-0.5">
                    <span className="w-4 sm:w-6 h-0.5 bg-blue-300"></span>
                    <span className="material-symbols-outlined text-[18px] text-blue-500 -ml-1">
                      arrow_forward
                    </span>
                  </div>
                  <span className="text-[9px] font-mono text-slate-400 uppercase tracking-tighter mt-1">
                    sector link
                  </span>
                </div>
              </React.Fragment>
            );
          })}

          {/* Reconstructed Evidence Target Node */}
          <div
            className={`min-w-[240px] flex-1 rounded-xl border-2 p-4 transition-all duration-500 relative ${
              assemblyStep >= currentPipeline.fragments.length + 1
                ? 'bg-emerald-50/50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-md translate-y-0'
                : 'bg-slate-50 border-dashed border-slate-300 opacity-60 translate-y-2'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded">
                Reconstructed Evidence
              </span>
              <span className="material-symbols-outlined text-[20px] text-emerald-600">
                verified
              </span>
            </div>

            <h4 className="text-xs font-bold text-slate-900 font-mono truncate mb-1" title={currentPipeline.fileName}>
              {currentPipeline.fileName}
            </h4>
            <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed mb-3">
              {currentPipeline.reconstructedEvidence.description}
            </p>

            <div className="pt-2 border-t border-emerald-200/60 flex items-center justify-between text-xs">
              <span className="text-[11px] text-slate-600 font-medium">Composite Confidence</span>
              <span className="font-mono font-bold text-emerald-700 text-sm">
                {currentPipeline.finalConfidence}%
              </span>
            </div>

            {onInspectReconstructed && (
              <button
                type="button"
                onClick={() => onInspectReconstructed(currentPipeline.fileId)}
                className="mt-3 w-full py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-xs"
              >
                <span>Inspect in Evidence Explorer</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Selected Fragment Inspection Drawer */}
      {activeFragment && (
        <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center font-mono font-bold shrink-0">
              0x
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 font-mono">{activeFragment.id}</span>
                <span className="text-slate-400">·</span>
                <span className="text-slate-600 font-mono text-[11px]">
                  Byte Stream Preview:
                </span>
              </div>
              <p className="font-mono text-[11px] text-blue-700 font-medium mt-0.5 truncate max-w-xl">
                {activeFragment.preview || '53 51 4C 69 74 65 20 66 6F 72 6D 61 74 20 33 00'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 text-slate-600 font-mono text-[11px]">
            <span>Size: {activeFragment.sizeFormatted || '4,096 B'}</span>
            <span className="text-slate-300">|</span>
            <span className="text-emerald-700 font-semibold">{activeFragment.recoveryStatus}</span>
          </div>
        </div>
      )}
    </div>
  );
};
