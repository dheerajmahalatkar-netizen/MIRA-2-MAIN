import React, { useState } from 'react';
import { ForensicProvider, useForensic } from './context/ForensicContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { ToastContainer } from './components/common/Toast';
import { HardwareBridgeModal } from './components/modals/HardwareBridgeModal';
import { AddCustodyModal } from './components/modals/AddCustodyModal';
import { CommandPaletteModal } from './components/modals/CommandPaletteModal';
import { PdfPreviewModal } from './components/modals/PdfPreviewModal';
import { ReconstructionDetailModal } from './components/modals/ReconstructionDetailModal';

// Forensic Workflow Pages
import { IntroPage } from './pages/IntroPage';
import { OverviewPage } from './pages/OverviewPage';
import { EvidenceIntakePage } from './pages/EvidenceIntakePage';
import { RecoveryAnalysisPage } from './pages/RecoveryAnalysisPage';
import { ReconstructionPage } from './pages/ReconstructionPage';
import { EvidenceExplorerPage } from './pages/EvidenceExplorerPage';
import { RelationshipGraphPage } from './pages/RelationshipGraphPage';
import { TimelineReconstructionPage } from './pages/TimelineReconstructionPage';
import { AiInsightsPage } from './pages/AiInsightsPage';
import { ReportsPage } from './pages/ReportsPage';
import { SectorAnalysisPage } from './pages/SectorAnalysisPage';
import { EvidenceLabPage } from './pages/EvidenceLabPage';
import { AuditPage } from './pages/AuditPage';
import { AskMiraAssistant } from './components/common/AskMiraAssistant';

const MainLayout: React.FC = () => {
  const { activeRoute, setActiveRoute, error, refreshCaseData, theme } = useForensic();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // Entrance Intro portal state
  const [showIntro, setShowIntro] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const entered = sessionStorage.getItem('mira_entered_workstation');
      return entered !== 'true';
    }
    return true;
  });

  const handleEnterWorkstation = () => {
    setShowIntro(false);
    sessionStorage.setItem('mira_entered_workstation', 'true');
  };

  const handleOpenIntro = () => {
    setShowIntro(true);
  };

  // Render active page
  const renderActivePage = () => {
    switch (activeRoute) {
      case 'intro':
        return <IntroPage onEnter={handleEnterWorkstation} />;
      case 'evidence-intake':
        return <EvidenceIntakePage />;
      case 'recovery-analysis':
        return <RecoveryAnalysisPage />;
      case 'reconstruction':
        return <ReconstructionPage />;
      case 'evidence-explorer':
        return <EvidenceExplorerPage />;
      case 'relationship-graph':
        return <RelationshipGraphPage />;
      case 'timeline':
        return <TimelineReconstructionPage />;
      case 'ai-insights':
        return <AiInsightsPage />;
      case 'reports':
        return <ReportsPage />;
      case 'report':
        return <AuditPage />;
      case 'sectors':
        return <SectorAnalysisPage />;
      case 'lab':
        return <EvidenceLabPage />;
      case 'overview':
      default:
        return <OverviewPage />;
    }
  };

  // If on intro page
  if (showIntro || activeRoute === 'intro') {
    return <IntroPage onEnter={handleEnterWorkstation} />;
  }

  return (
    <div
      className={`min-h-screen flex font-sans selection:bg-cyan-500/25 transition-colors duration-200 ${
        theme === 'dark' ? 'dark bg-[#070A12] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'
      }`}
    >
      {/* Fixed Left Sidebar with Mobile Drawer support */}
      <Sidebar
        onOpenIntro={handleOpenIntro}
        mobileOpen={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
      />

      <div className="flex-1 flex flex-col min-w-0">
        {/* Fixed Top Header */}
        <Header
          onOpenIntro={handleOpenIntro}
          onToggleMobileNav={() => setMobileNavOpen(prev => !prev)}
        />

        {/* Main Forensic Workspace */}
        {error ? (
          <div className="pt-28 px-8 max-w-xl mx-auto text-center space-y-4 lg:pl-60">
            <div className="w-12 h-12 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto shadow-xs">
              <span className="material-symbols-outlined text-[24px]">error</span>
            </div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Analysis Pipeline Offline
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">{error}</p>
            <button
              onClick={() => refreshCaseData()}
              className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-xs"
            >
              Retry Connection
            </button>
          </div>
        ) : (
          <main className="flex-1 w-full lg:pl-60 min-h-screen transition-colors duration-200">
            {renderActivePage()}
          </main>
        )}
      </div>

      {/* Floating "Ask Mira" AI Assistant */}
      <AskMiraAssistant />

      {/* Modals */}
      <HardwareBridgeModal />
      <AddCustodyModal />
      <CommandPaletteModal />
      <PdfPreviewModal />
      <ReconstructionDetailModal />

      {/* Floating System Notification Toasts */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <ForensicProvider>
      <MainLayout />
    </ForensicProvider>
  );
}

