import {
  AiInsightFinding,
  ReconstructionFragmentNode,
  InteractiveTimelineEvent,
  AnomalyRiskAlert,
  RelationshipNode,
  RelationshipLink,
} from '../types/forensic';

// ============================================================================
// 1. AI INSIGHT ENGINE FINDINGS
// ============================================================================
export const DEFAULT_AI_FINDINGS: AiInsightFinding[] = [
  {
    id: 'FND-001',
    title: 'SQLite Database Fragment Cluster Identified',
    explanation: 'Sequential LBA sectors contain contiguous SQLite format 3 B-Tree leaf pages with intact customer transaction tables.',
    category: 'key_finding',
    importance: 'CRITICAL',
    confidence: 96,
    whyReasons: [
      '3 matching fragments found sequentially across sectors #12, #13, and #14',
      'Matching magic byte header "SQLite format 3\\0" at offset 0x0000',
      'Consistent page size (4096 bytes) and valid internal B-tree cell pointers',
      'Strong contextual relationship with accounting journal metadata from 2026-09-24',
    ],
    matchedFragmentsCount: 3,
    relatedArtifactIds: ['art-sqlite-db-1'],
    relatedSectorIds: [12, 13, 14],
    timestamp: '10:42:15 UTC',
  },
  {
    id: 'FND-002',
    title: 'High-Entropy Encrypted Token Fragment in Slack Space',
    explanation: 'Detected an anomalous high-entropy (H = 7.84) payload containing JSON authentication tokens and RSA API keys.',
    category: 'anomaly',
    importance: 'CRITICAL',
    confidence: 92,
    whyReasons: [
      'Shannon Entropy calculation H = 7.84 indicates high-density cryptographic payload',
      'Located in unallocated sector #180, outside standard NTFS cluster runs',
      'String analysis revealed JSON key signatures: "client_secret", "access_token", "jwt"',
      'No corresponding directory entry found in Master File Table ($MFT)',
    ],
    matchedFragmentsCount: 2,
    relatedArtifactIds: ['art-sec-token-3'],
    relatedSectorIds: [180, 181],
    timestamp: '11:03:40 UTC',
  },
  {
    id: 'FND-003',
    title: 'Correlated Financial Spreadsheet Archive Header',
    explanation: 'PKZIP central directory matched with fragmented XML workbook parts, enabling full recovery of quarterly financial statements.',
    category: 'relationship',
    importance: 'HIGH',
    confidence: 94,
    whyReasons: [
      'Magic signature 0x50 0x4B 0x03 0x04 detected at sector #48',
      'Subsequent sectors #49 through #52 contain Deflate compressed streams',
      'Central directory trailer verified at sector #53 with CRC-32 match',
      'Timestamp aligns within 12 seconds of user logout event in security log',
    ],
    matchedFragmentsCount: 4,
    relatedArtifactIds: ['art-xlsx-budget-2'],
    relatedSectorIds: [48, 49, 50, 51, 52, 53],
    timestamp: '10:55:02 UTC',
  },
  {
    id: 'FND-004',
    title: 'Anti-Forensic File Deletion Pattern Detected',
    explanation: 'Identified intentional block zeroing and metadata stomping preceding the incident window.',
    category: 'pattern',
    importance: 'HIGH',
    confidence: 89,
    whyReasons: [
      'Contiguous 64 KB block of NULL bytes (0x00) immediately preceding recovered records',
      'NTFS $MFT Record 4108 indicates modified date newer than created date (timestomp indicator)',
      'USN Journal entries recorded 41 rapid-fire delete events within 1.4 seconds',
      'Associated with process ID 4812 (sdelete.exe equivalent)',
    ],
    matchedFragmentsCount: 5,
    relatedArtifactIds: ['art-sqlite-db-1'],
    relatedSectorIds: [10, 11, 12],
    timestamp: '11:15:20 UTC',
  },
  {
    id: 'FND-005',
    title: 'Incomplete Fragment Run Risk: Missing Central Header Chunk',
    explanation: 'A compressed backup archive has 2 verified data chunks but 1 missing intermediate cluster, causing potential 8% data truncation.',
    category: 'risk',
    importance: 'MEDIUM',
    confidence: 78,
    whyReasons: [
      'Fragment #01 (Header) and Fragment #03 (Footer) are verified and intact',
      'Sector #92 exhibits random overwrites, causing an unlinked boundary gap',
      'Predictive boundary carving has estimated 92% structural recovery with padding',
      'Recommended manual bit-level carve or parity rebuild',
    ],
    matchedFragmentsCount: 3,
    relatedArtifactIds: ['art-conf-sys-4'],
    relatedSectorIds: [90, 91, 93],
    timestamp: '11:22:45 UTC',
  },
  {
    id: 'FND-006',
    title: 'Cryptographic Dual-Hash Verification Match',
    explanation: 'Original forensic E01 disk SHA-256 and MD5 hashes match bit-for-bit with physical Tableau hardware write-blocker image.',
    category: 'key_finding',
    importance: 'HIGH',
    confidence: 100,
    whyReasons: [
      'SHA-256: 7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
      'MD5: 9e107d9d372bb6826bd81d3542a419d6',
      'Zero bit divergence between initial hardware acquisition and live memory buffer',
      'ISO/IEC 27037 compliant digital signature verified by Examiner J. Vance',
    ],
    matchedFragmentsCount: 1,
    relatedArtifactIds: ['art-sqlite-db-1', 'art-xlsx-budget-2'],
    timestamp: '09:30:00 UTC',
  },
];

// ============================================================================
// 2. FRAGMENT RECONSTRUCTION PIPELINE DATA
// ============================================================================
export interface FragmentPipelineGroup {
  fileId: string;
  fileName: string;
  fileType: string;
  finalConfidence: number;
  totalSize: string;
  fragments: ReconstructionFragmentNode[];
  reconstructedEvidence: {
    title: string;
    description: string;
    sha256: string;
    md5: string;
    verifiedStatus: string;
  };
}

export const DEFAULT_FRAGMENT_PIPELINES: FragmentPipelineGroup[] = [
  {
    fileId: 'REC-01',
    fileName: 'financial_records.xlsx',
    fileType: 'Spreadsheet Archive',
    finalConfidence: 96,
    totalSize: '12.4 MB',
    fragments: [
      {
        id: 'FRAG-01',
        sourceType: 'LBA Sector #48 [Zip Header]',
        timestamp: '10:42:08 UTC',
        recoveryStatus: 'Recovered',
        confidence: 98,
        sectorOffset: '0x00030000',
        sizeFormatted: '4,096 B',
        preview: '50 4B 03 04 14 00 06 00 08 00 ... [Content_Types].xml',
      },
      {
        id: 'FRAG-02',
        sourceType: 'LBA Sector #49-51 [Deflate Stream]',
        timestamp: '10:44:22 UTC',
        recoveryStatus: 'Carved',
        confidence: 94,
        sectorOffset: '0x00031000',
        sizeFormatted: '12,288 B',
        preview: '78 9C 4B CE C9 CC 4B 85 10 20 ... xl/worksheets/sheet1.xml',
      },
      {
        id: 'FRAG-03',
        sourceType: 'LBA Sector #52-53 [Central Directory]',
        timestamp: '10:47:19 UTC',
        recoveryStatus: 'Verified',
        confidence: 96,
        sectorOffset: '0x00034000',
        sizeFormatted: '8,192 B',
        preview: '50 4B 01 02 14 00 14 00 06 00 ... xl/sharedStrings.xml',
      },
    ],
    reconstructedEvidence: {
      title: 'financial_records.xlsx (Complete)',
      description: 'Fully reconstructed Microsoft Excel OpenXML workbook with 4 intact worksheets and financial formulas.',
      sha256: 'a8f4c931b2e47d890f12c448a609d1e43b92f708231947b198c614b8991d2e5a',
      md5: '4f7d29c8e10b2849a602de82049e29a1',
      verifiedStatus: 'Verified Bit-Perfect (ISO/IEC 27037)',
    },
  },
  {
    fileId: 'REC-02',
    fileName: 'transactions_ledger.db',
    fileType: 'SQLite Database',
    finalConfidence: 95,
    totalSize: '4.8 MB',
    fragments: [
      {
        id: 'FRAG-0x12',
        sourceType: 'LBA Sector #12 [SQLite Magic & Schema]',
        timestamp: '10:40:11 UTC',
        recoveryStatus: 'Recovered',
        confidence: 99,
        sectorOffset: '0x0000C000',
        sizeFormatted: '4,096 B',
        preview: '53 51 4C 69 74 65 20 66 6F 72 ... "SQLite format 3"',
      },
      {
        id: 'FRAG-0x13',
        sourceType: 'LBA Sector #13 [B-Tree Interior Node]',
        timestamp: '10:41:45 UTC',
        recoveryStatus: 'Carved',
        confidence: 95,
        sectorOffset: '0x0000D000',
        sizeFormatted: '4,096 B',
        preview: '05 00 00 00 08 0F A0 00 00 00 ... page_index=2 payload',
      },
      {
        id: 'FRAG-0x14',
        sourceType: 'LBA Sector #14 [B-Tree Leaf Cells]',
        timestamp: '10:43:02 UTC',
        recoveryStatus: 'Verified',
        confidence: 92,
        sectorOffset: '0x0000E000',
        sizeFormatted: '4,096 B',
        preview: '0D 00 00 00 1E 0C 40 00 00 00 ... tx_id=8921; amt=$420K',
      },
    ],
    reconstructedEvidence: {
      title: 'transactions_ledger.db (Active Table)',
      description: 'Reconstructed relational SQLite database containing 1,842 ledger entries spanning Q2-Q3 2026.',
      sha256: '7b28d011f4e91024bc98129034ff9821ac3e7b1a098234cd9021e89bca7145de',
      md5: '81f092318ab49120ce9a12830f8231aa',
      verifiedStatus: 'Verified Bit-Perfect (ISO/IEC 27037)',
    },
  },
  {
    fileId: 'REC-03',
    fileName: 'auth_credentials.json',
    fileType: 'JSON Token Payload',
    finalConfidence: 91,
    totalSize: '184 KB',
    fragments: [
      {
        id: 'FRAG-0xBA',
        sourceType: 'LBA Sector #180 [Unallocated Slack]',
        timestamp: '11:01:14 UTC',
        recoveryStatus: 'Recovered',
        confidence: 94,
        sectorOffset: '0x000B4000',
        sizeFormatted: '4,096 B',
        preview: '7B 0A 20 20 22 61 70 69 5F 6B ... {\n  "api_keys": [',
      },
      {
        id: 'FRAG-0xBB',
        sourceType: 'LBA Sector #181 [Private Key Block]',
        timestamp: '11:03:00 UTC',
        recoveryStatus: 'Carved',
        confidence: 88,
        sectorOffset: '0x000B5000',
        sizeFormatted: '4,096 B',
        preview: '2D 2D 2D 2D 2D 42 45 47 49 4E ... -----BEGIN PRIVATE KEY-----',
      },
    ],
    reconstructedEvidence: {
      title: 'auth_credentials.json (Recovered)',
      description: 'Extracted sensitive cloud credentials, OAuth tokens, and staging environment private keys.',
      sha256: '3f9821ea9820bc31908234cbfa87901234908123908123aebca0981234908123',
      md5: '71092830192830192830192830192830',
      verifiedStatus: 'Cryptographic Match Validated',
    },
  },
];

// ============================================================================
// 3. INTERACTIVE TIMELINE RECONSTRUCTION DATA
// ============================================================================
export const DEFAULT_TIMELINE_EVENTS: InteractiveTimelineEvent[] = [
  {
    id: 'TL-01',
    time: '09:15 AM',
    timestamp: '2026-09-25T09:15:00Z',
    title: 'Hardware Write-Blocker Bridge Engaged',
    description: 'Tableau T8u Forensic USB 3.0 bridge connected in hardware write-block mode. Host OS physical write commands disabled.',
    stage: 'detected',
    relatedEvidenceId: 'CASE-2026-091',
    relatedEvidenceName: 'Seagate FireCuda 2TB Physical Disk',
    confidence: 100,
    sectorLocation: 'Port: USB-3.0 / /dev/sdb',
    metadata: {
      'Firmware': 'v3.2.1-PROD',
      'Write Block Status': 'Hardware Enforced (ReadOnly)',
      'Examiner': 'J. Vance (Senior Forensic Examiner)',
    },
  },
  {
    id: 'TL-02',
    time: '09:30 AM',
    timestamp: '2026-09-25T09:30:00Z',
    title: 'Bitstream Acquisition & Hash Generation',
    description: 'Raw physical bitstream cloned to court-admissible forensic raw container (.dd). Dual-hash SHA-256 and MD5 computed.',
    stage: 'extracted',
    relatedEvidenceId: 'CASE-2026-091',
    relatedEvidenceName: 'evidence_image.raw (512 Sectors)',
    confidence: 100,
    sectorLocation: 'Sectors #0 - #511',
    metadata: {
      'SHA-256': '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
      'MD5': '9e107d9d372bb6826bd81d3542a419d6',
      'Block Size': '4,096 bytes/sector',
    },
  },
  {
    id: 'TL-03',
    time: '10:42 AM',
    timestamp: '2026-09-25T10:42:00Z',
    title: 'Fragment 01 Detected in Sector #12',
    description: 'Scanning engine detected SQLite magic byte header at offset 0x0000C000. Header continuity score: 99%.',
    stage: 'detected',
    relatedEvidenceId: 'REC-02',
    relatedEvidenceName: 'transactions_ledger.db',
    confidence: 99,
    sectorLocation: 'LBA Sector #12',
    rawEntropy: 4.82,
    metadata: {
      'Magic Signature': 'SQLite format 3\\0',
      'Page Size': '4096',
      'File Change Counter': '14',
    },
  },
  {
    id: 'TL-04',
    time: '10:47 AM',
    timestamp: '2026-09-25T10:47:00Z',
    title: 'Metadata Extracted & B-Tree Leaf Validated',
    description: 'Parsed internal schema definitions for tables: `accounts`, `transactions`, `wire_transfers`. Validated 1,842 row indices.',
    stage: 'extracted',
    relatedEvidenceId: 'REC-02',
    relatedEvidenceName: 'transactions_ledger.db',
    confidence: 96,
    sectorLocation: 'LBA Sectors #13 - #14',
    rawEntropy: 5.64,
    metadata: {
      'Tables Found': 'accounts, transactions, audit_log',
      'Encoding': 'UTF-8',
      'Schema Version': '4',
    },
  },
  {
    id: 'TL-05',
    time: '11:03 AM',
    timestamp: '2026-09-25T11:03:00Z',
    title: 'Related Evidence Found: High-Entropy Slack Token',
    description: 'Correlation engine discovered an unallocated sector #180 containing matching authorization headers and JWT signing keys.',
    stage: 'evidence_found',
    relatedEvidenceId: 'REC-03',
    relatedEvidenceName: 'auth_credentials.json',
    confidence: 92,
    sectorLocation: 'LBA Sector #180',
    rawEntropy: 7.84,
    metadata: {
      'Entropy Level': 'Critical (H = 7.84)',
      'Associated Account ID': 'USR-90218-EXEC',
      'Token Expiry': '2026-10-01T00:00:00Z',
    },
  },
  {
    id: 'TL-06',
    time: '11:15 AM',
    timestamp: '2026-09-25T11:15:00Z',
    title: 'AI Correlation Generated & Continuity Sealed',
    description: 'Neural boundary carving successfully linked 3 fragmented files across 12 sectors with zero data corruption.',
    stage: 'ai_correlated',
    relatedEvidenceId: 'REC-01',
    relatedEvidenceName: 'financial_records.xlsx',
    confidence: 98,
    sectorLocation: 'Sectors #48 - #53',
    metadata: {
      'Link Method': 'Analytical Boundary Continuity Carving',
      'Structural Continuity': '98.2%',
      'Attestation Ready': 'True',
    },
  },
];

// ============================================================================
// 4. ANOMALY / RISK ALERTS
// ============================================================================
export const DEFAULT_ANOMALY_ALERTS: AnomalyRiskAlert[] = [
  {
    id: 'ALT-01',
    type: 'unusual_timestamp',
    severity: 'warning',
    title: 'Unusual Timestamp Discrepancy Detected',
    description: 'Internal SQLite file modification header (10:41 UTC) predates $MFT allocation record (10:44 UTC) by 3 minutes, indicating possible timestomping or clock drift.',
    evidenceId: 'REC-02',
    timestamp: '10:44:12 UTC',
    actionLabel: 'Inspect SQLite Header',
    actionRoute: 'evidence-explorer',
    actionTargetId: 'REC-02',
  },
  {
    id: 'ALT-02',
    type: 'high_priority_evidence',
    severity: 'critical',
    title: 'High-Priority Evidence Found in Slack Space',
    description: 'Unallocated sector #180 contains unencrypted API keys and authentication tokens associated with the root administrative role.',
    evidenceId: 'REC-03',
    timestamp: '11:03:40 UTC',
    actionLabel: 'View Token Fragment',
    actionRoute: 'evidence-explorer',
    actionTargetId: 'REC-03',
  },
  {
    id: 'ALT-03',
    type: 'incomplete_reconstruction',
    severity: 'warning',
    title: 'Incomplete Fragment Reconstruction in Sector #92',
    description: 'Cluster gap detected between Fragment #01 and #03 in system configuration archive. 1 cluster unallocated.',
    evidenceId: 'REC-01',
    timestamp: '11:22:45 UTC',
    actionLabel: 'Open Reconstruction Lab',
    actionRoute: 'reconstruction',
  },
  {
    id: 'ALT-04',
    type: 'strong_correlation',
    severity: 'success',
    title: 'Strong Evidence Correlation Confirmed (98.2%)',
    description: 'Deflate decompression streams matched against XLSX central directory with zero checksum variance.',
    evidenceId: 'REC-01',
    timestamp: '11:15:20 UTC',
    actionLabel: 'View Relationship Graph',
    actionRoute: 'relationship-graph',
  },
];

// ============================================================================
// 5. RELATIONSHIP GRAPH DATA (File → Fragment → Evidence → Event → Finding)
// ============================================================================
export const DEFAULT_GRAPH_NODES: RelationshipNode[] = [
  // Files
  {
    id: 'node-file-1',
    label: 'evidence_disk.raw',
    sublabel: 'Raw Physical Disk (512 Sectors)',
    type: 'file',
    status: 'Acquired',
    details: 'Physical drive image cloned via hardware write blocker.',
    metadata: { Size: '2.00 MiB', Format: 'RAW', SHA256: '7f83b1...' },
  },
  {
    id: 'node-file-2',
    label: 'financial_records.xlsx',
    sublabel: 'Reconstructed Document',
    type: 'file',
    status: 'Intact',
    details: 'Office Open XML Spreadsheet recovered from unallocated runs.',
    metadata: { Size: '12.4 MB', Worksheets: 4, Confidence: '96%' },
  },

  // Fragments
  {
    id: 'node-frag-1',
    label: 'FRAG-0x12 (SQLite Header)',
    sublabel: 'LBA Sector #12',
    type: 'fragment',
    confidence: 99,
    status: 'Recovered',
    details: 'Contains "SQLite format 3" magic signature at offset 0x00.',
    metadata: { Entropy: 4.82, Offset: '0x0000C000', Size: '4,096 B' },
  },
  {
    id: 'node-frag-2',
    label: 'FRAG-0x14 (B-Tree Leaf)',
    sublabel: 'LBA Sector #14',
    type: 'fragment',
    confidence: 94,
    status: 'Verified',
    details: 'Ledger table rows containing transaction records.',
    metadata: { Rows: 1842, Payload: 'Transactions', Size: '4,096 B' },
  },
  {
    id: 'node-frag-3',
    label: 'FRAG-0xBA (Token Slack)',
    sublabel: 'LBA Sector #180',
    type: 'fragment',
    confidence: 92,
    status: 'Recovered',
    details: 'High-entropy payload in unallocated cluster space.',
    metadata: { Entropy: 7.84, Type: 'JSON API Keys' },
  },

  // Evidence Items
  {
    id: 'node-ev-1',
    label: 'EVID-DB-LEDGER',
    sublabel: 'transactions_ledger.db',
    type: 'evidence',
    confidence: 96,
    status: 'Verified',
    details: 'Central accounting ledger database for target organization.',
    metadata: { Entries: 1842, Integrity: 'Bit-Perfect', Triage: 'CRITICAL' },
  },
  {
    id: 'node-ev-2',
    label: 'EVID-SEC-CREDS',
    sublabel: 'auth_credentials.json',
    type: 'evidence',
    confidence: 91,
    status: 'Critical Alert',
    details: 'Exported administrative API access credentials and private keys.',
    metadata: { RiskLevel: 'High', Type: 'Credential Leak' },
  },

  // Events
  {
    id: 'node-evt-1',
    label: 'EVENT-10:42 (Header Discovery)',
    sublabel: '10:42 AM Acquisition',
    type: 'event',
    status: 'Logged',
    details: 'Automated carving process identified SQLite database magic byte string.',
    metadata: { Timestamp: '10:42:15 UTC', Engine: 'Boundary Carving v2.4' },
  },
  {
    id: 'node-evt-2',
    label: 'EVENT-11:03 (Slack Scan)',
    sublabel: '11:03 AM Anomaly Alert',
    type: 'event',
    status: 'Triggered',
    details: 'Entropy threshold detector flagged sector #180 with H=7.84.',
    metadata: { Timestamp: '11:03:40 UTC', Severity: 'Warning' },
  },

  // Findings
  {
    id: 'node-fnd-1',
    label: 'FINDING-REL-01 (DB Reconstruction)',
    sublabel: '96% Match Confidence',
    type: 'finding',
    confidence: 96,
    status: 'Confirmed',
    details: 'Strong sequential continuity verified across sectors #12, #13, #14.',
    metadata: { Importance: 'CRITICAL', Why: '3 matching fragments + schema integrity' },
  },
  {
    id: 'node-fnd-2',
    label: 'FINDING-ANOM-02 (Token Exposure)',
    sublabel: 'High Entropy Leak',
    type: 'finding',
    confidence: 92,
    status: 'Confirmed',
    details: 'Sensitive credentials discovered outside active file structures.',
    metadata: { Importance: 'CRITICAL', Why: 'Unallocated space + valid JSON JWT' },
  },
];

export const DEFAULT_GRAPH_LINKS: RelationshipLink[] = [
  // File -> Fragment
  {
    id: 'link-1',
    source: 'node-file-1',
    target: 'node-frag-1',
    label: 'contains sector',
    strength: 0.9,
    confidence: 100,
  },
  {
    id: 'link-2',
    source: 'node-file-1',
    target: 'node-frag-2',
    label: 'contains sector',
    strength: 0.9,
    confidence: 100,
  },
  {
    id: 'link-3',
    source: 'node-file-1',
    target: 'node-frag-3',
    label: 'unallocated space',
    strength: 0.8,
    confidence: 95,
  },

  // Fragment -> Evidence
  {
    id: 'link-4',
    source: 'node-frag-1',
    target: 'node-ev-1',
    label: 'reconstructs table',
    strength: 0.95,
    confidence: 98,
  },
  {
    id: 'link-5',
    source: 'node-frag-2',
    target: 'node-ev-1',
    label: 'supplies payload',
    strength: 0.95,
    confidence: 95,
  },
  {
    id: 'link-6',
    source: 'node-frag-3',
    target: 'node-ev-2',
    label: 'contains token JSON',
    strength: 0.92,
    confidence: 92,
  },

  // Evidence -> Event
  {
    id: 'link-7',
    source: 'node-ev-1',
    target: 'node-evt-1',
    label: 'triggers event',
    strength: 0.85,
    confidence: 96,
  },
  {
    id: 'link-8',
    source: 'node-ev-2',
    target: 'node-evt-2',
    label: 'flags alert',
    strength: 0.9,
    confidence: 94,
  },

  // Event -> Finding
  {
    id: 'link-9',
    source: 'node-evt-1',
    target: 'node-fnd-1',
    label: 'proves correlation',
    strength: 0.95,
    confidence: 96,
  },
  {
    id: 'link-10',
    source: 'node-evt-2',
    target: 'node-fnd-2',
    label: 'substantiates anomaly',
    strength: 0.92,
    confidence: 92,
  },
];
