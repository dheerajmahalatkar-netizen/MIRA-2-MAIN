import React, { useState } from 'react';
import { DEFAULT_TIMELINE_EVENTS } from '../data/forensicIntelligenceData';
import { InteractiveTimelineEvent, PageRoute } from '../types/forensic';
import { useForensic } from '../context/ForensicContext';
import { AiConfidenceMeter } from '../components/common/AiConfidenceMeter';

export const TimelineReconstructionPage: React.FC = () => {
  const { setActiveRoute } = useForensic();
  const [selectedEventId, setSelectedEventId] = useState<string>(DEFAULT_TIMELINE_EVENTS[2].id);
  const [stageFilter, setStageFilter] = useState<string>('all');

  const selectedEvent: InteractiveTimelineEvent =
    DEFAULT_TIMELINE_EVENTS.find(e => e.id === selectedEventId) || DEFAULT_TIMELINE_EVENTS[0];

  const filteredEvents = DEFAULT_TIMELINE_EVENTS.filter(
    e => stageFilter === 'all' || e.stage === stageFilter
  );

  const getStageBadge = (stage: InteractiveTimelineEvent['stage']) => {
    switch (stage) {
      case 'detected':
        return { label: 'Fragment Detected', icon: 'search', color: 'bg-blue-50 text-blue-700 border-blue-200' };
      case 'extracted':
        return { label: 'Metadata Extracted', icon: 'description', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
      case 'evidence_found':
        return { label: 'Related Evidence Found', icon: 'verified', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'ai_correlated':
        return { label: 'AI Correlation Generated', icon: 'psychology', color: 'bg-purple-50 text-purple-700 border-purple-200' };
    }
  };

  return (
    <div className="pt-20 px-6 lg:px-12 pb-16 max-w-[1500px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600">
              Chronological Reconstruction
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500">ISO/IEC 27037 Evidence Progression</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight">
            Timeline Reconstruction
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Trace the sequence from initial acquisition, fragment detection, and metadata extraction to AI correlation.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setActiveRoute('relationship-graph')}
            className="px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">account_tree</span>
            <span>Relationship Graph</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveRoute('ai-insights')}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <span>AI Insights Engine</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left Timeline + Right Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Vertical Timeline (8 Cols) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
          {/* Filter Bar */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <span className="text-xs font-bold text-slate-800">
              Chronological Event Sequence
            </span>

            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setStageFilter('all')}
                className={`px-2.5 py-1 rounded font-semibold transition-colors cursor-pointer ${
                  stageFilter === 'all' ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-600'
                }`}
              >
                All Events
              </button>
              <button
                type="button"
                onClick={() => setStageFilter('detected')}
                className={`px-2.5 py-1 rounded font-semibold transition-colors cursor-pointer ${
                  stageFilter === 'detected' ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-600'
                }`}
              >
                Detected
              </button>
              <button
                type="button"
                onClick={() => setStageFilter('evidence_found')}
                className={`px-2.5 py-1 rounded font-semibold transition-colors cursor-pointer ${
                  stageFilter === 'evidence_found' ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-600'
                }`}
              >
                Evidence
              </button>
              <button
                type="button"
                onClick={() => setStageFilter('ai_correlated')}
                className={`px-2.5 py-1 rounded font-semibold transition-colors cursor-pointer ${
                  stageFilter === 'ai_correlated' ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-600'
                }`}
              >
                AI Correlated
              </button>
            </div>
          </div>

          {/* Stepper Vertical Tree */}
          <div className="relative pl-6 space-y-6 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
            {filteredEvents.map(event => {
              const isSelected = selectedEventId === event.id;
              const badge = getStageBadge(event.stage);

              return (
                <div
                  key={event.id}
                  onClick={() => setSelectedEventId(event.id)}
                  className="relative group cursor-pointer"
                >
                  {/* Timeline Marker Dot */}
                  <div
                    className={`absolute -left-6 top-1 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                      isSelected
                        ? 'bg-blue-600 border-blue-600 text-white ring-4 ring-blue-100 shadow-xs'
                        : 'bg-white border-slate-300 text-slate-500 group-hover:border-blue-400'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[13px]">{badge.icon}</span>
                  </div>

                  {/* Event Card */}
                  <div
                    className={`p-4 rounded-xl border transition-all ${
                      isSelected
                        ? 'bg-blue-50/60 border-blue-400 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-white hover:bg-slate-50/80 border-slate-200 shadow-2xs'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                          {event.time}
                        </span>
                        <h4 className="text-xs font-bold text-slate-900">{event.title}</h4>
                      </div>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${badge.color}`}>
                        {badge.label}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-600 leading-relaxed">{event.description}</p>

                    <div className="mt-3 pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                      <span className="font-mono text-slate-500">
                        Target: <strong className="text-slate-800">{event.relatedEvidenceName}</strong>
                      </span>
                      <AiConfidenceMeter
                        confidence={event.confidence}
                        size="sm"
                        whyExplanation={`Event corroborated by write-block log and sector continuity at ${event.sectorLocation || 'offset'}.`}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Event Detail & Associated Evidence (4 Cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-6 space-y-5 shadow-xs">
          <div className="border-b border-slate-200 pb-4">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-600 block mb-1">
              Event Details &amp; Associated Evidence
            </span>
            <h3 className="text-base font-bold text-slate-900 font-mono">
              {selectedEvent.title}
            </h3>
            <span className="text-xs text-slate-500 mt-0.5 block font-mono">
              Time: {selectedEvent.time} ({selectedEvent.timestamp})
            </span>
          </div>

          {/* Description */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700 leading-relaxed">
            {selectedEvent.description}
          </div>

          {/* Associated Evidence Box */}
          <div className="p-3.5 bg-blue-50/60 rounded-xl border border-blue-200 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-800 block">
              Associated Evidence Artifact
            </span>
            <div className="flex items-center justify-between">
              <span className="font-mono font-bold text-xs text-slate-900">
                {selectedEvent.relatedEvidenceName}
              </span>
              <span className="text-[10px] font-mono text-blue-700 bg-white px-2 py-0.5 rounded border border-blue-200 font-semibold">
                {selectedEvent.relatedEvidenceId}
              </span>
            </div>
            {selectedEvent.sectorLocation && (
              <div className="text-[11px] font-mono text-slate-600">
                Location: {selectedEvent.sectorLocation}
              </div>
            )}
            <button
              type="button"
              onClick={() => setActiveRoute('evidence-explorer')}
              className="mt-2 w-full py-1.5 px-3 bg-white hover:bg-slate-50 border border-blue-300 text-blue-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
            >
              <span>Inspect Associated Evidence</span>
              <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
            </button>
          </div>

          {/* Raw Metadata Table */}
          {selectedEvent.metadata && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900">Captured Forensic Metadata</h4>
              <div className="space-y-1.5 text-xs font-mono">
                {Object.entries(selectedEvent.metadata).map(([k, v]) => (
                  <div
                    key={k}
                    className="flex items-center justify-between p-2 rounded bg-slate-50 border border-slate-100"
                  >
                    <span className="text-slate-500">{k}:</span>
                    <span className="font-semibold text-slate-800 truncate max-w-[180px]">{v}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
