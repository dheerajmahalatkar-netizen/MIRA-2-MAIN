import React from 'react';
import { useForensic } from '../context/ForensicContext';
import { AnomalyRiskBanner } from '../components/common/AnomalyRiskBanner';

export const OverviewPage: React.FC = () => {
  const { setActiveRoute, showToast, currentCase, artifacts, sectors } = useForensic();

  // Dynamic priority items from ingested artifacts with fallback defaults
  const priorityEvidence = artifacts.length > 0
    ? artifacts.slice(0, 6).map(art => ({
        priority: art.triage || 'MEDIUM',
        priorityColor: art.triage === 'CRITICAL' || art.triage === 'HIGH'
          ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800'
          : art.triage === 'MEDIUM'
            ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
            : 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
        name: art.name,
        type: art.fileType || 'Evidence Document',
        icon: art.fileType?.includes('PDF') ? 'picture_as_pdf' : art.fileType?.includes('Image') ? 'image' : art.fileType?.includes('JSON') ? 'code' : 'description',
        status: art.repairStatus === 'ATTEMPTED' ? 'Damaged Header' : 'Recovered',
        statusColor: art.repairStatus === 'ATTEMPTED'
          ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
          : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
        integrity: art.integrityScore || 95,
        confidence: Math.round(art.confidenceScore || 92),
      }))
    : [
        {
          priority: 'HIGH',
          priorityColor: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800',
          name: 'incident_report.txt',
          type: 'Document',
          icon: 'description',
          status: 'Recovered',
          statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
          integrity: 99,
          confidence: 96,
        },
        {
          priority: 'HIGH',
          priorityColor: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800',
          name: 'evidence_metadata.json',
          type: 'Database / JSON',
          icon: 'code',
          status: 'Reconstructed',
          statusColor: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800',
          integrity: 92,
          confidence: 94,
        },
        {
          priority: 'MEDIUM',
          priorityColor: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800',
          name: 'fragment_004_corrupted.txt',
          type: 'Corrupted Fragment',
          icon: 'warning',
          status: 'Repair Available',
          statusColor: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800',
          integrity: 45,
          confidence: 68,
        },
        {
          priority: 'MEDIUM',
          priorityColor: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800',
          name: 'activity_log.txt',
          type: 'System Trace',
          icon: 'article',
          status: 'Recovered',
          statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
          integrity: 99,
          confidence: 97,
        },
      ];

  const totalSectorsScanned = sectors.length > 0 ? sectors.length : 512;
  const totalArtifactsCount = artifacts.length > 0 ? artifacts.length : 8;

  return (
    <div className="pt-20 px-4 sm:px-6 lg:px-8 pb-12 space-y-6 max-w-[1440px] mx-auto animate-in fade-in duration-200">
      {/* 1. Page Header with Title, Subtitle, and Top Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
              MIRA Command Station
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-0.5">
            Investigation Command Overview
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
            Understand recovered fragments, structural relationships, reconstruction progress, and court-admissible attestations.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setActiveRoute('evidence-intake')}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 hover:scale-105 transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[17px]">upload_file</span>
            <span>Import Evidence</span>
          </button>

          <button
            type="button"
            onClick={() => {
              showToast('Opening full case audit dossier', 'info');
              setActiveRoute('reports');
            }}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold shadow-xs transition-all cursor-pointer hover:border-cyan-500/50"
          >
            <span className="material-symbols-outlined text-[17px] text-cyan-600 dark:text-cyan-400">visibility</span>
            <span>View Case Dossier</span>
          </button>
        </div>
      </div>

      {/* Anomaly & Risk Alerts Banner */}
      <AnomalyRiskBanner compact={false} />

      {/* 2. Top 4 Metric Cards with 3D Depth & Hover Specular */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Evidence Sources */}
        <div
          onClick={() => setActiveRoute('evidence-intake')}
          className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:border-blue-500/50 cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/80 text-blue-600 dark:text-cyan-400 flex items-center justify-center border border-blue-100 dark:border-blue-800/80">
              <span className="material-symbols-outlined text-[20px]">hard_drive</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 flex items-center gap-1">
              Active <span className="material-symbols-outlined text-[12px] transform group-hover:translate-x-0.5 transition-transform">arrow_forward</span>
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Evidence Sources</span>
            <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono mt-0.5">
              {currentCase?.uploadedFiles?.length || 3}
            </div>
            <span className="text-[11px] text-slate-400 dark:text-slate-500">Mounted physical bitstreams</span>
          </div>
        </div>

        {/* Card 2: Fragments Detected */}
        <div
          onClick={() => setActiveRoute('recovery-analysis')}
          className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:border-cyan-500/50 cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-cyan-50 dark:bg-cyan-950/80 text-cyan-600 dark:text-cyan-300 flex items-center justify-center border border-cyan-100 dark:border-cyan-800/80">
              <span className="material-symbols-outlined text-[20px]">saved_search</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 flex items-center gap-1">
              Sector LBA <span className="material-symbols-outlined text-[12px] transform group-hover:translate-x-0.5 transition-transform">arrow_forward</span>
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Sectors &amp; Fragments</span>
            <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono mt-0.5">
              {totalSectorsScanned.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400 dark:text-slate-500">4,096-byte LBA chunks mapped</span>
          </div>
        </div>

        {/* Card 3: Recoverable Data / Artifacts */}
        <div
          onClick={() => setActiveRoute('reconstruction')}
          className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:border-indigo-500/50 cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-100 dark:border-emerald-800/80">
              <span className="material-symbols-outlined text-[20px]">extension</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 flex items-center gap-1">
              Carving <span className="material-symbols-outlined text-[12px] transform group-hover:translate-x-0.5 transition-transform">arrow_forward</span>
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Recovered Artifacts</span>
            <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono mt-0.5">
              {totalArtifactsCount}
            </div>
            <span className="text-[11px] text-slate-400 dark:text-slate-500">Bitstream artifacts reconstructed</span>
          </div>
        </div>

        {/* Card 4: Reconstruction Confidence */}
        <div
          onClick={() => setActiveRoute('ai-insights')}
          className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:border-purple-500/50 cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/80 text-purple-600 dark:text-purple-300 flex items-center justify-center border border-purple-100 dark:border-purple-800/80">
              <span className="material-symbols-outlined text-[20px]">verified</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 flex items-center gap-1">
              Neural <span className="material-symbols-outlined text-[12px] transform group-hover:translate-x-0.5 transition-transform">arrow_forward</span>
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">AI Continuity Confidence</span>
            <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono mt-0.5">
              87.4%
            </div>
            <span className="text-[11px] text-slate-400 dark:text-slate-500">Weighted boundary certainty</span>
          </div>
        </div>
      </div>

      {/* 3. Recovery Status & Health Metrics */}
      <div className="bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Storage Health &amp; Integrity Analysis</h3>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">Physical bitstream baseline derived via Tableau T8u read-blocker.</p>
          </div>
          <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 font-bold">
            Write-Block Active
          </span>
        </div>

        <div className="space-y-4 text-xs">
          {/* Storage Integrity */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-300">
                <span className="material-symbols-outlined text-[16px] text-emerald-600 dark:text-emerald-400">shield</span>
                <span className="font-semibold">Storage Bitstream Integrity</span>
                <span className="text-[11px] text-slate-400 dark:text-slate-500 font-normal hidden sm:inline">SHA-256 and MD5 cryptographic match</span>
              </span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">96.8%</span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
              <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '96.8%' }} />
            </div>
          </div>

          {/* Fragmentation */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-300">
                <span className="material-symbols-outlined text-[16px] text-cyan-600 dark:text-cyan-400">dashboard_customize</span>
                <span className="font-semibold">LBA Fragmentation</span>
                <span className="text-[11px] text-slate-400 dark:text-slate-500 font-normal hidden sm:inline">Non-contiguous unallocated clusters</span>
              </span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">48.2%</span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
              <div className="bg-gradient-to-r from-cyan-500 to-blue-600 h-2 rounded-full" style={{ width: '48.2%' }} />
            </div>
          </div>

          {/* Estimated Recoverability */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-300">
                <span className="material-symbols-outlined text-[16px] text-indigo-600 dark:text-indigo-400">donut_large</span>
                <span className="font-semibold">Reconstructable Boundary Continua</span>
                <span className="text-[11px] text-slate-400 dark:text-slate-500 font-normal hidden sm:inline">64-byte transition matches &gt; 0.65 threshold</span>
              </span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">88.5%</span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 h-2 rounded-full" style={{ width: '88.5%' }} />
            </div>
          </div>
        </div>
      </div>

      {/* 4. "What MIRA Found" + "AI Recovery Summary" */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left: What MIRA Found Steps (8 Cols) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">What MIRA Found</h3>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
              AI-assisted topological analysis between fragmented sectors, magic signatures, and recovered artifacts.
            </p>
          </div>

          {/* Connected Steps Flow */}
          <div className="overflow-x-auto pb-2">
            <div className="min-w-[650px] flex items-center justify-between gap-1 text-center">
              {[
                { title: 'Physical Media', desc: 'Write-Blocked Disk', icon: 'archive', route: 'evidence-intake' as const },
                { title: 'LBA Profiling', desc: 'Entropy Decomposition', icon: 'pie_chart', route: 'recovery-analysis' as const },
                { title: 'AI Analysis', desc: 'Neural Continuity Match', icon: 'psychology', highlight: true, route: 'ai-insights' as const },
                { title: 'Link Graph', desc: 'Topological Edges', icon: 'hub', route: 'relationship-graph' as const },
                { title: 'Reconstructed', desc: 'Carved Documents', icon: 'description', route: 'reconstruction' as const },
                { title: 'ISO Attestation', desc: 'Chain of Custody', icon: 'verified', route: 'reports' as const },
              ].map((step, idx, arr) => (
                <React.Fragment key={idx}>
                  <div
                    onClick={() => setActiveRoute(step.route)}
                    className={`flex-1 p-3 rounded-xl border flex flex-col items-center justify-center space-y-1.5 transition-all cursor-pointer group hover:scale-105 ${
                      step.highlight
                        ? 'bg-blue-50/90 dark:bg-cyan-950/40 border-blue-300 dark:border-cyan-700/80 ring-2 ring-blue-500/20 dark:ring-cyan-500/20 shadow-xs'
                        : 'bg-slate-50/70 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                        step.highlight ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 text-white' : 'text-slate-600 dark:text-slate-400 group-hover:text-blue-600 dark:group-hover:text-cyan-400'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[17px]">{step.icon}</span>
                    </div>
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight block truncate max-w-[95px]">
                      {step.title}
                    </span>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 leading-tight block line-clamp-2 max-w-[100px]">
                      {step.desc}
                    </span>
                  </div>

                  {idx < arr.length - 1 && (
                    <span className="material-symbols-outlined text-[16px] text-blue-500 dark:text-cyan-400 shrink-0 px-0.5 animate-pulse">
                      arrow_forward
                    </span>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* Right: AI Recovery Summary (4 Cols) */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px] text-blue-600 dark:text-cyan-400">auto_awesome</span>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">AI Reconstruction Summary</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <strong className="text-slate-900 dark:text-white font-semibold">{totalArtifactsCount} forensic artifacts</strong> have been isolated across <strong className="text-slate-900 dark:text-white font-semibold">{totalSectorsScanned} physical sectors</strong>.
            </p>

            <div className="space-y-2 pt-1 text-xs">
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                <span className="font-bold text-slate-900 dark:text-white font-mono">{Math.max(1, totalArtifactsCount - 1)}</span>
                <span className="text-slate-500 dark:text-slate-400">High-confidence reconstructions</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                <span className="font-bold text-slate-900 dark:text-white font-mono">1</span>
                <span className="text-slate-500 dark:text-slate-400">Damaged headers with repair support</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                <span className="w-2 h-2 rounded-full bg-indigo-500 shrink-0"></span>
                <span className="font-bold text-slate-900 dark:text-white font-mono">100%</span>
                <span className="text-slate-500 dark:text-slate-400">ISO/IEC 27037 compliance</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveRoute('ai-insights')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:text-blue-700 dark:hover:text-cyan-300 transition-colors cursor-pointer pt-2 border-t border-slate-100 dark:border-slate-800"
          >
            <span>Explore AI Reasoning &amp; Provenance</span>
            <span className="material-symbols-outlined text-[15px]">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* 5. Priority Evidence Table */}
      <div className="bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Priority Recovered Evidence</h3>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
              Artifacts prioritized for immediate investigator triage and chain-of-custody logging.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setActiveRoute('evidence-explorer')}
            className="text-xs text-blue-600 dark:text-cyan-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>All Evidence</span>
            <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800">
                <th className="py-2.5 px-3 font-mono">Priority</th>
                <th className="py-2.5 px-3">Evidence File</th>
                <th className="py-2.5 px-3">Format</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Integrity</th>
                <th className="py-2.5 px-3">Confidence</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80 font-medium">
              {priorityEvidence.map((row, idx) => (
                <tr
                  key={idx}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors text-slate-800 dark:text-slate-200"
                >
                  {/* Priority Tag */}
                  <td className="py-3 px-3">
                    <span
                      className={`text-[9.5px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${row.priorityColor}`}
                    >
                      {row.priority}
                    </span>
                  </td>

                  {/* Evidence File Name */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2 font-mono font-semibold text-slate-900 dark:text-white">
                      <span className="material-symbols-outlined text-[17px] text-cyan-600 dark:text-cyan-400">
                        {row.icon}
                      </span>
                      <span>{row.name}</span>
                    </div>
                  </td>

                  {/* Type */}
                  <td className="py-3 px-3 text-slate-500 dark:text-slate-400">{row.type}</td>

                  {/* Status Pill */}
                  <td className="py-3 px-3">
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${row.statusColor}`}
                    >
                      {row.status}
                    </span>
                  </td>

                  {/* Integrity Bar */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-slate-700 dark:text-slate-300 w-8">{row.integrity}%</span>
                      <div className="w-16 bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-1.5 rounded-full ${
                            row.integrity > 80
                              ? 'bg-emerald-500'
                              : row.integrity > 60
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${row.integrity}%` }}
                        />
                      </div>
                    </div>
                  </td>

                  {/* Confidence Bar */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-slate-700 dark:text-slate-300 w-8">{row.confidence}%</span>
                      <div className="w-16 bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-blue-600 dark:bg-cyan-500 h-1.5 rounded-full"
                          style={{ width: `${row.confidence}%` }}
                        />
                      </div>
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="py-3 px-3 text-right space-x-2">
                    <button
                      type="button"
                      onClick={() => setActiveRoute('reconstruction')}
                      className="text-[11px] font-semibold text-blue-600 dark:text-cyan-400 hover:underline cursor-pointer"
                    >
                      Reconstruct
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveRoute('evidence-explorer')}
                      className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white cursor-pointer"
                    >
                      Hex View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 6. Next Recommended Action Banner */}
      <div className="bg-gradient-to-r from-blue-600/10 via-indigo-600/10 to-purple-600/10 dark:from-cyan-950/40 dark:via-blue-950/40 dark:to-purple-950/30 rounded-2xl border border-blue-200 dark:border-cyan-800/60 p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-md">
            <span className="material-symbols-outlined text-[22px]">auto_fix_high</span>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-cyan-400 block font-mono">
              NEXT RECOMMENDED ACTION
            </span>
            <p className="text-xs text-slate-800 dark:text-slate-200 font-semibold mt-0.5">
              Review fragment boundary matches and export court-admissible forensic attestation.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveRoute('reconstruction')}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
          >
            <span>Review Reconstructions</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveRoute('reports')}
            className="px-4 py-2.5 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
          >
            <span>Open Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};
