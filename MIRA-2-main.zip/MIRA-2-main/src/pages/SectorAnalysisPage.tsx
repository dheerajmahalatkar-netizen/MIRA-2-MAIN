import React, { useState } from 'react';
import { useForensic } from '../context/ForensicContext';
import { SectorData } from '../types/forensic';

export const SectorAnalysisPage: React.FC = () => {
  const {
    sectors,
    edges,
    artifacts,
    selectedSector,
    setSelectedSector,
    setActiveRoute,
    setSelectedArtifact,
  } = useForensic();

  const [hoveredSector, setHoveredSector] = useState<SectorData | null>(null);

  // If no sectors, render truthful empty state
  if (!sectors || sectors.length === 0) {
    return (
      <div className="pt-24 px-8 pb-16 max-w-4xl mx-auto text-center space-y-4">
        <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 text-slate-400 flex items-center justify-center mx-auto">
          <span className="material-symbols-outlined text-[24px]">grid_off</span>
        </div>
        <h2 className="text-lg font-bold text-slate-900">No sector profile available</h2>
        <p className="text-xs text-slate-500">
          Analyze a physical storage image or load the synthetic evidence demo to begin.
        </p>
      </div>
    );
  }

  const activeSector = selectedSector || sectors[12] || sectors[0];

  // Check if active sector participates in an edge
  const activeEdge = edges.find(
    e => e.sourceSector === activeSector.id || e.targetSector === activeSector.id
  );

  const relatedArtifact = artifacts.find(a =>
    a.sourceSectors.includes(activeSector.id)
  );

  // Helper for color coding in light mode
  const getSectorBg = (sector: SectorData, isSelected: boolean) => {
    if (isSelected) {
      return 'bg-blue-600 ring-2 ring-blue-400 z-10 scale-110 shadow-sm';
    }
    if (sector.isReconstructed) {
      return 'bg-emerald-500 hover:brightness-105';
    }
    switch (sector.classification) {
      case 'STRUCTURED_TEXT':
        return 'bg-emerald-200 hover:bg-emerald-300';
      case 'BINARY_STRUCTURE':
        return 'bg-amber-200 hover:bg-amber-300';
      case 'ENCRYPTED_CORRUPT':
        return 'bg-rose-400 hover:bg-rose-500';
      case 'SPARSE':
      default:
        return 'bg-slate-200 hover:bg-slate-300';
    }
  };

  return (
    <div className="pt-20 px-6 lg:px-12 pb-16 max-w-[1500px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Sector Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600">
              Physical Storage Layout
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500">512 Sectors · 4096-byte LBA Blocks</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
            Sector Analysis
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Explore where evidence was found and how fragmented sectors were connected.
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 bg-white px-4 py-2.5 rounded-lg border border-slate-200 text-xs shadow-2xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-slate-200 border border-slate-300"></span>
            <span className="text-slate-600">Sparse (H ≤ 1.0)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-emerald-200"></span>
            <span className="text-slate-600">Structured Text</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-amber-200"></span>
            <span className="text-slate-600">Binary Structure</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500"></span>
            <span className="text-slate-800 font-medium">Reconstructed</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-rose-400"></span>
            <span className="text-slate-600">High Entropy (H &gt; 7.2)</span>
          </div>
        </div>
      </div>

      {/* Main Analysis Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Sector Matrix Map (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-6 space-y-5 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Evidence Distribution Map</h2>
              <span className="text-xs text-slate-500">
                Click any sector to inspect its Shannon entropy, offset, and continuation relations.
              </span>
            </div>

            {hoveredSector && (
              <div className="px-3 py-1 rounded bg-slate-100 border border-slate-200 text-xs font-mono text-slate-800">
                Sector #{hoveredSector.id} · Offset: {hoveredSector.offsetHex} · H: {hoveredSector.entropy}
              </div>
            )}
          </div>

          {/* Compact 32-column Sector Grid */}
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 overflow-x-auto">
            <div className="grid grid-cols-[repeat(32,_minmax(0,_1fr))] gap-1 min-w-[640px]">
              {sectors.map(sector => {
                const isSelected = activeSector.id === sector.id;
                const isPartner =
                  activeEdge &&
                  (activeEdge.sourceSector === sector.id || activeEdge.targetSector === sector.id);

                return (
                  <button
                    key={sector.id}
                    onClick={() => setSelectedSector(sector)}
                    onMouseEnter={() => setHoveredSector(sector)}
                    onMouseLeave={() => setHoveredSector(null)}
                    title={`Sector #${sector.id} | Offset: ${sector.offsetHex} | Entropy: ${sector.entropy} | ${sector.classification}${sector.anchor ? ' | Anchor: ' + sector.anchor : ''}`}
                    className={`h-4.5 rounded-xs transition-all cursor-pointer relative ${getSectorBg(
                      sector,
                      isSelected
                    )} ${isPartner && !isSelected ? 'ring-1 ring-emerald-500' : ''}`}
                    type="button"
                  />
                );
              })}
            </div>
          </div>

          {/* Reconstruction Graph */}
          <div className="pt-3 border-t border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900">
                Reconstruction Graph
              </h3>
              <span className="text-[11px] text-slate-500">
                Evaluated 64-byte boundary continuity between candidate sectors
              </span>
            </div>

            {edges.length > 0 ? (
              <div className="space-y-3">
                {edges.map((edge, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3">
                      {/* Source Node */}
                      <button
                        onClick={() => {
                          const s = sectors.find(sec => sec.id === edge.sourceSector);
                          if (s) setSelectedSector(s);
                        }}
                        className="px-3 py-1.5 rounded bg-white border border-emerald-300 text-xs font-mono font-bold text-emerald-700 hover:bg-emerald-50 transition-colors shadow-2xs"
                      >
                        Sector #{edge.sourceSector}
                      </button>

                      {/* Direction and Edge score */}
                      <div className="flex flex-col items-center px-2">
                        <span className="text-[11px] font-mono font-bold text-emerald-600">
                          Score: {edge.continuityScore}
                        </span>
                        <div className="flex items-center w-28 sm:w-40 my-0.5">
                          <div className="h-0.5 bg-emerald-500 flex-1"></div>
                          <span className="material-symbols-outlined text-[16px] text-emerald-600 -ml-1">
                            arrow_forward
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-500">{edge.reason}</span>
                      </div>

                      {/* Target Node */}
                      <button
                        onClick={() => {
                          const s = sectors.find(sec => sec.id === edge.targetSector);
                          if (s) setSelectedSector(s);
                        }}
                        className="px-3 py-1.5 rounded bg-white border border-emerald-300 text-xs font-mono font-bold text-emerald-700 hover:bg-emerald-50 transition-colors shadow-2xs"
                      >
                        Sector #{edge.targetSector}
                      </button>
                    </div>

                    {relatedArtifact && (
                      <button
                        onClick={() => {
                          setSelectedArtifact(relatedArtifact);
                          setActiveRoute('lab');
                        }}
                        className="text-xs font-medium text-blue-600 hover:underline flex items-center gap-1 shrink-0"
                      >
                        <span>View {relatedArtifact.name}</span>
                        <span className="material-symbols-outlined text-[15px]">arrow_forward</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-center text-xs text-slate-500">
                No reconstruction graph edges detected.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Sector Inspector Details (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-6 space-y-5 shadow-xs">
          <div className="border-b border-slate-200 pb-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                Sector Inspector
              </span>
              <span className="font-mono text-xs text-slate-500">
                {activeSector.offsetHex}
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 font-mono mt-1">
              Sector #{activeSector.id}
            </h3>
          </div>

          {/* Properties Table */}
          <div className="space-y-2.5 text-xs">
            <div className="flex items-center justify-between p-2.5 rounded bg-slate-50 border border-slate-200">
              <span className="text-slate-500">Shannon Entropy</span>
              <span className="font-mono font-bold text-slate-900">
                {activeSector.entropy} / 8.00
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded bg-slate-50 border border-slate-200">
              <span className="text-slate-500">Category</span>
              <span className="font-semibold text-slate-800">
                {activeSector.classification.replace('_', ' ')}
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded bg-slate-50 border border-slate-200">
              <span className="text-slate-500">Magic Anchor</span>
              <span className="font-mono text-emerald-700 font-semibold">
                {activeSector.anchor || 'None detected'}
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded bg-slate-50 border border-slate-200">
              <span className="text-slate-500">Reconstruction Status</span>
              <span className="font-semibold text-slate-800">
                {activeSector.isReconstructed ? (
                  <span className="text-emerald-600 font-medium">Active Participant</span>
                ) : (
                  <span className="text-slate-400">Isolated Block</span>
                )}
              </span>
            </div>
          </div>

          {/* Reconstructed Partner Connection if any */}
          {activeEdge && (
            <div className="p-3.5 rounded-lg bg-emerald-50/70 border border-emerald-200 space-y-1.5">
              <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider block">
                Graph Relationship
              </span>
              <p className="text-xs text-slate-700">
                Linked {activeEdge.sourceSector === activeSector.id ? `to Sector #${activeEdge.targetSector}` : `from Sector #${activeEdge.sourceSector}`} with continuity score <strong className="text-emerald-700 font-mono">{activeEdge.continuityScore}</strong> ({activeEdge.reason}).
              </p>
            </div>
          )}

          {/* Hex & ASCII sample snippet */}
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Leading Bytes Preview
            </span>
            <div className="p-3 bg-slate-50 rounded border border-slate-200 font-mono text-[11px] space-y-1 text-slate-900">
              <div className="text-emerald-700 font-medium break-all">{activeSector.hexPreview || '00 00 00 00 ...'}</div>
              <div className="text-slate-500 truncate">{activeSector.asciiPreview || '................'}</div>
            </div>
          </div>

          {/* Action button */}
          {relatedArtifact && (
            <button
              onClick={() => {
                setSelectedArtifact(relatedArtifact);
                setActiveRoute('lab');
              }}
              className="w-full py-2.5 px-4 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
            >
              <span>Inspect Reconstructed Artifact ({relatedArtifact.name})</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
