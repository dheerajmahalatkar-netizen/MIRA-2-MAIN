import React from 'react';
import { useForensic } from '../context/ForensicContext';

export const RecoveryAnalysisPage: React.FC = () => {
  const { setActiveRoute, showToast } = useForensic();

  // Generate 24x8 sample sector grid matching screenshot
  const sectorGrid = [
    ['recovered', 'recovered', 'recovered', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'corrupted', 'corrupted', 'recovered', 'unknown', 'unknown', 'empty', 'empty', 'unknown', 'empty', 'corrupted', 'recovered', 'empty', 'empty'],
    ['recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'fragmented', 'corrupted', 'corrupted', 'recovered', 'unknown', 'unknown', 'empty', 'empty', 'unknown', 'empty', 'corrupted', 'recovered', 'empty', 'empty'],
    ['recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'unknown', 'unknown', 'unknown', 'unknown', 'fragmented', 'fragmented', 'corrupted', 'corrupted', 'unknown', 'unknown', 'unknown', 'empty', 'empty', 'unknown', 'empty', 'recovered', 'recovered', 'empty', 'empty'],
    ['recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'unknown', 'unknown', 'unknown', 'unknown', 'corrupted', 'corrupted', 'unknown', 'corrupted', 'corrupted', 'recovered', 'recovered', 'recovered', 'empty', 'corrupted', 'unknown', 'recovered', 'recovered', 'empty', 'empty'],
    ['recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'corrupted', 'unknown', 'corrupted', 'corrupted', 'recovered', 'recovered', 'unknown', 'empty', 'corrupted', 'corrupted', 'recovered', 'recovered', 'empty', 'empty'],
    ['recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'corrupted', 'unknown', 'unknown', 'unknown', 'recovered', 'recovered', 'recovered', 'empty', 'recovered', 'corrupted', 'recovered', 'recovered', 'empty', 'empty'],
    ['unknown', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'recovered', 'unknown', 'unknown', 'unknown', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
    ['unknown', 'unknown', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty', 'empty'],
  ];

  const getSectorColor = (type: string) => {
    switch (type) {
      case 'recovered':
        return 'bg-blue-500';
      case 'fragmented':
        return 'bg-emerald-500';
      case 'corrupted':
        return 'bg-rose-500';
      case 'unknown':
        return 'bg-amber-400';
      case 'empty':
      default:
        return 'bg-slate-200/90';
    }
  };

  return (
    <div className="pt-20 px-6 lg:px-8 pb-12 space-y-6 max-w-[1440px] mx-auto animate-in fade-in duration-200">
      {/* 1. Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Recovery Analysis</h1>
        <p className="text-xs text-slate-500 mt-1">
          Scan the storage, detect fragments and analyze recoverable data.
        </p>
      </div>

      {/* 2. Top Pipeline Stepper matching screenshot */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="relative flex items-center justify-between max-w-4xl mx-auto px-4">
          {/* Connector Line */}
          <div className="absolute left-10 right-10 top-4 h-0.5 bg-slate-200 -z-0">
            <div className="h-full bg-blue-600 w-1/5"></div>
          </div>

          {/* Step 1: Evidence (Complete) */}
          <button
            type="button"
            onClick={() => setActiveRoute('evidence-intake')}
            className="flex flex-col items-center text-center relative z-10 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 border border-emerald-300 flex items-center justify-center font-bold text-xs shadow-2xs mb-1.5 group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[15px]">check</span>
            </div>
            <span className="text-xs font-semibold text-slate-700 group-hover:text-blue-600 transition-colors">
              Evidence
            </span>
          </button>

          {/* Step 2: File System Scan (Active) */}
          <div className="flex flex-col items-center text-center relative z-10">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs ring-4 ring-blue-100 mb-1.5">
              <span className="material-symbols-outlined text-[15px]">find_in_page</span>
            </div>
            <span className="text-xs font-bold text-blue-600">File System Scan</span>
          </div>

          {/* Step 3: Fragment Detection */}
          <div className="flex flex-col items-center text-center relative z-10">
            <div className="w-8 h-8 rounded-full bg-white border border-slate-300 text-slate-400 flex items-center justify-center text-xs mb-1.5">
              <span className="material-symbols-outlined text-[15px]">crop_free</span>
            </div>
            <span className="text-xs font-semibold text-slate-400">Fragment Detection</span>
          </div>

          {/* Step 4: Relationship Analysis */}
          <div className="flex flex-col items-center text-center relative z-10">
            <div className="w-8 h-8 rounded-full bg-white border border-slate-300 text-slate-400 flex items-center justify-center text-xs mb-1.5">
              <span className="material-symbols-outlined text-[15px]">hub</span>
            </div>
            <span className="text-xs font-semibold text-slate-400">Relationship Analysis</span>
          </div>

          {/* Step 5: Reconstruction */}
          <button
            type="button"
            onClick={() => setActiveRoute('reconstruction')}
            className="flex flex-col items-center text-center relative z-10 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-full bg-white border border-slate-300 text-slate-400 flex items-center justify-center text-xs mb-1.5 group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[15px]">layers</span>
            </div>
            <span className="text-xs font-semibold text-slate-400 group-hover:text-blue-600 transition-colors">
              Reconstruction
            </span>
          </button>

          {/* Step 6: Verification */}
          <div className="flex flex-col items-center text-center relative z-10">
            <div className="w-8 h-8 rounded-full bg-white border border-slate-300 text-slate-400 flex items-center justify-center text-xs mb-1.5">
              <span className="material-symbols-outlined text-[15px]">verified</span>
            </div>
            <span className="text-xs font-semibold text-slate-400">Verification</span>
          </div>
        </div>
      </div>

      {/* 3. Scanning Storage Card matching screenshot */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Scanning Storage</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Analyzing file system structures and identifying recoverable data...
          </p>
        </div>

        {/* Progress Bar & Percentage */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-900">
            <span></span>
            <span className="font-mono text-sm">72%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
              style={{ width: '72%' }}
            ></div>
          </div>
        </div>

        {/* 3 Stats below progress */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {/* Stat 1 */}
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
            <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100 shrink-0">
              <span className="material-symbols-outlined text-[20px]">database</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-400 font-medium block">Fragments Discovered</span>
              <span className="text-lg font-bold text-slate-900 font-mono mt-0.5 block">12,847</span>
              <span className="text-[10px] text-slate-400 block">Potential data fragments</span>
            </div>
          </div>

          {/* Stat 2 */}
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
            <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100 shrink-0">
              <span className="material-symbols-outlined text-[20px]">description</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-400 font-medium block">Potential File Structures</span>
              <span className="text-lg font-bold text-slate-900 font-mono mt-0.5 block">3,421</span>
              <span className="text-[10px] text-slate-400 block">Possible file structures</span>
            </div>
          </div>

          {/* Stat 3 */}
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
            <div className="w-9 h-9 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center border border-cyan-100 shrink-0">
              <span className="material-symbols-outlined text-[20px]">inventory_2</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-400 font-medium block">Potentially Recoverable</span>
              <span className="text-lg font-bold text-slate-900 font-mono mt-0.5 block">2,086</span>
              <span className="text-[10px] text-slate-400 block">Files or data segments</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Bottom Grid: Sector Visualization + Scan Details + Analysis Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left: Storage Sector Visualization & Scan Details (8 Cols) */}
        <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* Sector Visualization Matrix (8 Cols of 12) */}
          <div className="md:col-span-8 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Storage Sector Visualization</h3>
              <p className="text-xs text-slate-400 mt-0.5">Overview of storage sectors and their current state.</p>
            </div>

            {/* Matrix of color-coded cells */}
            <div className="overflow-x-auto py-1">
              <div className="min-w-[360px] grid grid-cols-24 gap-1.5 p-1 bg-slate-50 rounded-xl border border-slate-100">
                {sectorGrid.flatMap((row, rIdx) =>
                  row.map((cell, cIdx) => (
                    <div
                      key={`${rIdx}-${cIdx}`}
                      className={`w-full aspect-square rounded-[2px] transition-transform hover:scale-125 hover:z-10 cursor-pointer ${getSectorColor(
                        cell
                      )}`}
                      title={`Sector #${rIdx * 24 + cIdx}: ${cell.toUpperCase()}`}
                    ></div>
                  ))
                )}
              </div>
            </div>

            {/* Sector Color Legend matching screenshot */}
            <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono">
              <span className="flex items-center gap-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded-xs bg-blue-500"></span>
                <span>Recovered</span>
                <strong className="text-slate-900 font-bold">32%</strong>
              </span>

              <span className="flex items-center gap-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500"></span>
                <span>Fragmented</span>
                <strong className="text-slate-900 font-bold">28%</strong>
              </span>

              <span className="flex items-center gap-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded-xs bg-rose-500"></span>
                <span>Corrupted</span>
                <strong className="text-slate-900 font-bold">4%</strong>
              </span>

              <span className="flex items-center gap-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded-xs bg-amber-400"></span>
                <span>Unknown</span>
                <strong className="text-slate-900 font-bold">12%</strong>
              </span>

              <span className="flex items-center gap-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded-xs bg-slate-300"></span>
                <span>Empty</span>
                <strong className="text-slate-900 font-bold">24%</strong>
              </span>
            </div>
          </div>

          {/* Scan Details Card (4 Cols of 12) */}
          <div className="md:col-span-4 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4 flex flex-col justify-between">
            <h3 className="text-sm font-bold text-slate-900">Scan Details</h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-[18px] text-slate-400 mt-0.5">
                  hard_drive
                </span>
                <div>
                  <span className="text-[11px] text-slate-400 font-medium block">Storage Size</span>
                  <span className="font-bold text-slate-900 font-mono mt-0.5 block">512 GB</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-[18px] text-slate-400 mt-0.5">
                  grid_view
                </span>
                <div>
                  <span className="text-[11px] text-slate-400 font-medium block">Sectors Scanned</span>
                  <span className="font-bold text-slate-900 font-mono mt-0.5 block">524,288</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-[18px] text-slate-400 mt-0.5">
                  schedule
                </span>
                <div>
                  <span className="text-[11px] text-slate-400 font-medium block">Scan Duration</span>
                  <span className="font-bold text-slate-900 font-mono mt-0.5 block">12 min 36 sec</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-[18px] text-slate-400 mt-0.5">
                  folder
                </span>
                <div>
                  <span className="text-[11px] text-slate-400 font-medium block">File System</span>
                  <span className="font-bold text-slate-900 font-mono mt-0.5 block">NTFS (Detected)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Analysis Log (4 Cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900">Analysis Log</h3>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Live
              </span>
            </div>

            {/* Stepper of Logs matching screenshot */}
            <div className="relative pl-6 space-y-4 pt-3 text-xs before:absolute before:left-2.5 before:top-4 before:bottom-3 before:w-0.5 before:bg-slate-200">
              {/* Step 1 */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs border border-emerald-300">
                  <span className="material-symbols-outlined text-[12px]">check</span>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900">Initializing scan</h4>
                    <span className="text-[10px] font-mono text-slate-400">10:24 AM</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">Reading disk structure and metadata...</p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs border border-emerald-300">
                  <span className="material-symbols-outlined text-[12px]">check</span>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900">Scanning file system</h4>
                    <span className="text-[10px] font-mono text-slate-400">10:28 AM</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">Analyzing partition tables and file system...</p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs border border-emerald-300">
                  <span className="material-symbols-outlined text-[12px]">check</span>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900">Detecting fragments</h4>
                    <span className="text-[10px] font-mono text-slate-400">10:34 AM</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">Identified 12,847 potential fragments...</p>
                </div>
              </div>

              {/* Step 4: Active */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center border-2 border-blue-600">
                  <span className="material-symbols-outlined text-[12px] animate-spin">sync</span>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-blue-900">Analyzing relationships</h4>
                    <span className="text-[10px] font-mono text-blue-600">10:41 AM</span>
                  </div>
                  <p className="text-[11px] text-blue-700 mt-0.5">Linking fragments to file structures...</p>
                </div>
              </div>

              {/* Step 5: Pending */}
              <div className="relative opacity-60">
                <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-white text-slate-400 flex items-center justify-center border border-slate-300 text-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-700">Reconstruction</h4>
                  <p className="text-[10px] text-slate-400">Pending · Building recoverable files...</p>
                </div>
              </div>

              {/* Step 6: Pending */}
              <div className="relative opacity-60">
                <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-white text-slate-400 flex items-center justify-center border border-slate-300 text-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-700">Verification</h4>
                  <p className="text-[10px] text-slate-400">Pending · Checking integrity and completeness...</p>
                </div>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveRoute('reconstruction')}
            className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
          >
            <span>Proceed to Reconstruction</span>
            <span className="material-symbols-outlined text-[15px]">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* 5. Bottom Scan in Progress Banner matching screenshot */}
      <div className="bg-blue-50/70 border border-blue-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-[20px] text-blue-600 shrink-0">
            info
          </span>
          <div>
            <h4 className="font-bold text-blue-900 leading-tight">Scan in progress</h4>
            <p className="text-[11px] text-blue-700 mt-0.5">
              The analysis may take some time depending on the size and condition of the storage device.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => showToast('Forensic scan paused safely. State preserved.', 'warning')}
          className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold rounded-lg text-xs shadow-2xs transition-colors cursor-pointer shrink-0"
        >
          Cancel Scan
        </button>
      </div>
    </div>
  );
};
