import React, { useState } from 'react';
import { useForensic } from '../context/ForensicContext';
import { ForensicArtifact } from '../types/forensic';

export const EvidenceLabPage: React.FC = () => {
  const {
    artifacts,
    selectedArtifact,
    setSelectedArtifact,
    repairArtifactHeader,
    downloadArtifact,
    isLoading,
  } = useForensic();

  const [activeTab, setActiveTab] = useState<'content' | 'hex' | 'provenance'>('content');
  const [repairing, setRepairing] = useState(false);

  const currentArtifact: ForensicArtifact | undefined =
    selectedArtifact || artifacts[0];

  const handleRepair = async () => {
    if (!currentArtifact) return;
    setRepairing(true);
    try {
      await repairArtifactHeader(currentArtifact.id);
    } finally {
      setRepairing(false);
    }
  };

  const handleDownload = () => {
    if (!currentArtifact) return;
    downloadArtifact(currentArtifact.id, currentArtifact.name);
  };

  if (!currentArtifact) {
    return (
      <div className="pt-24 px-8 pb-16 max-w-4xl mx-auto text-center space-y-4">
        <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 text-slate-400 flex items-center justify-center mx-auto">
          <span className="material-symbols-outlined text-[24px]">science</span>
        </div>
        <h2 className="text-lg font-bold text-slate-900">No artifacts loaded</h2>
        <p className="text-xs text-slate-500">
          Execute the analysis pipeline or load the demo image to inspect recovered files.
        </p>
      </div>
    );
  }

  const isCritical = currentArtifact.triage === 'CRITICAL';
  const isHigh = currentArtifact.triage === 'HIGH';

  return (
    <div className="pt-20 px-6 lg:px-12 pb-16 max-w-[1500px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600">
              Artifact Examination
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500">{artifacts.length} Assembled Candidates</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
            Evidence Lab
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            What exactly was recovered? Inspect candidate reconstructions, byte-level hex traces, and evidentiary provenance.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer shadow-xs"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px] text-blue-600">download</span>
            <span>Download Artifact Bitstream</span>
          </button>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Artifacts Selector List (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-4 space-y-3 shadow-xs">
          <div className="px-2 py-1 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Recovered Artifacts
            </span>
            <span className="text-[11px] font-mono text-slate-500">
              {artifacts.length} Items
            </span>
          </div>

          <div className="space-y-1.5 max-h-[680px] overflow-y-auto pr-1">
            {artifacts.map(art => {
              const isSelected = art.id === currentArtifact.id;
              const artCrit = art.triage === 'CRITICAL';
              const artHigh = art.triage === 'HIGH';

              return (
                <div
                  key={art.id}
                  onClick={() => setSelectedArtifact(art)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-300 shadow-2xs'
                      : 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:bg-slate-100/60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <span className="font-mono text-xs font-bold text-slate-900 truncate">
                      {art.name}
                    </span>
                    <span
                      className={`inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-mono font-bold uppercase tracking-wide border ${
                        artCrit
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : artHigh
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}
                    >
                      {art.triage}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <span>{art.fileType}</span>
                    <span className="font-mono font-medium text-slate-800">
                      {art.sizeFormatted}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pt-2 border-t border-slate-200">
                    <span className="font-mono text-blue-600 font-medium">
                      Sectors: {art.sourceSectors.map(s => `#${s}`).join(' → ')}
                    </span>
                    <span className="font-mono">
                      Conf: <strong className="text-slate-800">{art.confidenceScore}%</strong>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Artifact Viewer & Provenance (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-6 space-y-6 shadow-xs">
          {/* Artifact Metadata Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wide border ${
                    isCritical
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : isHigh
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  }`}
                >
                  {currentArtifact.triage} PRIORITY
                </span>
                <span className="text-xs text-slate-500">{currentArtifact.fileType}</span>
                {currentArtifact.isSyntheticDemo && (
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                    SYNTHETIC DEMO
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold text-slate-900 font-mono">
                {currentArtifact.name}
              </h2>
            </div>

            {/* Metrics Capsule */}
            <div className="flex items-center gap-4 bg-slate-50 px-4 py-2 rounded-lg border border-slate-200 font-mono">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">Integrity</span>
                <span className="text-sm font-bold text-slate-900">
                  {currentArtifact.integrityScore}%
                </span>
              </div>
              <div className="border-l border-slate-200 pl-4">
                <span className="text-[10px] text-slate-500 uppercase block">Confidence</span>
                <span className="text-sm font-bold text-emerald-600">
                  {currentArtifact.confidenceScore}%
                </span>
              </div>
              <div className="border-l border-slate-200 pl-4">
                <span className="text-[10px] text-slate-500 uppercase block">Sectors</span>
                <span className="text-sm font-bold text-slate-900">
                  {currentArtifact.sourceSectors.map(s => `#${s}`).join('→')}
                </span>
              </div>
            </div>
          </div>

          {/* Cryptographic SHA-256 Box */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2 truncate">
              <span className="text-slate-500 uppercase font-bold text-[10px]">SHA-256:</span>
              <span className="text-blue-700 truncate select-all font-medium">{currentArtifact.sha256}</span>
            </div>
            <button
              onClick={() => {
                if (navigator?.clipboard) {
                  navigator.clipboard.writeText(currentArtifact.sha256);
                }
              }}
              title="Copy hash to clipboard"
              className="text-slate-500 hover:text-slate-800 p-1 transition-colors"
            >
              <span className="material-symbols-outlined text-[16px]">content_copy</span>
            </button>
          </div>

          {/* Header Repair Button (Shown ONLY when supported) */}
          {currentArtifact.supportsHeaderRepair && (
            <div className="p-4 rounded-lg bg-amber-50/60 border border-amber-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-amber-800 uppercase tracking-wider">
                    Header Synthesis Candidate
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Damaged leading magic bytes detected with intact structural IHDR metadata.
                  </p>
                </div>
                <button
                  onClick={handleRepair}
                  disabled={repairing || isLoading || currentArtifact.repairStatus === 'SUCCESS'}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs ${
                    currentArtifact.repairStatus === 'SUCCESS'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-600 hover:bg-amber-700 text-white'
                  }`}
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">
                    {currentArtifact.repairStatus === 'SUCCESS' ? 'check' : 'build'}
                  </span>
                  <span>
                    {currentArtifact.repairStatus === 'SUCCESS'
                      ? 'Header Repaired'
                      : repairing
                      ? 'Synthesizing...'
                      : 'Synthesize Damaged Header'}
                  </span>
                </button>
              </div>

              {currentArtifact.repairValidation && (
                <div
                  className={`text-xs p-2.5 rounded font-mono ${
                    currentArtifact.repairStatus === 'SUCCESS'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  {currentArtifact.repairValidation}
                </div>
              )}
            </div>
          )}

          {/* Tabs: Content, Hex Viewer, Provenance */}
          <div className="space-y-4">
            <div className="flex items-center gap-1 border-b border-slate-200 pb-2 text-xs">
              <button
                onClick={() => setActiveTab('content')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  activeTab === 'content'
                    ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Reconstructed Content
              </button>
              <button
                onClick={() => setActiveTab('hex')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  activeTab === 'hex'
                    ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Hex Viewer (16 bytes/row)
              </button>
              <button
                onClick={() => setActiveTab('provenance')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  activeTab === 'provenance'
                    ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Provenance &amp; Boundary Reasoning
              </button>
            </div>

            {/* Tab 1: Reconstructed Content */}
            {activeTab === 'content' && (
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 max-h-96 overflow-y-auto">
                <pre className="font-mono text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                  {currentArtifact.contentPreview}
                </pre>
              </div>
            )}

            {/* Tab 2: Hex Viewer */}
            {activeTab === 'hex' && (
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 overflow-x-auto max-h-96">
                <table className="w-full text-left font-mono text-[11px] border-collapse min-w-[580px]">
                  <thead>
                    <tr className="text-slate-500 border-b border-slate-200 pb-1">
                      <th className="py-1 px-2 w-28">Offset</th>
                      <th className="py-1 px-4">Hex Bytes (00 - 0F)</th>
                      <th className="py-1 px-2 w-48 text-right">ASCII</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {currentArtifact.hexViewRows?.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-100/70 transition-colors">
                        <td className="py-1 px-2 text-slate-500">{row.offset}</td>
                        <td className="py-1 px-4 text-slate-900 tracking-wider select-all">{row.hex}</td>
                        <td className="py-1 px-2 text-emerald-700 font-medium text-right">{row.ascii}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Tab 3: Provenance View */}
            {activeTab === 'provenance' && (
              <div className="p-5 bg-slate-50 rounded-lg border border-slate-200 space-y-5 text-xs">
                <div>
                  <h4 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-2">
                    Analytical Evidence Provenance Chain
                  </h4>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3 p-3 rounded bg-white border border-slate-200 font-mono shadow-2xs">
                    <span className="text-emerald-700 font-medium">
                      {currentArtifact.sourceSectors.map(s => `Sector #${s}`).join(' → ')}
                    </span>
                    <span className="text-slate-400">↓</span>
                    <span className="text-amber-700 font-medium">
                      Confidence: {currentArtifact.confidenceScore}%
                    </span>
                    <span className="text-slate-400">↓</span>
                    <span className="text-slate-800 truncate">
                      SHA-256: {currentArtifact.sha256.substring(0, 16)}...
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border border-slate-200 shadow-2xs">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                      Observed Evidence
                    </span>
                    <p className="text-slate-700 leading-relaxed">
                      {currentArtifact.provenance.observed}
                    </p>
                  </div>

                  <div className="p-3 bg-white rounded border border-slate-200 shadow-2xs">
                    <span className="text-[10px] font-bold text-emerald-700 uppercase block mb-1">
                      Inferred Relationship
                    </span>
                    <p className="text-slate-700 leading-relaxed">
                      {currentArtifact.provenance.inferred}
                    </p>
                  </div>

                  <div className="p-3 bg-white rounded border border-slate-200 shadow-2xs">
                    <span className="text-[10px] font-bold text-amber-700 uppercase block mb-1">
                      Verified Result
                    </span>
                    <p className="text-slate-700 leading-relaxed">
                      {currentArtifact.provenance.verified}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
