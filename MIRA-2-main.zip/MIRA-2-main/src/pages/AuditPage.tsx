import React from 'react';
import { useForensic } from '../context/ForensicContext';

export const AuditPage: React.FC = () => {
  const {
    currentCase,
    artifacts,
    auditTimeline,
    exportCustodyPdf,
  } = useForensic();

  const handlePrint = () => {
    window.print();
  };

  const driveSize = currentCase?.driveSizeFormatted || '2.00 MiB';

  return (
    <div className="pt-20 px-6 lg:px-12 pb-16 max-w-[1200px] mx-auto space-y-8 animate-in fade-in duration-200">
      {/* Action Bar (Hidden on print) */}
      <div className="no-print flex items-center justify-between border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Forensic Examination Record
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Formal evidentiary documentation and ISO/IEC 27037-aligned audit trail.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={exportCustodyPdf}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer shadow-xs"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px] text-blue-600">picture_as_pdf</span>
            <span>Export Attestation (PDF)</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white transition-colors cursor-pointer shadow-xs"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">print</span>
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Formal Document Container (Printable Area) */}
      <article className="print-area bg-white rounded-xl border border-slate-200 p-8 lg:p-12 space-y-8 shadow-xs text-slate-900">
        {/* Document Header */}
        <header className="border-b-2 border-blue-600 pb-6 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="text-xs font-mono font-bold tracking-widest text-blue-600 uppercase mb-1">
              MIRA DIGITAL FORENSIC EXAMINATION RECORD
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Case Record: {currentCase?.id || 'CASE-2026-091'}
            </h2>
            <div className="text-xs text-slate-500 mt-1 font-mono">
              ISO/IEC 27037-aligned evidence handling workflow · Station: WS-EVIDENCE-04
            </div>
          </div>

          <div className="text-right font-mono text-xs text-slate-500">
            <div>Date: {currentCase?.acquisitionDate || '25 Sep 2026, 14:32 UTC'}</div>
            <div>Examiner: Abhishek · Lead Forensic Analyst</div>
            <div className="text-emerald-600 font-bold mt-1">Verification: Bit-Perfect</div>
          </div>
        </header>

        {/* SECTION 1: Original Evidence */}
        <section className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1.5">
            1. Original Evidence Identification
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px] uppercase">Storage Medium</span>
              <span className="text-slate-900 font-semibold">{currentCase?.title || 'Physical NAND Disk'}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px] uppercase">Calculated Drive Size</span>
              <span className="text-emerald-700 font-bold">{driveSize}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px] uppercase">Sectors Profiled</span>
              <span className="text-slate-900 font-semibold">{currentCase?.sectorCount || 512} (4096-byte)</span>
            </div>
            <div className="p-3 bg-slate-50 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px] uppercase">Acquisition Protocol</span>
              <span className="text-slate-800">Write-Blocked (Tableau T8u)</span>
            </div>
          </div>
        </section>

        {/* SECTION 2: Cryptographic Hashes */}
        <section className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1.5">
            2. Cryptographic Attestation &amp; Verification
          </h3>
          <div className="p-4 bg-slate-50 rounded border border-slate-200 space-y-2 text-xs font-mono">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <span className="text-slate-500 uppercase font-bold text-[11px]">Primary SHA-256 (Bit-Stream Level):</span>
              <span className="text-blue-700 select-all font-semibold break-all">{currentCase?.sha256}</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pt-2 border-t border-slate-200">
              <span className="text-slate-500 uppercase font-bold text-[11px]">Corroborating MD5 Checksum:</span>
              <span className="text-slate-900 select-all break-all">{currentCase?.md5}</span>
            </div>
          </div>
        </section>

        {/* SECTION 3: Reconstructed Artifact Ledger */}
        <section className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1.5">
            3. Reconstructed Artifact Ledger
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse print-table">
              <thead>
                <tr className="bg-slate-50 text-slate-600 uppercase text-[10px] font-mono border-b border-slate-200">
                  <th className="py-2.5 px-3">Artifact Identifier</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Source LBA</th>
                  <th className="py-2.5 px-3">Integrity</th>
                  <th className="py-2.5 px-3">Confidence</th>
                  <th className="py-2.5 px-3">Cryptographic SHA-256</th>
                  <th className="py-2.5 px-3 text-right">Triage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                {artifacts.map(a => (
                  <tr key={a.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-3 font-bold text-slate-900">{a.name}</td>
                    <td className="py-2.5 px-3 text-slate-500">{a.fileType}</td>
                    <td className="py-2.5 px-3 text-emerald-700 font-medium">
                      {a.sourceSectors.map(s => `#${s}`).join('→')}
                    </td>
                    <td className="py-2.5 px-3 text-slate-900">{a.integrityScore}%</td>
                    <td className="py-2.5 px-3 text-emerald-700 font-medium">{a.confidenceScore}%</td>
                    <td className="py-2.5 px-3 text-slate-500 text-[10px]">
                      {a.sha256.substring(0, 16)}...
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span
                        className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-bold ${
                          a.triage === 'CRITICAL'
                            ? 'text-rose-700 bg-rose-50 border border-rose-200'
                            : a.triage === 'HIGH'
                            ? 'text-amber-700 bg-amber-50 border border-amber-200'
                            : 'text-emerald-700 bg-emerald-50 border border-emerald-200'
                        }`}
                      >
                        {a.triage}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* SECTION 4: Chain of Custody & Audit Timeline */}
        <section className="space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1.5">
            4. Chronological Chain of Custody Timeline
          </h3>
          <div className="space-y-3 font-mono text-xs">
            {auditTimeline.map(item => (
              <div
                key={item.id}
                className="p-3.5 bg-slate-50 rounded border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <div>
                    <span className="font-bold text-slate-900 block">{item.step}</span>
                    <span className="text-[11px] text-slate-500">{item.details}</span>
                  </div>
                </div>
                <div className="text-slate-500 text-[10px] sm:text-right shrink-0">
                  {item.timestamp}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Certification Sign-Off Block */}
        <footer className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row justify-between gap-8 text-xs font-mono">
          <div className="space-y-1">
            <span className="text-slate-500 uppercase block text-[10px]">Lead Examiner Certification</span>
            <div className="font-bold text-slate-900">Abhishek · Lead Forensic Analyst</div>
            <div className="text-[11px] text-slate-500">MIRA Cryptographic Examination Station 04</div>
          </div>

          <div className="space-y-1 sm:text-right">
            <span className="text-slate-500 uppercase block text-[10px]">Cryptographic Seal</span>
            <div className="text-emerald-700 font-bold">BITSTREAM INTEGRITY VERIFIED</div>
            <div className="text-[10px] text-slate-500">ISO/IEC 27037-aligned evidence handling workflow</div>
          </div>
        </footer>
      </article>
    </div>
  );
};
