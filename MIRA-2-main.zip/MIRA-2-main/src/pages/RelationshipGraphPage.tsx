import React, { useState } from 'react';
import {
  DEFAULT_GRAPH_NODES,
  DEFAULT_GRAPH_LINKS,
} from '../data/forensicIntelligenceData';
import { RelationshipNode, GraphNodeType, PageRoute } from '../types/forensic';
import { useForensic } from '../context/ForensicContext';

export const RelationshipGraphPage: React.FC = () => {
  const { setActiveRoute, showToast } = useForensic();
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-frag-1');
  const [filterType, setFilterType] = useState<GraphNodeType | 'all'>('all');

  const selectedNode =
    DEFAULT_GRAPH_NODES.find(n => n.id === selectedNodeId) || DEFAULT_GRAPH_NODES[0];

  // Connected links
  const connectedLinks = DEFAULT_GRAPH_LINKS.filter(
    l => l.source === selectedNodeId || l.target === selectedNodeId
  );

  // Connected node IDs
  const connectedNodeIds = new Set<string>();
  connectedLinks.forEach(l => {
    connectedNodeIds.add(l.source);
    connectedNodeIds.add(l.target);
  });

  const filteredNodes = DEFAULT_GRAPH_NODES.filter(
    n => filterType === 'all' || n.type === filterType
  );

  const getTypeBadge = (type: GraphNodeType) => {
    switch (type) {
      case 'file':
        return { label: 'File', color: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-cyan-300 dark:border-blue-800', icon: 'draft' };
      case 'fragment':
        return { label: 'Fragment', color: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800', icon: 'extension' };
      case 'evidence':
        return { label: 'Evidence', color: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800', icon: 'verified' };
      case 'event':
        return { label: 'Event', color: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800', icon: 'event' };
      case 'finding':
        return { label: 'Finding', color: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800', icon: 'psychology' };
    }
  };

  // Group nodes by type for visual hierarchy:
  const stages: Array<{ type: GraphNodeType; label: string; icon: string }> = [
    { type: 'file', label: '1. Files', icon: 'draft' },
    { type: 'fragment', label: '2. Fragments', icon: 'extension' },
    { type: 'evidence', label: '3. Evidence', icon: 'verified' },
    { type: 'event', label: '4. Events', icon: 'event' },
    { type: 'finding', label: '5. Findings', icon: 'psychology' },
  ];

  return (
    <div className="pt-20 px-4 sm:px-6 lg:px-12 pb-16 max-w-[1500px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
              Evidentiary Topology
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Heuristic Node Correlation</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Relationship Graph
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Interactive multi-tier visualization linking <span className="font-semibold text-slate-700 dark:text-slate-200">File → Fragment → Evidence → Event → Finding</span>.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setActiveRoute('evidence-explorer')}
            className="px-3.5 py-2 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">folder_open</span>
            <span>Evidence Explorer</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveRoute('timeline')}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
          >
            <span>Timeline Reconstruction</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900/90 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs overflow-x-auto w-fit">
        <button
          type="button"
          onClick={() => setFilterType('all')}
          className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
            filterType === 'all'
              ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-cyan-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          All Layers ({DEFAULT_GRAPH_NODES.length})
        </button>
        {stages.map(st => (
          <button
            key={st.type}
            type="button"
            onClick={() => setFilterType(st.type)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer capitalize flex items-center gap-1.5 ${
              filterType === st.type
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-cyan-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">{st.icon}</span>
            <span>{st.label}</span>
          </button>
        ))}
      </div>

      {/* Main Graph Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Flow Canvas / Columns (8 Cols) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Correlated Topology Flow
            </span>
            <span className="text-[11px] text-slate-400 dark:text-slate-500 font-mono">
              Click any node to highlight linked relationships
            </span>
          </div>

          {/* 5-Column Multi-Tier Flow */}
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
            {stages.map(stage => {
              const nodesInStage = filteredNodes.filter(n => n.type === stage.type);
              return (
                <div key={stage.type} className="space-y-3">
                  {/* Column Header */}
                  <div className="text-center pb-2 border-b border-slate-200 dark:border-slate-800">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block font-mono">
                      {stage.label}
                    </span>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                      {nodesInStage.length} items
                    </span>
                  </div>

                  {/* Node Cards in this Column */}
                  <div className="space-y-2">
                    {nodesInStage.map(node => {
                      const isSelected = selectedNodeId === node.id;
                      const isConnected = connectedNodeIds.has(node.id);
                      const badge = getTypeBadge(node.type);

                      return (
                        <div
                          key={node.id}
                          onClick={() => setSelectedNodeId(node.id)}
                          className={`mira-card-3d p-3 rounded-xl border text-left transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? 'bg-blue-50 dark:bg-cyan-950/60 border-blue-500 dark:border-cyan-500 ring-2 ring-blue-500/20 shadow-md shadow-cyan-500/10'
                              : isConnected
                              ? 'bg-indigo-50/40 dark:bg-indigo-950/30 border-indigo-300 dark:border-indigo-800 shadow-2xs'
                              : 'bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-850 border-slate-200 dark:border-slate-800 shadow-2xs'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 mb-1.5">
                            <span
                              className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${badge.color}`}
                            >
                              {badge.label}
                            </span>
                            {node.confidence && (
                              <span className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400">
                                {node.confidence}%
                              </span>
                            )}
                          </div>

                          <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1" title={node.label}>
                            {node.label}
                          </h4>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                            {node.sublabel}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Flow Legend */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 dark:bg-cyan-400"></span>
                <span>Selected Node</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-300 dark:bg-indigo-500"></span>
                <span>Directly Connected</span>
              </span>
            </div>
            <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
              Active Links: {connectedLinks.length}
            </span>
          </div>
        </div>

        {/* Right Column: Node Details Inspector (4 Cols) */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-5 shadow-xs">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
                Node Inspector
              </span>
              <span
                className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                  getTypeBadge(selectedNode.type).color
                }`}
              >
                {getTypeBadge(selectedNode.type).label}
              </span>
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white font-mono break-words">
              {selectedNode.label}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{selectedNode.sublabel}</p>
          </div>

          {/* Description */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            {selectedNode.details}
          </div>

          {/* Metadata Key-Values */}
          {selectedNode.metadata && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Extracted Attributes</h4>
              <div className="space-y-1.5 text-xs font-mono">
                {Object.entries(selectedNode.metadata).map(([k, v]) => (
                  <div
                    key={k}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                  >
                    <span className="text-slate-500 dark:text-slate-400">{k}:</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]">{v}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Connected Edges List */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">Connected Relationships</h4>
            <div className="space-y-1.5 text-xs">
              {connectedLinks.map(link => {
                const targetNode = DEFAULT_GRAPH_NODES.find(n => n.id === link.target);
                const sourceNode = DEFAULT_GRAPH_NODES.find(n => n.id === link.source);

                return (
                  <div
                    key={link.id}
                    className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px]"
                  >
                    <div className="flex items-center gap-1.5 truncate mr-2">
                      <span className="material-symbols-outlined text-[14px] text-blue-600 dark:text-cyan-400">
                        arrow_forward
                      </span>
                      <span className="font-medium text-slate-800 dark:text-slate-200 font-mono truncate">
                        {link.source === selectedNodeId ? targetNode?.label : sourceNode?.label}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 shrink-0">
                      {link.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action button inside inspector */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => {
                showToast(`Inspecting node: ${selectedNode.label}`, 'info');
                setActiveRoute('reconstruction');
              }}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
            >
              <span>Examine in Reconstruction Flow</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
