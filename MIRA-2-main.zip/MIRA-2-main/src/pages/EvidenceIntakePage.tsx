import React, { useState, useRef } from 'react';
import { useForensic } from '../context/ForensicContext';

export const EvidenceIntakePage: React.FC = () => {
  const {
    currentCase,
    custodyHistory,
    intakeEvidenceFile,
    setActiveRoute,
    showToast,
  } = useForensic();

  const [isDragging, setIsDragging] = useState(false);
  const [technicalDetailsOpen, setTechnicalDetailsOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files);
      for (const file of files) {
        await handleProcessFile(file);
      }
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      for (const file of files) {
        await handleProcessFile(file);
      }
      e.target.value = '';
    }
  };

  const handleProcessFile = async (file: File) => {
    // Client-side validations
    if (!file) {
      showToast('No file selected. Please select a valid evidence file.', 'error');
      return;
    }

    if (file.size === 0) {
      showToast(`File is empty: "${file.name}" contains 0 bytes.`, 'error');
      return;
    }

    const maxSizeBytes = 200 * 1024 * 1024; // 200 MB
    if (file.size > maxSizeBytes) {
      showToast(`File is too large: "${file.name}" exceeds 200 MB limit.`, 'error');
      return;
    }

    const ext = file.name.includes('.') ? file.name.substring(file.name.lastIndexOf('.')).toLowerCase() : '';
    const allowed = [
      '.txt', '.json', '.pdf', '.eml', '.jpg', '.jpeg', '.png',
      '.raw', '.dd', '.img', '.e01', '.zip', '.bin', '.iso', '.csv', '.log', '.dat'
    ];
    if (ext && !allowed.includes(ext)) {
      showToast(`Unsupported file type (${ext}). Supported formats: TXT, JSON, PDF, EML, JPG, PNG, RAW, DD, IMG, E01, ZIP.`, 'error');
      return;
    }

    const cleanName = file.name.replace(/\\/g, '/').split('/').pop()?.replace(/[^a-zA-Z0-9._-]/g, '_') || file.name;
    const isDuplicate = uploadedFilesList.some((uf: any) => uf.name === cleanName || uf.name === file.name);
    if (isDuplicate) {
      showToast(`Duplicate file detected: Re-verifying "${file.name}" under ISO/IEC 27037...`, 'info');
    } else {
      showToast(`Uploading ${file.name} to forensic workstation...`, 'info');
    }

    try {
      await intakeEvidenceFile(file, 'Imported via Forensic Intake Interface');
      showToast(`File uploaded successfully: ${file.name}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Upload failed — please try again', 'error');
    }
  };

  const uploadedFilesList = (currentCase as any)?.uploadedFiles || [];

  return (
    <div className="pt-20 px-6 lg:px-8 pb-12 space-y-6 max-w-[1440px] mx-auto animate-in fade-in duration-200">
      {/* 1. Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Evidence Intake</h1>
        <p className="text-xs text-slate-500 mt-1">
          Import a forensic image, disk snapshot, memory dump, or recovered evidence file for analysis.
        </p>
      </div>

      {/* 2. Large Drag & Drop Box matching screenshot */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`w-full py-16 px-6 rounded-2xl border-2 border-dashed text-center flex flex-col items-center justify-center transition-all ${
          isDragging
            ? 'border-blue-500 bg-blue-50/60 ring-4 ring-blue-500/20'
            : 'border-blue-200/90 bg-blue-50/20 hover:bg-blue-50/40'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".txt,.json,.pdf,.eml,.jpg,.jpeg,.png,.raw,.dd,.img,.e01,.zip,.bin,.iso,.csv,.log,.dat"
          onChange={handleFileChange}
          className="hidden"
        />

        {/* Cloud Upload Icon */}
        <div className="w-16 h-16 rounded-2xl bg-white text-blue-600 shadow-xs border border-blue-100 flex items-center justify-center mb-4">
          <span className="material-symbols-outlined text-[36px]">cloud_upload</span>
        </div>

        <h3 className="text-base font-bold text-slate-900">Drag and drop evidence here</h3>
        <p className="text-xs text-slate-400 mt-1 mb-4">or</p>

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
        >
          Select Evidence File
        </button>

        <p className="text-[11px] text-slate-400 mt-5 font-mono">
          Supported formats: TXT · JSON · PDF · EML · JPG · PNG · RAW · DD · IMG · ZIP · BIN
        </p>
      </div>

      {/* 2.5 Ingested Evidence Files List (if any files uploaded) */}
      {uploadedFilesList.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[19px] text-emerald-600">
                task_alt
              </span>
              <h3 className="text-sm font-bold text-slate-900">Ingested Evidence Files</h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                {uploadedFilesList.length} Active {uploadedFilesList.length === 1 ? 'File' : 'Files'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setActiveRoute('evidence-explorer')}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>Explore in Evidence Dossier</span>
              <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-mono text-slate-400 uppercase">
                  <th className="pb-2 font-semibold">Evidence Name</th>
                  <th className="pb-2 font-semibold">Type</th>
                  <th className="pb-2 font-semibold">Size</th>
                  <th className="pb-2 font-semibold">SHA-256 Digest</th>
                  <th className="pb-2 font-semibold">Status</th>
                  <th className="pb-2 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 font-sans">
                {uploadedFilesList.map((uf: any, idx: number) => (
                  <tr key={uf.id || idx} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-2.5 font-bold text-slate-900 flex items-center gap-2">
                      <span className="material-symbols-outlined text-[16px] text-blue-600">
                        description
                      </span>
                      <span>{uf.name}</span>
                    </td>
                    <td className="py-2.5 text-slate-600 font-mono text-[11px]">{uf.type}</td>
                    <td className="py-2.5 text-slate-600 font-mono text-[11px]">{uf.size}</td>
                    <td className="py-2.5 text-slate-500 font-mono text-[11px]">
                      {uf.sha256 ? `${uf.sha256.substring(0, 10)}...${uf.sha256.slice(-4)}` : 'Verified'}
                    </td>
                    <td className="py-2.5">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <span className="material-symbols-outlined text-[12px]">check</span>
                        {uf.status || 'Verified Bit-Perfect'}
                      </span>
                    </td>
                    <td className="py-2.5 text-right space-x-2">
                      <button
                        type="button"
                        onClick={() => setActiveRoute('recovery-analysis')}
                        className="text-[11px] font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
                      >
                        Recovery Scan
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Bottom Grid: Evidence Details + Chain of Custody */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Card: Evidence Details (7 Cols) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[19px] text-blue-600">
                description
              </span>
              <h3 className="text-sm font-bold text-slate-900">Evidence Details</h3>
            </div>
            <span className="material-symbols-outlined text-[18px] text-slate-400">
              expand_more
            </span>
          </div>

          {/* Details 2x3 Grid matching screenshot */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-4 gap-x-8 text-xs">
            <div>
              <span className="text-[11px] text-slate-400 font-medium block">Evidence ID</span>
              <span className="font-bold text-slate-900 font-mono mt-0.5 block">
                {currentCase?.id || 'CASE-2026-091'}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-medium block">Acquisition Date</span>
              <span className="font-bold text-slate-900 font-mono mt-0.5 block">
                25 Sep 2026, 14:32
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-medium block">Source</span>
              <span className="font-bold text-slate-900 mt-0.5 block">
                {currentCase?.deviceModel || 'Samsung SSD Image'}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-medium block">SHA-256</span>
              <span className="font-bold text-slate-800 font-mono text-[11px] mt-0.5 block truncate">
                a8f4e2c6d7b9...l91d2
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-medium block">Size</span>
              <span className="font-bold text-slate-900 font-mono mt-0.5 block">
                {currentCase?.driveSizeFormatted || '512 GB'}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-medium block">
                Verification Status
              </span>
              <div className="mt-1">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <span className="material-symbols-outlined text-[13px]">check</span>
                  Verified
                </span>
              </div>
            </div>
          </div>

          {/* Sub-Card: Technical Details */}
          <div
            onClick={() => setTechnicalDetailsOpen(prev => !prev)}
            className="p-3.5 bg-slate-50/70 hover:bg-slate-100/70 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100">
                <span className="material-symbols-outlined text-[18px]">settings</span>
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Technical Details</h4>
                <p className="text-[11px] text-slate-500">
                  View detailed metadata, partition information and hash values.
                </p>
              </div>
            </div>
            <span className="material-symbols-outlined text-[18px] text-slate-400">
              {technicalDetailsOpen ? 'expand_less' : 'chevron_right'}
            </span>
          </div>

          {/* Expanded Technical Details */}
          {technicalDetailsOpen && (
            <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs font-mono space-y-2 animate-in fade-in duration-150">
              <div className="flex justify-between text-slate-600">
                <span>File System:</span>
                <span className="font-bold text-slate-900">NTFS (Cluster Size: 4,096 bytes)</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Total Sectors:</span>
                <span className="font-bold text-slate-900">524,288 LBA Blocks</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Write-Block Device:</span>
                <span className="font-bold text-slate-900">Tableau T8u Forensic Bridge</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Full SHA-256:</span>
                <span className="text-blue-700 text-[10px] break-all select-all">
                  a8f4e2c6d7b90124bc98129034ff9821ac3e7b1a098234cd9021e89bca7145de
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Right Card: Chain of Custody (5 Cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="material-symbols-outlined text-[19px] text-blue-600">
              assignment
            </span>
            <h3 className="text-sm font-bold text-slate-900">Chain of Custody</h3>
          </div>

          {/* Vertical Stepper matching screenshot */}
          <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-blue-200">
            {/* Step 1 */}
            <div className="relative">
              <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <span className="material-symbols-outlined text-[12px]">check</span>
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Evidence Acquired</h4>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                  25 Sep 2026, 14:32 · Forensic Analyst
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <span className="material-symbols-outlined text-[12px]">check</span>
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Hash Verified</h4>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                  SHA-256 matched · 25 Sep 2026, 14:36
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <span className="material-symbols-outlined text-[12px]">check</span>
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Integrity Confirmed</h4>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                  No tampering detected · 25 Sep 2026, 14:40
                </p>
              </div>
            </div>
          </div>

          {/* Blue Callout Pill Container */}
          <div className="p-3.5 bg-blue-50/70 border border-blue-100 rounded-xl flex items-center gap-2.5 text-xs text-blue-900">
            <span className="material-symbols-outlined text-[20px] text-blue-600 shrink-0">
              verified_user
            </span>
            <span className="text-[11px] font-medium leading-relaxed">
              This evidence has been verified and is ready for analysis.
            </span>
          </div>

          <button
            type="button"
            onClick={() => setActiveRoute('recovery-analysis')}
            className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
          >
            <span>Proceed to Recovery Analysis</span>
            <span className="material-symbols-outlined text-[15px]">arrow_forward</span>
          </button>
        </div>
      </div>
    </div>
  );
};
