import React, { useState } from 'react';
import { useForensic } from '../context/ForensicContext';
import { DEFAULT_AI_FINDINGS } from '../data/forensicIntelligenceData';
import { AiInsightFinding } from '../types/forensic';
import { AiConfidenceMeter } from '../components/common/AiConfidenceMeter';
import { AnomalyRiskBanner } from '../components/common/AnomalyRiskBanner';
import { FinalReportModal } from '../components/modals/FinalReportModal';

export const AiInsightsPage: React.FC = () => {
  const { currentCase, artifacts, setActiveRoute } = useForensic();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedWhyIds, setExpandedWhyIds] = useState<Record<string, boolean>>({
    'FND-001': true,
  });
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const toggleWhy = (id: string) => {
    setExpandedWhyIds(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const categories = [
    { id: 'all', label: 'All Findings' },
    { id: 'key_finding', label: 'Key Findings' },
    { id: 'pattern', label: 'Patterns' },
    { id: 'relationship', label: 'Relationships' },
    { id: 'anomaly', label: 'Anomalies' },
    { id: 'risk', label: 'Potential Risks' },
  ];

  const filteredFindings = DEFAULT_AI_FINDINGS.filter(
    f => selectedCategory === 'all' || f.category === selectedCategory
  );

  const getImportanceBadge = (importance: AiInsightFinding['importance']) => {
    switch (importance) {
      case 'CRITICAL':
        return 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800';
      case 'HIGH':
        return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800';
      case 'MEDIUM':
        return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-cyan-300 dark:border-blue-800';
      case 'LOW':
        return 'bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700';
    }
  };

  return (
    <div className="pt-20 px-4 sm:px-6 lg:px-12 pb-16 max-w-[1500px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
              AI Insight Engine
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Explainable Heuristic Reasoning</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            AI Insights &amp; Forensic Reasoning
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Deep analytical reasoning distinguishing <span className="text-blue-600 dark:text-cyan-400 font-semibold">Observed Evidence</span>, <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Recovered Information</span>, and <span className="text-purple-600 dark:text-purple-400 font-semibold">AI Inferences</span>.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setActiveRoute('evidence-explorer')}
            className="px-3.5 py-2 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">folder_open</span>
            <span>View Evidence Explorer</span>
          </button>
          <button
            type="button"
            onClick={() => setIsReportModalOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">summarize</span>
            <span>Generate Final Report</span>
          </button>
        </div>
      </div>

      {/* Anomaly & Risk Alerts Dedicated Section */}
      <AnomalyRiskBanner />

      {/* Top 3 Intelligence Metric Gauges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="mira-card-3d bg-white dark:bg-slate-900/80 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Neural Match Confidence</span>
            <span className="material-symbols-outlined text-[20px] text-blue-600 dark:text-cyan-400">psychology</span>
          </div>
          <div className="text-3xl font-bold text-slate-900 dark:text-white font-mono">
            {currentCase?.metrics?.reconstructionConfidence || 95}%
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Correlated across magic byte headers, Shannon entropy gradients, and LBA sequential continuity.
          </p>
        </div>

        <div className="mira-card-3d bg-white dark:bg-slate-900/80 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Boundary Continuity Model</span>
            <span className="material-symbols-outlined text-[20px] text-emerald-600 dark:text-emerald-400">hub</span>
          </div>
          <div className="text-3xl font-bold text-emerald-600 dark:text-emerald-400 font-mono">
            98.2%
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Fragments clustered into contiguous file representations with verified bitstream integrity.
          </p>
        </div>

        <div className="mira-card-3d bg-white dark:bg-slate-900/80 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">ISO/IEC 27037 Integrity</span>
            <span className="material-symbols-outlined text-[20px] text-purple-600 dark:text-purple-400">verified</span>
          </div>
          <div className="text-3xl font-bold text-slate-900 dark:text-white font-mono">
            100% Bit-Perfect
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Dual SHA-256 and MD5 cryptographic hashes validated against original acquisition image.
          </p>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900/90 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs overflow-x-auto w-fit">
        {categories.map(cat => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-cyan-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Findings Grid with Explainable AI ("Why this finding?") */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredFindings.map(finding => {
          const isWhyExpanded = !!expandedWhyIds[finding.id];

          return (
            <div
              key={finding.id}
              className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4 flex flex-col justify-between transition-all"
            >
              <div className="space-y-3">
                {/* Header: Title + Badges */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500 font-bold block mb-1">
                      {finding.id}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                      {finding.title}
                    </h3>
                  </div>

                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border shrink-0 uppercase ${getImportanceBadge(
                      finding.importance
                    )}`}
                  >
                    {finding.importance}
                  </span>
                </div>

                {/* Explanation */}
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {finding.explanation}
                </p>

                {/* Confidence Bar Meter */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Certainty Score</span>
                  <AiConfidenceMeter
                    confidence={finding.confidence}
                    showWhyButton={false}
                  />
                </div>
              </div>

              {/* Explainable AI: Expandable "Why this finding?" Section */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => toggleWhy(finding.id)}
                  className="w-full flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:text-blue-700 dark:hover:text-cyan-300 bg-blue-50/50 dark:bg-slate-850 p-2.5 rounded-xl border border-blue-100 dark:border-slate-700/80 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px]">psychology</span>
                    <span>Explainable Reasoning</span>
                    {finding.matchedFragmentsCount && (
                      <span className="text-[10px] bg-white dark:bg-slate-900 px-1.5 py-0.2 rounded font-mono text-slate-600 dark:text-slate-300 border border-blue-200 dark:border-slate-700">
                        {finding.matchedFragmentsCount} fragments
                      </span>
                    )}
                  </div>
                  <span
                    className={`material-symbols-outlined text-[16px] transition-transform duration-200 ${
                      isWhyExpanded ? 'rotate-180' : ''
                    }`}
                  >
                    expand_more
                  </span>
                </button>

                {/* Expandable Body */}
                {isWhyExpanded && (
                  <div className="mt-2.5 p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 text-xs text-slate-700 dark:text-slate-300 animate-in fade-in duration-150">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">
                      Evidentiary Rationale:
                    </span>
                    <ul className="space-y-1.5">
                      {finding.whyReasons.map((reason, rIdx) => (
                        <li key={rIdx} className="flex items-start gap-2 text-[11px] leading-relaxed text-slate-700 dark:text-slate-300">
                          <span className="material-symbols-outlined text-[14px] text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0">
                            check_circle
                          </span>
                          <span>{reason}</span>
                        </li>
                      ))}
                    </ul>

                    {finding.timestamp && (
                      <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[10px] font-mono text-slate-500 dark:text-slate-400">
                        <span>Timestamp: {finding.timestamp}</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold">ISO/IEC 27037 Validated</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* One-Click Final Report Modal */}
      <FinalReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
      />
    </div>
  );
};
