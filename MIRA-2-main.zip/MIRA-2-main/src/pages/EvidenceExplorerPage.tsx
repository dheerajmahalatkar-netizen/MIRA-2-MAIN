import React, { useState } from 'react';
import { useForensic } from '../context/ForensicContext';
import { ReconstructedFile, ForensicArtifact } from '../types/forensic';
import { AiConfidenceMeter } from '../components/common/AiConfidenceMeter';
import { DEFAULT_FRAGMENT_PIPELINES, DEFAULT_TIMELINE_EVENTS } from '../../src/data/forensicIntelligenceData';

export const EvidenceExplorerPage: React.FC = () => {
  const {
    artifacts,
    reconstructedFiles,
    currentCase,
    setActiveRoute,
    downloadArtifact,
    downloadFileBitstream,
    setSelectedReconstructedFile,
    setFileDetailModalOpen,
    showToast,
  } = useForensic();

  // Search & Multi-Filters
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedConfidenceTier, setSelectedConfidenceTier] = useState<string>('all');
  const [selectedSource, setSelectedSource] = useState<string>('all');
  const [selectedImportance, setSelectedImportance] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  const [selectedItemId, setSelectedItemId] = useState<string>(
    reconstructedFiles[0]?.id || 'REC-01'
  );

  // Active Selected File
  const activeFile: ReconstructedFile =
    reconstructedFiles.find(f => f.id === selectedItemId) ||
    reconstructedFiles[0] || {
      id: 'REC-01',
      fileName: 'financial_records.xlsx',
      fileType: 'Document',
      size: '12.4 MB',
      sizeBytes: 13002488,
      confidence: 96,
      status: 'reconstructed',
      signatureMatchPct: 89,
      metadataContinuityPct: 76,
      sectorRelationshipPct: 64,
      structuralSimilarityPct: 58,
      sha256: 'a8f4c931b2e47d890f12c448a609d1e43b92f708231947b198c614b8991d2e5a',
      md5: '4f7d29c8e10b2849a602de82049e29a1',
    };

  // Associated Pipeline & Timeline events for detailed panel
  const relatedPipeline = DEFAULT_FRAGMENT_PIPELINES.find(
    p => p.fileName === activeFile.fileName || p.fileId === activeFile.id
  ) || DEFAULT_FRAGMENT_PIPELINES[0];

  const relatedEvents = DEFAULT_TIMELINE_EVENTS.filter(
    e =>
      e.relatedEvidenceName?.toLowerCase().includes(activeFile.fileName.toLowerCase()) ||
      e.relatedEvidenceId === activeFile.id
  );

  // Filter application
  const filteredFiles = reconstructedFiles.filter(file => {
    // Search
    const q = search.toLowerCase().trim();
    const matchesSearch =
      q === '' ||
      file.fileName.toLowerCase().includes(q) ||
      file.id.toLowerCase().includes(q) ||
      file.fileType.toLowerCase().includes(q) ||
      (file.sha256 && file.sha256.toLowerCase().includes(q));

    if (!matchesSearch) return false;

    // Type filter
    if (selectedType !== 'all') {
      if (selectedType === 'document' && file.fileType !== 'Document' && file.fileType !== 'Spreadsheet')
        return false;
      if (selectedType === 'database' && file.fileType !== 'Database') return false;
      if (selectedType === 'archive' && file.fileType !== 'Archive') return false;
      if (selectedType === 'token' && file.fileType !== 'JSON' && file.fileType !== 'Configuration')
        return false;
    }

    // Confidence tier
    if (selectedConfidenceTier === 'high' && file.confidence < 90) return false;
    if (
      selectedConfidenceTier === 'medium' &&
      (file.confidence < 70 || file.confidence >= 90)
    )
      return false;
    if (selectedConfidenceTier === 'low' && file.confidence >= 70) return false;

    return true;
  });

  const handleInspectModal = (file: ReconstructedFile) => {
    setSelectedReconstructedFile(file);
    setFileDetailModalOpen(true);
  };

  return (
    <div className="pt-20 px-6 lg:px-12 pb-16 max-w-[1500px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600">
              Forensic Repository
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500">ISO/IEC 27037 Evidence Store</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight">
            Evidence Explorer
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Comprehensive evidence browser with multi-dimensional filtering, fragment correlation, and detailed artifact inspection.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setActiveRoute('reconstruction')}
            className="px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">arrow_back</span>
            <span>Reconstruction Flow</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveRoute('relationship-graph')}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <span>Relationship Graph</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* Main Layout: Browser + Detailed Side Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Multi-filter Controls + Evidence Table/Cards (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-xs">
          {/* Smart Search Bar */}
          <div className="relative">
            <span className="material-symbols-outlined text-[18px] text-slate-400 absolute left-3 top-2.5">
              search
            </span>
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search evidence by name, ID, checksum, or keywords (e.g. 'high confidence', 'xlsx')..."
              className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-500 placeholder:text-slate-400"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              {/* Type Filter */}
              <select
                value={selectedType}
                onChange={e => setSelectedType(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                <option value="all">Type: All</option>
                <option value="document">Documents</option>
                <option value="database">Databases</option>
                <option value="archive">Archives</option>
                <option value="token">Credentials &amp; Tokens</option>
              </select>

              {/* Confidence Filter */}
              <select
                value={selectedConfidenceTier}
                onChange={e => setSelectedConfidenceTier(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                <option value="all">Confidence: All</option>
                <option value="high">High (≥90%)</option>
                <option value="medium">Medium (70-89%)</option>
                <option value="low">Low (&lt;70%)</option>
              </select>

              {/* Source Filter */}
              <select
                value={selectedSource}
                onChange={e => setSelectedSource(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                <option value="all">Source: All</option>
                <option value="lba">LBA Sectors</option>
                <option value="slack">Slack Space</option>
                <option value="unallocated">Unallocated Clusters</option>
              </select>
            </div>

            {/* View Mode Toggle (Table / Cards) */}
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`p-1 rounded transition-colors cursor-pointer ${
                  viewMode === 'table' ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-500'
                }`}
                title="Table view"
              >
                <span className="material-symbols-outlined text-[16px]">table_rows</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('cards')}
                className={`p-1 rounded transition-colors cursor-pointer ${
                  viewMode === 'cards' ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-500'
                }`}
                title="Cards view"
              >
                <span className="material-symbols-outlined text-[16px]">grid_view</span>
              </button>
            </div>
          </div>

          {/* Table / Cards List */}
          {viewMode === 'table' ? (
            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase text-[10px] font-semibold tracking-wider">
                    <th className="py-2.5 px-3">File Name</th>
                    <th className="py-2.5 px-2">Type</th>
                    <th className="py-2.5 px-2">Size</th>
                    <th className="py-2.5 px-2">Confidence</th>
                    <th className="py-2.5 px-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredFiles.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400">
                        No evidence items match the filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredFiles.map(file => {
                      const isSelected = activeFile.id === file.id;

                      return (
                        <tr
                          key={file.id}
                          onClick={() => setSelectedItemId(file.id)}
                          className={`hover:bg-slate-50 transition-colors cursor-pointer ${
                            isSelected ? 'bg-blue-50/70 font-semibold' : ''
                          }`}
                        >
                          <td className="py-2.5 px-3">
                            <div className="flex items-center gap-2">
                              <span className="material-symbols-outlined text-[17px] text-blue-600 shrink-0">
                                {file.fileType === 'Database'
                                  ? 'database'
                                  : file.fileType === 'Document'
                                  ? 'description'
                                  : 'draft'}
                              </span>
                              <div>
                                <span className="font-mono text-xs font-bold text-slate-900 block truncate max-w-[170px]">
                                  {file.fileName}
                                </span>
                                <span className="font-mono text-[10px] text-slate-400">
                                  {file.id}
                                </span>
                              </div>
                            </div>
                          </td>
                          <td className="py-2.5 px-2 text-slate-600">{file.fileType}</td>
                          <td className="py-2.5 px-2 font-mono text-slate-600">{file.size}</td>
                          <td className="py-2.5 px-2">
                            <AiConfidenceMeter
                              confidence={file.confidence}
                              size="sm"
                              whyExplanation={`File validated via ${file.signatureMatchPct || 90}% magic byte match.`}
                            />
                          </td>
                          <td className="py-2.5 px-2 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={e => {
                                  e.stopPropagation();
                                  handleInspectModal(file);
                                }}
                                className="p-1 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded transition-colors"
                                title="Inspect Details"
                              >
                                <span className="material-symbols-outlined text-[16px]">visibility</span>
                              </button>
                              <button
                                type="button"
                                onClick={e => {
                                  e.stopPropagation();
                                  downloadFileBitstream(file);
                                }}
                                className="p-1 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded transition-colors"
                                title="Download Bitstream"
                              >
                                <span className="material-symbols-outlined text-[16px]">download</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            /* Cards View */
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredFiles.map(file => {
                const isSelected = activeFile.id === file.id;

                return (
                  <div
                    key={file.id}
                    onClick={() => setSelectedItemId(file.id)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-2 ${
                      isSelected
                        ? 'bg-blue-50/70 border-blue-500 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-white hover:bg-slate-50 border-slate-200 shadow-2xs'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] text-slate-400 font-bold">
                        {file.id}
                      </span>
                      <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                        {file.verificationStatus || 'Verified'}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 font-mono truncate" title={file.fileName}>
                      {file.fileName}
                    </h4>

                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>{file.fileType}</span>
                      <span className="font-mono">{file.size}</span>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400">Confidence</span>
                      <AiConfidenceMeter confidence={file.confidence} size="sm" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Detailed Evidence Panel (5 Cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-6 space-y-5 shadow-xs">
          {/* Header */}
          <div className="border-b border-slate-200 pb-4">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-600">
                Evidence Information
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                {activeFile.verificationStatus || 'ISO/IEC 27037 Verified'}
              </span>
            </div>
            <h3 className="text-base font-bold text-slate-900 font-mono break-words">
              {activeFile.fileName}
            </h3>
            <span className="text-xs text-slate-500 mt-0.5 block font-mono">
              ID: {activeFile.id} · Size: {activeFile.size} · Type: {activeFile.fileType}
            </span>
          </div>

          {/* AI Confidence Meter with Why */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800">AI Confidence Level</span>
              <AiConfidenceMeter
                confidence={activeFile.confidence}
                whyExplanation={`File rebuilt from ${relatedPipeline.fragments.length} fragments with ${activeFile.signatureMatchPct || 92}% signature match and continuous LBA sector offsets.`}
              />
            </div>
          </div>

          {/* Related Fragments Section */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-900 flex items-center justify-between">
              <span>Related Fragments ({relatedPipeline.fragments.length})</span>
              <span className="text-[10px] font-mono text-slate-400">Visual Flow</span>
            </h4>
            <div className="space-y-1.5">
              {relatedPipeline.fragments.map(frag => (
                <div
                  key={frag.id}
                  className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-slate-900">{frag.id}</span>
                      <span className="text-slate-400">·</span>
                      <span className="font-medium text-slate-700">{frag.sourceType}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {frag.timestamp} · Offset {frag.sectorOffset}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-emerald-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {frag.confidence}%
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Related Events Section */}
          {relatedEvents.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-900">
                Related Chronological Events ({relatedEvents.length})
              </h4>
              <div className="space-y-1.5 text-xs">
                {relatedEvents.map(evt => (
                  <div
                    key={evt.id}
                    className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-2"
                  >
                    <span className="material-symbols-outlined text-[15px] text-blue-600 mt-0.5 shrink-0">
                      schedule
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5 font-bold text-slate-900">
                        <span>{evt.time}</span>
                        <span className="text-slate-400">·</span>
                        <span>{evt.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">{evt.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Metadata & Checksums */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2 text-xs font-mono">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-sans font-bold">
                SHA-256 Checksum:
              </span>
              <span className="text-blue-700 text-[11px] break-all select-all font-medium">
                {activeFile.sha256}
              </span>
            </div>
            <div className="pt-1 border-t border-slate-200">
              <span className="text-[10px] text-slate-500 uppercase block font-sans font-bold">
                MD5 Checksum:
              </span>
              <span className="text-slate-800 text-[11px] break-all select-all">
                {activeFile.md5}
              </span>
            </div>
          </div>

          {/* AI Observations Callout */}
          <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-lg text-xs space-y-1 text-slate-700">
            <div className="flex items-center gap-1.5 text-blue-800 font-bold">
              <span className="material-symbols-outlined text-[16px]">psychology</span>
              <span>AI Observation &amp; Provenance</span>
            </div>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Magic byte verification matches offset 0x0000. Sequential LBA clusters #12–#14 exhibit
              uniform page size (4096 bytes) and valid internal cell pointers without fragmentation
              contamination.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <button
              type="button"
              onClick={() => handleInspectModal(activeFile)}
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">visibility</span>
              <span>Open Forensic Hex Inspector Modal</span>
            </button>
            <button
              type="button"
              onClick={() => downloadFileBitstream(activeFile)}
              className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              <span>Download Reconstructed Bitstream ({activeFile.size})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
