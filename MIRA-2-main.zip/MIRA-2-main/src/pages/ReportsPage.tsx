import React, { useState } from 'react';
import { useForensic } from '../context/ForensicContext';
import { FinalReportModal } from '../components/modals/FinalReportModal';

export const ReportsPage: React.FC = () => {
  const { currentCase, artifacts, custodyHistory, exportCustodyPdf, setActiveRoute, setPdfModalOpen, showToast } = useForensic();
  const [isFinalReportModalOpen, setIsFinalReportModalOpen] = useState(false);

  const handleExportQuickPdf = () => {
    showToast('Exporting ISO/IEC 27037 Attestation Report PDF...', 'info');
    exportCustodyPdf();
  };

  return (
    <div className="pt-20 px-4 sm:px-6 lg:px-12 pb-16 max-w-[1500px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
              Evidentiary Records
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Court-Admissible ISO/IEC 27037 Attestations</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Forensic Reports &amp; Attestations
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Export signed forensic reports, cryptographic chain-of-custody ledgers, and candidate reconstruction dossiers.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setActiveRoute('report')}
            className="px-3.5 py-2 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">print</span>
            <span>Examination Sheet</span>
          </button>
          <button
            type="button"
            onClick={() => setIsFinalReportModalOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">summarize</span>
            <span>Generate Final Report</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Card 1: Official Attestation Dossier */}
        <div className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/80 text-blue-600 dark:text-cyan-400 flex items-center justify-center border border-blue-200 dark:border-blue-800/80">
              <span className="material-symbols-outlined text-[22px]">verified</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                MIRA Final Dossier &amp; Attestation
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Executive summary, reconstructed evidence list, timeline, relationship graph summary, and ISO/IEC 27037 verification.
              </p>
            </div>
            <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono space-y-1 text-slate-600 dark:text-slate-300">
              <div>Case: {currentCase?.id || 'CASE-2026-091'}</div>
              <div>Examiner: {currentCase?.examiner || 'Abhishek · Lead Analyst'}</div>
              <div className="text-emerald-600 dark:text-emerald-400 font-semibold">Integrity: Verified Bit-Perfect</div>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <button
              type="button"
              onClick={() => setIsFinalReportModalOpen(true)}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">description</span>
              <span>Generate Final Report</span>
            </button>
            <button
              type="button"
              onClick={handleExportQuickPdf}
              className="w-full py-2 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[15px]">download</span>
              <span>Download PDF Ledger</span>
            </button>
          </div>
        </div>

        {/* Card 2: Chain of Custody History */}
        <div className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-200 dark:border-emerald-800/80">
              <span className="material-symbols-outlined text-[22px]">history_edu</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Chain of Custody Ledger
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Timestamped audit log tracking evidence acquisition, hash verification, hardware mounts, and examiner checkouts.
              </p>
            </div>
            <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1 text-slate-600 dark:text-slate-300">
              <div className="flex items-center justify-between">
                <span>Recorded Events:</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{custodyHistory.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Standard Alignment:</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">ISO/IEC 27037 §6.4</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Hardware Seal:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">Tableau T8u Bridge</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setPdfModalOpen(true)}
            className="w-full py-2.5 px-4 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px] text-cyan-600 dark:text-cyan-400">visibility</span>
            <span>Inspect Custody Certificate</span>
          </button>
        </div>

        {/* Card 3: Artifact Reconstruction Dossier */}
        <div className="mira-card-3d bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center border border-amber-200 dark:border-amber-800/80">
              <span className="material-symbols-outlined text-[22px]">inventory_2</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Artifact Carving Dossier
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Full technical manifest detailing recovered files, fragmented sector mappings, and entropy continuity graphs.
              </p>
            </div>
            <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1 text-slate-600 dark:text-slate-300">
              <div className="flex items-center justify-between">
                <span>Recovered Candidates:</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{artifacts.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Critical Triage:</span>
                <span className="font-semibold text-rose-600 dark:text-rose-400">
                  {artifacts.filter(a => a.triage === 'CRITICAL').length} Items
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Mean Confidence:</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">95%</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveRoute('evidence-explorer')}
            className="w-full py-2.5 px-4 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px] text-cyan-600 dark:text-cyan-400">folder_open</span>
            <span>Open Artifact Manifest</span>
          </button>
        </div>
      </div>

      <FinalReportModal
        isOpen={isFinalReportModalOpen}
        onClose={() => setIsFinalReportModalOpen(false)}
      />
    </div>
  );
};
