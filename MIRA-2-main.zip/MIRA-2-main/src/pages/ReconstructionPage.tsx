import React, { useState, useEffect, useRef } from 'react';
import { useForensic } from '../context/ForensicContext';
import { ReconstructedFile } from '../types/forensic';
import { FragmentRecoveryPipeline } from '../components/common/FragmentRecoveryPipeline';

export const ReconstructionPage: React.FC = () => {
  const {
    reconstructedFiles,
    reconstructionStats,
    setActiveRoute,
    showToast,
    selectedReconstructedFile,
    setSelectedReconstructedFile,
    setFileDetailModalOpen,
    downloadFileBitstream,
    batchRebuildFiles,
  } = useForensic();

  // Active selected file for right-hand preview
  const [selectedFileId, setSelectedFileId] = useState<string>('REC-01');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterDropdownOpen, setFilterDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isBatchRebuilding, setIsBatchRebuilding] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync selected file
  useEffect(() => {
    if (selectedReconstructedFile) {
      setSelectedFileId(selectedReconstructedFile.id);
    } else if (reconstructedFiles.length > 0) {
      setSelectedFileId(reconstructedFiles[0].id);
      setSelectedReconstructedFile(reconstructedFiles[0]);
    }
  }, [selectedReconstructedFile, reconstructedFiles, setSelectedReconstructedFile]);

  // Click outside listener for filter dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setFilterDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedFile: ReconstructedFile =
    reconstructedFiles.find(f => f.id === selectedFileId) ||
    reconstructedFiles[0] || {
      id: 'REC-01',
      fileName: 'financial_records.xlsx',
      fileType: 'Document',
      size: '12.4 MB',
      sizeBytes: 13002488,
      confidence: 96,
      status: 'reconstructed',
      signatureMatchPct: 89,
      metadataContinuityPct: 76,
      sectorRelationshipPct: 64,
      structuralSimilarityPct: 58,
      sha256: 'a8f4c931b2e47d890f12c448a609d1e43b92f708231947b198c614b8991d2e5a',
      md5: '4f7d29c8e10b2849a602de82049e29a1',
    };

  const handleSelectFile = (file: ReconstructedFile) => {
    setSelectedFileId(file.id);
    setSelectedReconstructedFile(file);
  };

  const handleOpenDetails = () => {
    setSelectedReconstructedFile(selectedFile);
    setFileDetailModalOpen(true);
  };

  const handleDownload = () => {
    downloadFileBitstream(selectedFile);
  };

  const handleBatchRebuild = async () => {
    setIsBatchRebuilding(true);
    try {
      await batchRebuildFiles();
    } finally {
      setIsBatchRebuilding(false);
    }
  };

  const filteredFiles = reconstructedFiles.filter(f => {
    const matchesSearch = searchQuery.trim() === '' || 
      f.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.fileType.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterType === 'all') return true;
    if (filterType === 'document') return f.fileType.toLowerCase() === 'document';
    if (filterType === 'database') return f.fileType.toLowerCase() === 'database';
    if (filterType === 'archive') return f.fileType.toLowerCase() === 'archive';
    if (filterType === 'image') return f.fileType.toLowerCase() === 'image';
    if (filterType === 'text') return f.fileType.toLowerCase() === 'text';
    return true;
  });

  const progress = reconstructionStats?.progressPercent || 68;
  const dashOffset = Math.max(0, 251.2 - (251.2 * progress) / 100);

  return (
    <div className="pt-20 px-8 pb-12 max-w-[1440px] mx-auto space-y-6 animate-in fade-in duration-200">
      {/* BEGIN: PageHeader */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Fragment Reconstruction
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Analyze relationships between fragments and reconstruct recoverable files.
          </p>
        </div>
        <button
          onClick={() => setActiveRoute('recovery-analysis')}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 shadow-2xs transition-colors cursor-pointer"
          type="button"
          title="Return to Recovery Analysis scan"
        >
          <svg className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path d="M10 19l-7-7m0 0l7-7m-7 7h18" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
          </svg>
          <span>Back to Analysis</span>
        </button>
      </div>
      {/* END: PageHeader */}

      {/* BEGIN: StepperWorkflow */}
      <div className="bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs transition-colors">
        <div className="relative flex items-center justify-between max-w-5xl mx-auto px-4">
          {/* Connecting Progress Lines */}
          <div className="absolute left-10 right-10 top-4 h-0.5 bg-slate-200 dark:bg-slate-700 -z-0">
            <div className="h-full bg-blue-600 w-1/2 transition-all duration-500"></div>
          </div>

          {/* Step 1: Evidence (Complete) */}
          <button
            onClick={() => setActiveRoute('evidence-intake')}
            className="flex flex-col items-center text-center relative z-10 group cursor-pointer"
            type="button"
            title="Inspect Evidence Intake"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center ring-4 ring-white dark:ring-[#111827] shadow-xs mb-2 group-hover:scale-105 transition-transform">
              <svg className="w-4 h-4 stroke-[3]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round"></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 transition-colors">
              Scanning Complete
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5">12,847 fragments found</span>
          </button>

          {/* Step 2: Relationship Analysis (Complete) */}
          <button
            onClick={() => setActiveRoute('recovery-analysis')}
            className="flex flex-col items-center text-center relative z-10 group cursor-pointer"
            type="button"
            title="Inspect Recovery Analysis"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center ring-4 ring-white dark:ring-[#111827] shadow-xs mb-2 group-hover:scale-105 transition-transform">
              <svg className="w-4 h-4 stroke-[3]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round"></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 transition-colors">
              Relationship Analysis
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5">Analyzing fragment links</span>
          </button>

          {/* Step 3: Reconstruction (Current / Active) */}
          <div className="flex flex-col items-center text-center relative z-10">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center ring-4 ring-blue-100 dark:ring-blue-950 shadow-md mb-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400">Reconstruction</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Building file structures</span>
          </div>

          {/* Step 4: Verification (Pending) */}
          <button
            onClick={() => setActiveRoute('evidence-explorer')}
            className="flex flex-col items-center text-center relative z-10 group cursor-pointer"
            type="button"
            title="Proceed to Verification"
          >
            <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-400 flex items-center justify-center ring-4 ring-white dark:ring-[#111827] shadow-xs mb-2 group-hover:scale-105 transition-transform">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
              </svg>
            </div>
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 group-hover:text-blue-600 transition-colors">
              Verification
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5">Checking integrity</span>
          </button>

          {/* Step 5: Complete */}
          <button
            onClick={() => setActiveRoute('reports')}
            className="flex flex-col items-center text-center relative z-10 group cursor-pointer"
            type="button"
            title="Proceed to Reports"
          >
            <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-400 flex items-center justify-center ring-4 ring-white dark:ring-[#111827] shadow-xs mb-2 group-hover:scale-105 transition-transform">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <rect height="16" rx="2" strokeWidth="2" width="16" x="4" y="4"></rect>
              </svg>
            </div>
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 group-hover:text-blue-600 transition-colors">
              Complete
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5">Results ready</span>
          </button>
        </div>
      </div>
      {/* END: StepperWorkflow */}
      
      {/* Fragment -> Recovery Visual Pipeline */}
      <FragmentRecoveryPipeline
        onInspectReconstructed={(fileId) => {
          setSelectedFileId(fileId);
          setActiveRoute('evidence-explorer');
        }}
      />

      {/* BEGIN: MainThreeColumnLayout */}
      <div className="grid grid-cols-12 gap-5 items-start">
        {/* ================= LEFT COLUMN: Progress & Stats (4 cols) ================= */}
        <div className="col-span-12 lg:col-span-4 space-y-5">
          {/* Reconstruction Progress Card */}
          <div className="bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs space-y-5 transition-colors">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Reconstruction Progress
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                AI is analyzing fragment relationships and rebuilding file structures.
              </p>
            </div>

            {/* Circular Progress & Legend */}
            <div className="flex items-center justify-between gap-2 pt-1">
              {/* Circular Chart Gauge */}
              <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
                <svg className="w-28 h-28 transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" fill="transparent" r="40" stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeWidth="8"></circle>
                  <circle
                    cx="50"
                    cy="50"
                    fill="transparent"
                    r="40"
                    stroke="#2563eb"
                    strokeDasharray="251.2"
                    strokeDashoffset={dashOffset}
                    strokeLinecap="round"
                    strokeWidth="8"
                    className="transition-all duration-700 ease-out"
                  ></circle>
                </svg>
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <span className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                    {progress}%
                  </span>
                  <span className="text-[9px] text-slate-400 font-medium -mt-0.5">Progress</span>
                </div>
              </div>

              {/* Breakdown Legend */}
              <div className="flex-1 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    Files Reconstructed
                  </span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 font-mono">
                    {reconstructionStats?.filesReconstructed || 12}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                    <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                    In Progress
                  </span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 font-mono">
                    {reconstructionStats?.inProgress || 8}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                    <span className="w-2 h-2 rounded-full bg-slate-300 dark:bg-slate-600"></span>
                    Pending
                  </span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 font-mono">
                    {reconstructionStats?.pending || 5}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                    <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                    Failed
                  </span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 font-mono">
                    {reconstructionStats?.failed || 1}
                  </span>
                </div>
              </div>
            </div>

            {/* AI Status Info Pill Card */}
            <div className="bg-blue-50/70 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/50 rounded-lg p-3 flex gap-2.5 items-start">
              <div className="p-1 rounded bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 shrink-0">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                </svg>
              </div>
              <p className="text-[11px] leading-relaxed text-blue-900 dark:text-blue-200">
                <strong className="font-semibold">AI is matching fragments</strong> using file signatures, metadata continuity and structural patterns to rebuild files.
              </p>
            </div>
          </div>

          {/* Reconstruction Statistics Card */}
          <div className="bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs space-y-4 transition-colors">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Reconstruction Statistics
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {/* Stat 1 */}
              <div className="p-3 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-750 rounded-lg space-y-1">
                <div className="w-6 h-6 rounded bg-blue-100/70 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-1">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                  </svg>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Total Fragments Analyzed</div>
                <div className="text-base font-extrabold text-slate-900 dark:text-slate-100 font-mono">
                  {reconstructionStats?.totalFragmentsAnalyzed?.toLocaleString() || '12,847'}
                </div>
              </div>

              {/* Stat 2 */}
              <div className="p-3 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-750 rounded-lg space-y-1">
                <div className="w-6 h-6 rounded bg-indigo-100/70 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-1">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                  </svg>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Possible File Structures</div>
                <div className="text-base font-extrabold text-slate-900 dark:text-slate-100 font-mono">
                  {reconstructionStats?.possibleFileStructures?.toLocaleString() || '3,421'}
                </div>
              </div>

              {/* Stat 3 */}
              <div className="p-3 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-750 rounded-lg space-y-1">
                <div className="w-6 h-6 rounded bg-emerald-100/70 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-1">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                  </svg>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Files Reconstructed</div>
                <div className="text-base font-extrabold text-slate-900 dark:text-slate-100 font-mono">
                  {reconstructionStats?.filesReconstructed || 12}
                </div>
              </div>

              {/* Stat 4 */}
              <div className="p-3 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-750 rounded-lg space-y-1">
                <div className="w-6 h-6 rounded bg-sky-100/70 dark:bg-sky-900/50 text-sky-600 dark:text-sky-400 flex items-center justify-center mb-1">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M4 7v10c0 2 1.5 3 3.5 3h9c2 0 3.5-1 3.5-3V7c0-2-1.5-3-3.5-3h-9C5.5 4 4 5 4 7zm0 5h16M4 12c0 2 1.5 3 3.5 3h9c2 0 3.5-1 3.5-3" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                  </svg>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Estimated Recoverable</div>
                <div className="text-base font-extrabold text-slate-900 dark:text-slate-100 font-mono">
                  {reconstructionStats?.estimatedRecoverableGb || '68.4'} GB
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ================= MIDDLE COLUMN: Reconstructed Files Table (5 cols) ================= */}
        <div className="col-span-12 lg:col-span-5 bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs flex flex-col justify-between transition-colors min-h-[580px]">
          <div>
            {/* Header with Dropdown & Search */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Reconstructed Files
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Files successfully rebuilt from fragment analysis.
                </p>
              </div>

              {/* Filter Dropdown Pill */}
              <div className="flex items-center gap-2">
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setFilterDropdownOpen(prev => !prev)}
                    className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors cursor-pointer"
                    type="button"
                    aria-haspopup="true"
                    aria-expanded={filterDropdownOpen}
                  >
                    <span className="capitalize">
                      {filterType === 'all' ? `All (${reconstructedFiles.length})` : filterType}
                    </span>
                    <svg className="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path d="M19 9l-7 7-7-7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                    </svg>
                  </button>

                  {filterDropdownOpen && (
                    <div className="absolute right-0 mt-1 w-40 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg z-30 py-1 text-xs">
                      <button
                        onClick={() => { setFilterType('all'); setFilterDropdownOpen(false); }}
                        className={`w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 ${filterType === 'all' ? 'text-blue-600 font-bold' : ''}`}
                      >
                        All ({reconstructedFiles.length})
                      </button>
                      <button
                        onClick={() => { setFilterType('document'); setFilterDropdownOpen(false); }}
                        className={`w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 ${filterType === 'document' ? 'text-blue-600 font-bold' : ''}`}
                      >
                        Documents
                      </button>
                      <button
                        onClick={() => { setFilterType('database'); setFilterDropdownOpen(false); }}
                        className={`w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 ${filterType === 'database' ? 'text-blue-600 font-bold' : ''}`}
                      >
                        Databases
                      </button>
                      <button
                        onClick={() => { setFilterType('archive'); setFilterDropdownOpen(false); }}
                        className={`w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 ${filterType === 'archive' ? 'text-blue-600 font-bold' : ''}`}
                      >
                        Archives
                      </button>
                      <button
                        onClick={() => { setFilterType('image'); setFilterDropdownOpen(false); }}
                        className={`w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 ${filterType === 'image' ? 'text-blue-600 font-bold' : ''}`}
                      >
                        Images
                      </button>
                      <button
                        onClick={() => { setFilterType('text'); setFilterDropdownOpen(false); }}
                        className={`w-full text-left px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 ${filterType === 'text' ? 'text-blue-600 font-bold' : ''}`}
                      >
                        Text & Config
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Search Bar */}
            <div className="mt-3 relative">
              <span className="material-symbols-outlined absolute left-2.5 top-2 text-[16px] text-slate-400">
                search
              </span>
              <input
                type="text"
                placeholder="Search reconstructed files..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg text-xs placeholder:text-slate-400 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Reconstructed Files List Table */}
            <div className="overflow-x-auto mt-2">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="text-[11px] font-semibold text-slate-400 border-b border-slate-100 dark:border-slate-800">
                    <th className="py-2.5 pl-2 font-medium">File Name</th>
                    <th className="py-2.5 px-2 font-medium">Type</th>
                    <th className="py-2.5 px-2 font-medium">Size</th>
                    <th className="py-2.5 pr-2 font-medium text-right">Confidence</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 dark:divide-slate-800/60 font-medium">
                  {filteredFiles.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-8 text-center text-slate-400 text-xs">
                        No reconstructed files match "{searchQuery}"
                      </td>
                    </tr>
                  ) : (
                    filteredFiles.map(file => {
                      const isSelected = selectedFileId === file.id;
                      const isHigh = file.confidence >= 85;

                      return (
                        <tr
                          key={file.id}
                          onClick={() => handleSelectFile(file)}
                          className={`transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-blue-50/70 dark:bg-blue-950/50 rounded-lg font-semibold text-blue-950 dark:text-blue-100'
                              : 'hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-800 dark:text-slate-200'
                          }`}
                        >
                          <td className="py-2 pl-2 pr-2 flex items-center gap-2">
                            <span
                              className={`material-symbols-outlined text-[17px] shrink-0 ${
                                file.fileType === 'Document'
                                  ? 'text-emerald-600'
                                  : file.fileType === 'Archive'
                                  ? 'text-amber-500'
                                  : file.fileType === 'Database'
                                  ? 'text-blue-500'
                                  : file.fileType === 'Image'
                                  ? 'text-indigo-500'
                                  : 'text-slate-400'
                              }`}
                            >
                              {file.fileType === 'Document'
                                ? 'description'
                                : file.fileType === 'Archive'
                                ? 'folder_zip'
                                : file.fileType === 'Database'
                                ? 'database'
                                : file.fileType === 'Image'
                                ? 'image'
                                : 'draft'}
                            </span>
                            <span className="truncate max-w-[140px] font-mono text-xs">{file.fileName}</span>
                          </td>
                          <td className="py-2 px-2 text-slate-500 dark:text-slate-400 text-xs">{file.fileType}</td>
                          <td className="py-2 px-2 text-slate-500 dark:text-slate-400 font-mono text-xs">{file.size}</td>
                          <td className="py-2 pr-2 text-right">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                isHigh
                                  ? 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300'
                                  : 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300'
                              }`}
                            >
                              {file.confidence}%
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table Footer & Active Ongoing Task Sub-Card */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <button
              onClick={() => setActiveRoute('evidence-explorer')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 transition-colors cursor-pointer"
              type="button"
            >
              <span>View all reconstructed files</span>
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path d="M14 5l7 7m0 0l-7 7m7-7H3" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
              </svg>
            </button>

            {/* Bottom Sub-card: Reconstruction In Progress banner */}
            <div className="p-3 bg-blue-50/70 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/50 rounded-lg space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-blue-900 dark:text-blue-200 leading-tight">
                      Reconstruction in Progress
                    </h4>
                    <p className="text-[10px] text-blue-700 dark:text-blue-300">
                      {reconstructionStats?.inProgress || 8} files are currently being rebuilt. This may take a few minutes.
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleBatchRebuild}
                  disabled={isBatchRebuilding}
                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-md text-[10px] font-bold shadow-2xs shrink-0 transition-colors cursor-pointer"
                  type="button"
                  title="Trigger batch reconstruction of remaining fragments"
                >
                  {isBatchRebuilding ? 'Processing...' : 'Accelerate Batch'}
                </button>
              </div>
              <div className="w-full bg-blue-200/60 dark:bg-blue-900/40 rounded-full h-1.5 overflow-hidden">
                <div className="bg-blue-600 h-1.5 rounded-full w-2/3 animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>

        {/* ================= RIGHT COLUMN: AI Reasoning & File Preview (3 cols) ================= */}
        <div className="col-span-12 lg:col-span-3 space-y-5">
          {/* AI Reasoning Card */}
          <div className="bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs space-y-4 transition-colors">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">AI Reasoning</h3>
              <p className="text-xs text-slate-400 mt-0.5">Why these fragments were linked and reconstructed.</p>
            </div>

            {/* Reconstruction Analysis Callout */}
            <div className="p-3 bg-blue-50/60 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/50 rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-blue-700 dark:text-blue-300 font-semibold text-xs">
                <svg className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path clipRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zM12 2a1 1 0 01.967.744L14.146 7.2 17.5 9.134a1 1 0 010 1.732l-3.354 1.935-1.18 4.455a1 1 0 01-1.933 0L9.854 12.8 6.5 10.866a1 1 0 010-1.732l3.354-1.935 1.18-4.455A1 1 0 0112 2z" fillRule="evenodd"></path>
                </svg>
                <span>Reconstruction Analysis</span>
              </div>
              <p className="text-[11px] text-blue-900 dark:text-blue-200 leading-relaxed">
                Fragments were linked based on file signature, metadata continuity, sector relationship and structural similarity.
              </p>
            </div>

            {/* Key Indicators Checklist */}
            <div className="space-y-2 pt-1">
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Key Indicators</h4>
              <ul className="space-y-2 text-xs">
                <li className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <svg className="w-4 h-4 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5"></path>
                  </svg>
                  <span>File signature match ({selectedFile.signatureMatchPct || 89}%)</span>
                </li>
                <li className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <svg className="w-4 h-4 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5"></path>
                  </svg>
                  <span>Metadata continuity ({selectedFile.metadataContinuityPct || 76}%)</span>
                </li>
                <li className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <svg className="w-4 h-4 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5"></path>
                  </svg>
                  <span>Sector relationship ({selectedFile.sectorRelationshipPct || 64}%)</span>
                </li>
                <li className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <svg className="w-4 h-4 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5"></path>
                  </svg>
                  <span>Structural similarity ({selectedFile.structuralSimilarityPct || 58}%)</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Selected File Preview Card */}
          <div className="bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs space-y-4 transition-colors">
            <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 tracking-wide uppercase">
              Selected File Preview
            </h3>
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-950 border border-blue-100 dark:border-blue-900 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-[22px]">
                  {selectedFile.fileType === 'Document'
                    ? 'description'
                    : selectedFile.fileType === 'Archive'
                    ? 'folder_zip'
                    : selectedFile.fileType === 'Database'
                    ? 'database'
                    : selectedFile.fileType === 'Image'
                    ? 'image'
                    : 'draft'}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate font-mono">
                    {selectedFile.fileName}
                  </h4>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 leading-tight">
                    {selectedFile.confidence}% confidence
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  {selectedFile.size} · {selectedFile.fileType}
                </p>
              </div>
            </div>

            {/* Preview Action Buttons */}
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleOpenDetails}
                className="flex-1 py-1.5 px-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 shadow-2xs transition-colors text-center cursor-pointer"
                type="button"
              >
                View Details
              </button>
              <button
                onClick={handleDownload}
                className="p-1.5 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
                title={`Download Reconstructed Bitstream (${selectedFile.fileName})`}
                type="button"
                aria-label={`Download ${selectedFile.fileName}`}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
                </svg>
              </button>
            </div>
          </div>

          {/* Cautionary Forensic Callout */}
          <div className="p-3 bg-slate-50/80 dark:bg-slate-850 border border-slate-200 dark:border-slate-750 rounded-lg flex items-start gap-2.5">
            <svg className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
            </svg>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
              Some files may be partially reconstructed. Please verify the integrity in the next step.
            </p>
          </div>
        </div>
      </div>
      {/* END: MainThreeColumnLayout */}

      {/* BEGIN: NextStepActionBanner */}
      <div className="bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-2xs flex items-center justify-between transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
            </svg>
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400 block">
              Next Step
            </span>
            <p className="text-xs text-slate-600 dark:text-slate-300 font-medium mt-0.5">
              Proceed to verification to check file integrity and authenticity.
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            showToast('Navigating to Evidence Explorer for deep inspection and verification', 'success');
            setActiveRoute('evidence-explorer');
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer"
          type="button"
        >
          <span>Continue to Verification</span>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path d="M14 5l7 7m0 0l-7 7m7-7H3" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
          </svg>
        </button>
      </div>
      {/* END: NextStepActionBanner */}
    </div>
  );
};
