import React, { useState, useEffect } from 'react';
import { useForensic } from '../context/ForensicContext';
import { PageRoute } from '../types/forensic';
import { AboutMiraModal } from '../components/modals/AboutMiraModal';
import { HowItWorksModal } from '../components/modals/HowItWorksModal';
import { FeaturesModal } from '../components/modals/FeaturesModal';
import { ContactForensicsModal } from '../components/modals/ContactForensicsModal';
import { FragmentInspectModal, FloatingFragmentData } from '../components/modals/FragmentInspectModal';

interface IntroPageProps {
  onEnter: () => void;
}

export const IntroPage: React.FC<IntroPageProps> = ({ onEnter }) => {
  const { setActiveRoute } = useForensic();

  // Navigation & Interactive Modal States
  const [activeNav, setActiveNav] = useState<'home' | 'about' | 'features' | 'how-it-works' | 'contact'>('home');
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);
  const [isFeaturesOpen, setIsFeaturesOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [selectedFragment, setSelectedFragment] = useState<FloatingFragmentData | null>(null);
  const [isEntering, setIsEntering] = useState(false);

  // Live dynamic reconstruction telemetry for the on-desk monitor
  const [telemetryProgress, setTelemetryProgress] = useState(78);
  const [liveConfidence, setLiveConfidence] = useState(87);
  const [hoveredFragmentId, setHoveredFragmentId] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetryProgress(prev => (prev >= 98 ? 74 : prev + 1));
      setLiveConfidence(prev => (prev >= 96 ? 85 : prev + (Math.random() > 0.6 ? 1 : 0)));
    }, 2400);
    return () => clearInterval(interval);
  }, []);

  const handleEnterWorkspace = (targetRoute: PageRoute = 'overview') => {
    setIsEntering(true);
    setTimeout(() => {
      setActiveRoute(targetRoute);
      onEnter();
    }, 450);
  };

  // Sample forensic fragments floating in 3D space
  const floatingFragments: FloatingFragmentData[] = [
    {
      id: 'frag-jpg',
      name: 'IMG_4920.raw#01',
      type: 'JPG',
      category: 'Image Stream',
      sectorLba: 110,
      offsetHex: '0x0006E000',
      entropy: 7.14,
      magicBytes: 'FF D8 FF E0 00 10 4A 46',
      preview: 'FF D8 FF E0 00 10 4A 46 49 46 00 01 01 01 00 60\n[EXIF METADATA DETECTED: Nikon D850 Raw Fragment]',
      score: 0.94,
    },
    {
      id: 'frag-doc',
      name: 'vault_auth.json#part1',
      type: 'JSON',
      category: 'Auth Credential',
      sectorLba: 12,
      offsetHex: '0x0000C000',
      entropy: 5.18,
      magicBytes: '7B 22 73 65 72 76 69 63',
      preview: '{\n  "service": "production_vault",\n  "operator": "Abhishek",\n  "secret_token": "mira_sec_',
      score: 0.95,
    },
    {
      id: 'frag-db',
      name: 'customer.db#page1',
      type: 'SQL',
      category: 'SQLite B-Tree',
      sectorLba: 40,
      offsetHex: '0x00028000',
      entropy: 6.42,
      magicBytes: '53 51 4C 69 74 65 20 66',
      preview: 'SQLite format 3\\0\nCREATE TABLE customers (id INT, account_id TEXT);',
      score: 0.96,
    },
    {
      id: 'frag-bin',
      name: 'audit_log.bin#run2',
      type: 'BIN',
      category: 'System Trace',
      sectorLba: 64,
      offsetHex: '0x00040000',
      entropy: 4.88,
      magicBytes: '5B 32 30 32 36 2D 30 39',
      preview: '[2026-09-25 14:32:01] BOOT_SEQ: Write-blocker active\nATTESTATION: SHA-256 confirmed',
      score: 0.97,
    },
    {
      id: 'frag-slack',
      name: 'slack_token.dat',
      type: 'DAT',
      category: 'Unallocated Slack',
      sectorLba: 88,
      offsetHex: '0x00058000',
      entropy: 7.82,
      magicBytes: '3A 9F 11 B2 8C C0 44 E9',
      preview: 'High-entropy cipher fragment recovered from unallocated partition margin.',
      score: 0.89,
    },
  ];

  return (
    <div className="relative min-h-screen bg-[#070A12] text-white flex flex-col justify-between overflow-x-hidden selection:bg-cyan-500/30 selection:text-white">
      {/* 1. CINEMATIC DESK PHOTO BACKGROUND & GRADIENT OVERLAYS */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Desk background image matching reference */}
        <img
          src="/mira_forensic_desk.jpg"
          alt="MIRA Forensic Lab Workstation"
          className="w-full h-full object-cover object-right-bottom scale-[1.03] transition-transform duration-1000 ease-out"
        />

        {/* Deep Slate/Obsidian Vignette & Directional Lighting */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#070A12] via-[#070A12]/90 to-[#070A12]/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-transparent to-[#070A12]/80" />
        
        {/* Subtle Ambient Glows corresponding to desk lamp & monitor */}
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[140px]" />
        <div className="absolute top-12 right-12 w-[350px] h-[350px] bg-amber-500/10 rounded-full blur-[120px]" />
        <div className="absolute -bottom-24 left-1/4 w-[600px] h-[300px] bg-indigo-600/10 rounded-full blur-[150px]" />

        {/* Subtle Cyber Grid texture */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(#38BDF8 1px, transparent 1px), linear-gradient(90deg, #38BDF8 1px, transparent 1px)`,
            backgroundSize: '48px 48px',
          }}
        />
      </div>

      {/* 2. TOP NAVIGATION BAR */}
      <header className="relative z-20 w-full px-6 lg:px-12 py-5 flex items-center justify-between border-b border-slate-800/40 backdrop-blur-md">
        {/* Brand Logo: Stylized Ribbon M + MIRA */}
        <div
          onClick={() => handleEnterWorkspace('overview')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          {/* Stylized Modern Gradient M Logo Icon matching reference */}
          <div className="relative w-9 h-9 flex items-center justify-center shrink-0">
            <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 rounded-xl opacity-80 blur-xs group-hover:opacity-100 transition-opacity" />
            <svg
              className="relative w-8 h-8 drop-shadow-md transform group-hover:scale-105 transition-transform"
              viewBox="0 0 40 40"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Left Ribbon Leg */}
              <path
                d="M8 32V10C8 8.89543 8.89543 8 10 8H14C15.1046 8 16 8.89543 16 10V22L22 14L28 22V10C28 8.89543 28.8954 8 30 8H34C35.1046 8 36 8.89543 36 10V32"
                stroke="url(#miraNavGrad)"
                strokeWidth="4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* Accent Crossbar */}
              <path
                d="M10 24H20M20 24L30 32"
                stroke="#38BDF8"
                strokeWidth="3.5"
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="miraNavGrad" x1="8" y1="8" x2="36" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#38BDF8" />
                  <stop offset="0.5" stopColor="#6366F1" />
                  <stop offset="1" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          <div className="flex items-baseline gap-1">
            <span className="text-xl font-extrabold tracking-tight text-white font-sans">
              MIRA
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse ml-0.5" />
          </div>
        </div>

        {/* Center Navigation Links with Active Pill Indicator */}
        <nav className="hidden md:flex items-center gap-8 text-xs font-medium text-slate-300">
          <button
            type="button"
            onClick={() => {
              setActiveNav('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`relative py-1 transition-colors cursor-pointer ${
              activeNav === 'home' ? 'text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Home</span>
            {activeNav === 'home' && (
              <span className="absolute -bottom-2 left-0 right-0 h-[2px] bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full shadow-[0_0_8px_#38BDF8]" />
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveNav('about');
              setIsAboutOpen(true);
            }}
            className={`relative py-1 transition-colors cursor-pointer ${
              activeNav === 'about' ? 'text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>About</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveNav('features');
              setIsFeaturesOpen(true);
            }}
            className={`relative py-1 transition-colors cursor-pointer ${
              activeNav === 'features' ? 'text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Features</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveNav('how-it-works');
              setIsHowItWorksOpen(true);
            }}
            className={`relative py-1 transition-colors cursor-pointer ${
              activeNav === 'how-it-works' ? 'text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>How It Works</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveNav('contact');
              setIsContactOpen(true);
            }}
            className={`relative py-1 transition-colors cursor-pointer ${
              activeNav === 'contact' ? 'text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Contact</span>
          </button>
        </nav>

        {/* Right CTA Button: Get Started → */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => handleEnterWorkspace('overview')}
            disabled={isEntering}
            className="px-5 py-2 rounded-full border border-blue-500/40 bg-slate-900/60 hover:bg-slate-800/80 hover:border-cyan-400 text-xs font-semibold text-white transition-all duration-300 hover:scale-105 hover:shadow-[0_0_20px_rgba(56,189,248,0.25)] flex items-center gap-1.5 cursor-pointer backdrop-blur-sm"
          >
            <span>{isEntering ? 'Entering...' : 'Get Started'}</span>
            <span className="material-symbols-outlined text-[15px]">arrow_forward</span>
          </button>
        </div>
      </header>

      {/* 3. MAIN HERO VIEWPORT */}
      <main className="relative z-10 flex-1 w-full max-w-[1560px] mx-auto px-6 lg:px-12 py-8 lg:py-14 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Column: Headline, Subtitle, and Enter CTA */}
        <div className="lg:col-span-6 space-y-6 lg:pr-6">
          {/* Subtitle tag */}
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            <span className="text-[11px] font-mono font-semibold tracking-[0.2em] text-slate-400 uppercase">
              MEMORY INTELLIGENCE &amp; RESOURCE ANALYSIS
            </span>
          </div>

          {/* Main Headline with Cyan-Purple Gradient on second line */}
          <h1 className="text-4xl sm:text-5xl lg:text-[54px] font-extrabold tracking-tight leading-[1.12] text-white">
            Reconstruct What’s Lost.
            <br />
            <span className="bg-gradient-to-r from-[#38BDF8] via-[#6366F1] to-[#A855F7] bg-clip-text text-transparent drop-shadow-[0_0_28px_rgba(99,102,241,0.35)]">
              Reveal What Matters.
            </span>
          </h1>

          {/* Narrative paragraph */}
          <p className="text-sm sm:text-base text-slate-300/90 max-w-lg leading-relaxed font-sans">
            MIRA finds fragmented data, uncovers relationships, reconstructs what it can, and explains what was recovered.
          </p>

          {/* Call-to-Action Buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-4">
            {/* Primary Pill Button: Enter MIRA → */}
            <button
              type="button"
              onClick={() => handleEnterWorkspace('overview')}
              disabled={isEntering}
              className="px-7 py-3 rounded-full border border-blue-500/50 hover:border-cyan-400 bg-slate-900/80 hover:bg-slate-800 text-white font-semibold text-sm transition-all duration-300 hover:scale-105 shadow-[0_0_25px_rgba(37,99,235,0.3)] flex items-center gap-2.5 cursor-pointer backdrop-blur-md group"
            >
              <span className="tracking-wide">
                {isEntering ? 'INITIALIZING ENGINE...' : 'Enter MIRA'}
              </span>
              <span className="material-symbols-outlined text-[17px] transform group-hover:translate-x-1 transition-transform">
                arrow_forward
              </span>
            </button>

            {/* Quick Demo Launch Button */}
            <button
              type="button"
              onClick={() => handleEnterWorkspace('recovery-analysis')}
              className="px-5 py-3 rounded-full border border-slate-700/80 bg-slate-900/40 hover:bg-slate-800/60 text-slate-300 hover:text-white font-medium text-xs transition-colors flex items-center gap-2 cursor-pointer backdrop-blur-xs"
            >
              <span className="material-symbols-outlined text-[16px] text-cyan-400">play_circle</span>
              <span>Live Recovery Scan</span>
            </button>
          </div>

          {/* Physical Evidence Tag (Echoing the forensic evidence bag on desk) */}
          <div className="pt-3 inline-flex items-center gap-3 px-3.5 py-1.5 rounded-lg bg-slate-900/60 border border-slate-800/80 text-[11px] font-mono text-slate-400 backdrop-blur-xs">
            <span className="text-amber-400 font-bold">DIGITAL EVIDENCE:</span>
            <span>Case No: 2026-091</span>
            <span className="text-slate-600">·</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              Write-Blocker Sealed
            </span>
          </div>
        </div>

        {/* Right Column: 3D Holographic Floating Fragment Network & Monitor */}
        <div className="lg:col-span-6 relative flex items-center justify-center min-h-[380px] lg:min-h-[440px]">
          {/* Interactive 3D Hologram Area */}
          <div className="relative w-full h-full flex items-center justify-between">
            {/* SVG Connecting Neural Fiber Lines */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none z-10"
              viewBox="0 0 600 400"
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="fiberGlowCyan" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.8" />
                  <stop offset="50%" stopColor="#6366F1" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#38BDF8" stopOpacity="0.9" />
                </linearGradient>

                <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* Dynamic Curved Laser Streams from Left Fragments to Central Reconstructed File */}
              <path
                d="M 120 70 C 230 80, 260 160, 350 180"
                stroke="url(#fiberGlowCyan)"
                strokeWidth="2"
                fill="none"
                filter="url(#neonGlow)"
                strokeDasharray="6 3"
                className="animate-[dash_20s_linear_infinite]"
              />
              <path
                d="M 110 130 C 220 140, 260 180, 350 190"
                stroke="url(#fiberGlowCyan)"
                strokeWidth="2.2"
                fill="none"
                filter="url(#neonGlow)"
              />
              <path
                d="M 90 200 C 200 200, 250 195, 350 200"
                stroke="#6366F1"
                strokeWidth="1.8"
                fill="none"
                filter="url(#neonGlow)"
              />
              <path
                d="M 115 270 C 220 260, 270 215, 350 210"
                stroke="url(#fiberGlowCyan)"
                strokeWidth="2"
                fill="none"
                filter="url(#neonGlow)"
                strokeDasharray="8 4"
              />
              <path
                d="M 130 330 C 240 320, 280 230, 350 220"
                stroke="#38BDF8"
                strokeWidth="1.6"
                fill="none"
                filter="url(#neonGlow)"
              />
            </svg>

            {/* Left Column: 5 Floating 3D Digital Fragment Cards */}
            <div className="relative z-20 flex flex-col gap-3 py-2">
              {floatingFragments.map((frag, idx) => {
                const isHovered = hoveredFragmentId === frag.id;
                return (
                  <div
                    key={frag.id}
                    onMouseEnter={() => setHoveredFragmentId(frag.id)}
                    onMouseLeave={() => setHoveredFragmentId(null)}
                    onClick={() => setSelectedFragment(frag)}
                    className={`relative p-2.5 rounded-lg border backdrop-blur-md transition-all duration-300 cursor-pointer shadow-lg select-none group transform hover:scale-105 ${
                      isHovered
                        ? 'bg-cyan-950/80 border-cyan-400 shadow-[0_0_20px_rgba(56,189,248,0.4)] translate-x-2'
                        : 'bg-slate-900/85 border-slate-700/80 hover:border-cyan-500/60'
                    }`}
                    style={{
                      transform: `perspective(600px) rotateY(6deg) translateY(${Math.sin(idx * 1.5) * 4}px)`,
                    }}
                  >
                    <div className="flex items-center gap-2">
                      {/* Fragment Type Icon */}
                      <span className="w-5 h-5 rounded bg-blue-600/30 text-cyan-300 font-mono text-[9px] font-bold flex items-center justify-center border border-cyan-500/30">
                        {frag.type}
                      </span>
                      <div>
                        <span className="text-[11px] font-mono font-bold text-white block leading-none">
                          {frag.name}
                        </span>
                        <span className="text-[9px] font-mono text-slate-400">
                          H={frag.entropy} · {Math.round(frag.score * 100)}%
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Center Destination: 3D Holographic Reconstructed File (PDF with Mountain Preview) */}
            <div className="relative z-20 mx-auto px-4 flex flex-col items-center">
              <div
                onClick={() => handleEnterWorkspace('reconstruction')}
                className="relative group cursor-pointer"
                title="Click to view full reconstructed file in workspace"
              >
                {/* Glowing Aura Ring */}
                <div className="absolute -inset-3 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 opacity-40 group-hover:opacity-80 blur-lg transition-opacity duration-500 animate-pulse" />

                {/* Technical Corner Brackets [ ] */}
                <div className="absolute -top-2 -left-2 w-4 h-4 border-t-2 border-l-2 border-cyan-400 z-30" />
                <div className="absolute -top-2 -right-2 w-4 h-4 border-t-2 border-r-2 border-cyan-400 z-30" />
                <div className="absolute -bottom-2 -left-2 w-4 h-4 border-b-2 border-l-2 border-cyan-400 z-30" />
                <div className="absolute -bottom-2 -right-2 w-4 h-4 border-b-2 border-r-2 border-cyan-400 z-30" />

                {/* Reconstructed File Card */}
                <div className="relative w-28 sm:w-32 h-36 sm:h-40 rounded-xl bg-slate-900/90 border border-cyan-400/80 p-2.5 flex flex-col justify-between shadow-2xl backdrop-blur-xl transform group-hover:scale-105 transition-transform duration-300">
                  {/* File Thumbnail Preview: Mountain photograph graphic */}
                  <div className="relative w-full h-20 rounded-md overflow-hidden bg-slate-800 border border-slate-700">
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent z-10" />
                    {/* Stylized vector mountain terrain preview */}
                    <svg className="w-full h-full" viewBox="0 0 120 80" preserveAspectRatio="none">
                      <polygon points="0,80 30,35 60,65 90,25 120,80" fill="#1E293B" />
                      <polygon points="20,80 50,45 75,70 100,35 120,80" fill="#334155" opacity="0.8" />
                      <polygon points="40,80 70,50 95,75 120,80" fill="#475569" opacity="0.6" />
                      <circle cx="95" cy="20" r="6" fill="#F8FAFC" opacity="0.9" />
                    </svg>
                    <span className="absolute bottom-1 left-1.5 z-20 text-[9px] font-mono text-cyan-300">
                      evidence_doc.pdf
                    </span>
                  </div>

                  {/* Badge & Integrity Meter */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-rose-600/90 text-white">
                      PDF
                    </span>
                    <span className="text-[10px] font-mono font-bold text-emerald-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      100%
                    </span>
                  </div>

                  <span className="text-[9px] font-mono text-slate-400 text-center block border-t border-slate-800 pt-1">
                    Reconstructed File
                  </span>
                </div>
              </div>
            </div>

            {/* Right: On-Desk Workstation Monitor UI (matching reference monitor HUD) */}
            <div
              onClick={() => handleEnterWorkspace('overview')}
              className="relative z-20 hidden sm:block w-48 lg:w-56 p-3.5 rounded-xl bg-slate-950/90 border border-slate-700/80 shadow-2xl backdrop-blur-md cursor-pointer hover:border-cyan-500/60 transition-all group"
            >
              {/* Monitor Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2.5">
                <span className="text-[10px] font-mono font-bold text-slate-300 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                  MIRA Workstation
                </span>
                <span className="text-[9px] font-mono text-slate-500">WS-04</span>
              </div>

              {/* Reconstruction Progress Bar */}
              <div className="space-y-1 mb-3">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-400">Reconstruction Progress</span>
                  <span className="text-cyan-400 font-bold">{telemetryProgress}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 transition-all duration-700"
                    style={{ width: `${telemetryProgress}%` }}
                  />
                </div>
              </div>

              {/* Metric Counts matching reference monitor */}
              <div className="space-y-2 text-[10px] font-mono text-slate-300">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[13px] text-blue-400">description</span>
                    Fragments Found
                  </span>
                  <span className="font-bold text-white">24</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[13px] text-cyan-400">hub</span>
                    Related Groups
                  </span>
                  <span className="font-bold text-white">5</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[13px] text-indigo-400">task</span>
                    File Reconstructed
                  </span>
                  <span className="font-bold text-white">1</span>
                </div>
              </div>

              {/* Recovery Status Pill */}
              <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[9px] font-mono">
                <span className="text-slate-400">Recovery Status</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <span className="material-symbols-outlined text-[12px]">check_circle</span>
                  Partially Recovered ({liveConfidence}%)
                </span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* 4. BOTTOM 5 FEATURE COLUMNS (Separated by subtle vertical dividers matching reference) */}
      <footer className="relative z-20 w-full border-t border-slate-800/80 bg-slate-950/70 backdrop-blur-md">
        <div className="max-w-[1560px] mx-auto grid grid-cols-2 md:grid-cols-5 divide-y md:divide-y-0 md:divide-x divide-slate-800/80">
          {/* 1. Upload & Analyze */}
          <div
            onClick={() => handleEnterWorkspace('evidence-intake')}
            className="p-5 hover:bg-slate-900/60 transition-all cursor-pointer group flex flex-col justify-between space-y-2 select-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:text-cyan-300 transition-colors">
                <span className="material-symbols-outlined text-[20px]">upload_file</span>
              </div>
              <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                Upload &amp; Analyze
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug font-sans">
              Process your data, disk image or fragments.
            </p>
          </div>

          {/* 2. Find Relationships */}
          <div
            onClick={() => handleEnterWorkspace('relationship-graph')}
            className="p-5 hover:bg-slate-900/60 transition-all cursor-pointer group flex flex-col justify-between space-y-2 select-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:text-cyan-200 transition-colors">
                <span className="material-symbols-outlined text-[20px]">hub</span>
              </div>
              <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                Find Relationships
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug font-sans">
              AI detects how fragments connect.
            </p>
          </div>

          {/* 3. Reconstruct Files */}
          <div
            onClick={() => handleEnterWorkspace('reconstruction')}
            className="p-5 hover:bg-slate-900/60 transition-all cursor-pointer group flex flex-col justify-between space-y-2 select-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:text-indigo-300 transition-colors">
                <span className="material-symbols-outlined text-[20px]">extension</span>
              </div>
              <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                Reconstruct Files
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug font-sans">
              Rebuild what can be recovered with confidence.
            </p>
          </div>

          {/* 4. Assess Integrity */}
          <div
            onClick={() => handleEnterWorkspace('sectors')}
            className="p-5 hover:bg-slate-900/60 transition-all cursor-pointer group flex flex-col justify-between space-y-2 select-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:text-emerald-300 transition-colors">
                <span className="material-symbols-outlined text-[20px]">verified_user</span>
              </div>
              <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                Assess Integrity
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug font-sans">
              Know what's recoverable and why.
            </p>
          </div>

          {/* 5. Prioritize & Explore */}
          <div
            onClick={() => handleEnterWorkspace('evidence-explorer')}
            className="p-5 hover:bg-slate-900/60 transition-all cursor-pointer group flex flex-col justify-between space-y-2 select-none col-span-2 md:col-span-1"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:text-purple-300 transition-colors">
                <span className="material-symbols-outlined text-[20px]">fact_check</span>
              </div>
              <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                Prioritize &amp; Explore
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug font-sans">
              Focus on what matters most with clear insights.
            </p>
          </div>
        </div>
      </footer>

      {/* 5. INTERACTIVE FUNCTIONAL MODALS */}
      <AboutMiraModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        onEnter={() => handleEnterWorkspace('overview')}
      />

      <HowItWorksModal
        isOpen={isHowItWorksOpen}
        onClose={() => setIsHowItWorksOpen(false)}
        onEnter={() => handleEnterWorkspace('recovery-analysis')}
      />

      <FeaturesModal
        isOpen={isFeaturesOpen}
        onClose={() => setIsFeaturesOpen(false)}
        onNavigate={handleEnterWorkspace}
      />

      <ContactForensicsModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />

      <FragmentInspectModal
        fragment={selectedFragment}
        isOpen={!!selectedFragment}
        onClose={() => setSelectedFragment(null)}
        onNavigate={handleEnterWorkspace}
      />

      {/* SVG Animation Keyframes */}
      <style>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -1000;
          }
        }
      `}</style>
    </div>
  );
};
